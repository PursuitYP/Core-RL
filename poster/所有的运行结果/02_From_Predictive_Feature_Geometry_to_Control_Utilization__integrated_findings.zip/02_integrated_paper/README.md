# From Predictive Feature Geometry to Control Utilization

**Core topic:** an integrated machine-learning-paper narrative connecting predictive-feature geometry, semantic diagnostics, decodability/control separation, and fixed nonlinear utilization adapters.

This package is the English LaTeX edition of the latest integrated Chinese PDF returned in the conversation. It supersedes the earlier integrated-paper revisions. It includes the main cross-environment pilot, the complete Stage A/B1/B2 adapter evidence, negative results, stability/runtime diagnostics, and full appendix tables.

## Build

```bash
./build.sh
```

A standard TeX Live/MiKTeX installation with `latexmk` and `pdflatex` is sufficient.
