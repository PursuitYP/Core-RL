## Source and version selection

This package translates the latest integrated-paper version (`流式部分可观测强化学习_整合论文_中文版.pdf`). Earlier integrated revisions were treated as minor versions and were not packaged separately.
