"""Read-only audit of pre-existing experiment artifacts.

This script never modifies files outside ``paper_from_existing_results``.  It
creates exhaustive result/figure inventories and deterministic summaries used
by the Chinese report.
"""

from __future__ import annotations

import csv
import hashlib
import json
import math
import struct
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import pandas as pd


OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
RESULTS = ROOT / "results"


SELECTED_FIGURES = {
    "results/cross_pilot/preregistered-cross-pilot-20260713-v1/figures/final_performance_by_environment.png",
    "results/cross_pilot/preregistered-cross-pilot-20260713-v1/figures/task_matched_vs_generic.png",
    "results/cross_pilot/preregistered-cross-pilot-20260713-v1/figures/decodability_vs_control.png",
    "results/cross_pilot/preregistered-cross-pilot-20260713-v1/figures/effective_rank_vs_control.png",
    "results/cross_pilot/preregistered-cross-pilot-20260713-v1/figures/isotropy_vs_control.png",
    "results/cross_pilot/preregistered-cross-pilot-20260713-v1/figures/moment_error_vs_control_performance.png",
    "results/cross_pilot/preregistered-cross-pilot-20260713-v1/figures/update_norm_stability.png",
    "results/cross_pilot/preregistered-cross-pilot-20260713-v1/figures/covariance_eigenvalue_spectra.png",
    "results/cross_pilot/preregistered-cross-pilot-20260713-v1/figures/property_fulfillment_summary.png",
    "results/cross_pilot/preregistered-cross-pilot-20260713-v1/figures/environment_specific_latent_geometry.png",
    "results/cross_pilot/preregistered-cross-pilot-20260713-v1/figures/e1_cue_clusters.png",
    "results/cross_pilot/preregistered-cross-pilot-20260713-v1/figures/e2_circular_phase.png",
    "results/cross_pilot/preregistered-cross-pilot-20260713-v1/figures/e3_block_representation.png",
    "results/cross_pilot/preregistered-cross-pilot-20260713-v1/figures/e4_hidden_velocity_prediction.png",
    "results/pilot/preregistered-pilot-20260713-v3/figures/final_accuracy.png",
    "results/pilot/preregistered-pilot-20260713-v3/figures/cue_decodability_by_position.png",
    "results/pilot/preregistered-pilot-20260713-v3/figures/accuracy_vs_cue_decodability.png",
    "results/diagnostics/preregistered-20260713-v3/figures/gaussian_synthetic_histograms.png",
}


FIGURE_META: dict[str, dict[str, str]] = {
    "final_performance_by_environment.png": {
        "topic": "各环境末窗控制表现",
        "x": "condition",
        "y": "E1-E3 为末窗 accuracy；E4 为末窗 reward（越大越好）",
        "legend": "颜色对应 condition；四个 panel 对应环境",
        "error": "跨 seed 标准误（SEM）",
        "supports": "环境内 condition 差异、跨 seed 不确定性与异质性",
        "cannot": "不能据三 seed 证明普遍优越或统计显著性",
    },
    "task_matched_vs_generic.png": {
        "topic": "matched、raw、whitened 与 gaussian_moment 的环境内比较",
        "x": "condition",
        "y": "末窗 accuracy/reward",
        "legend": "颜色对应 condition；四个 panel 对应环境",
        "error": "跨 seed SEM",
        "supports": "task-matched prior 并非跨环境一致占优",
        "cannot": "不能将差异归因于单一几何因素",
    },
    "control_learning_curves_by_environment.png": {
        "topic": "按环境汇总的在线控制曲线",
        "x": "interaction",
        "y": "moving accuracy 或 moving reward",
        "legend": "颜色对应 condition",
        "error": "均值周围的跨 seed SEM 阴影",
        "supports": "训练过程中的不稳定性和环境差异",
        "cannot": "two_loop 中存在长对角伪影且曲线拥挤，不宜作为正式收敛证据",
    },
    "decodability_vs_control.png": {
        "topic": "held-out task decodability 与控制表现",
        "x": "task_decodability（环境特定 held-out probe）",
        "y": "末窗表现",
        "legend": "颜色对应 condition；点为 condition×seed",
        "error": "无误差条；展示单 seed 点",
        "supports": "信息可解码与在线控制可分离，关系依赖环境",
        "cannot": "不能证明 decodability 的因果中介作用或充分性",
    },
    "effective_rank_vs_control.png": {
        "topic": "effective rank 与控制表现",
        "x": "effective rank",
        "y": "末窗表现",
        "legend": "颜色对应 condition；点为 condition×seed",
        "error": "无误差条",
        "supports": "较高 effective rank 不是高表现的充分条件",
        "cannot": "不能证明 rank 对表现没有任何影响",
    },
    "isotropy_vs_control.png": {
        "topic": "二阶 isotropy error 与控制表现",
        "x": "isotropy error（越低越接近单位协方差）",
        "y": "末窗表现",
        "legend": "颜色对应 condition；点为 condition×seed",
        "error": "无误差条",
        "supports": "改善二阶几何不保证控制改善",
        "cannot": "不能把相关散点解释为因果",
    },
    "moment_error_vs_control_performance.png": {
        "topic": "skewness/kurtosis error 与控制表现",
        "x": "skewness error 或 kurtosis error",
        "y": "末窗表现（混合不同环境的原始尺度）",
        "legend": "颜色对应 condition；点为 condition×seed",
        "error": "无误差条",
        "supports": "较小矩误差不自动对应较高控制表现",
        "cannot": "混合环境尺度，不能用于总体相关或因果结论",
    },
    "update_norm_stability.png": {
        "topic": "控制器在线更新范数",
        "x": "condition",
        "y": "control update norm",
        "legend": "四个 panel 对应环境",
        "error": "聚合更新样本的 SEM；不是 seed 间独立 SEM",
        "supports": "不同变换改变更新尺度与稳定性",
        "cannot": "该误差条口径不能替代跨 seed 不确定性",
    },
    "covariance_eigenvalue_spectra.png": {
        "topic": "表征协方差特征值谱",
        "x": "特征值秩",
        "y": "协方差特征值（对数尺度）",
        "legend": "颜色对应 condition；曲线为跨 seed 均值",
        "error": "无误差条",
        "supports": "秩亏、谱形与变换的二阶效应",
        "cannot": "不能单独推出任务信息或控制表现",
    },
    "property_fulfillment_summary.png": {
        "topic": "真实流中的 isotropy error 热图",
        "x": "condition",
        "y": "environment",
        "legend": "颜色和格内数字为跨 seed 平均 isotropy error",
        "error": "无误差条",
        "supports": "property fulfillment 与控制表现可分离",
        "cannot": "oracle/observation 的特征维度不同，不能作纯变换公平比较",
    },
    "environment_specific_latent_geometry.png": {
        "topic": "matched representation 的环境特定几何",
        "x": "matched 坐标或 PCA 坐标",
        "y": "matched 坐标或 PCA 坐标",
        "legend": "颜色为真实 latent，仅用于离线诊断；取 matched 的 seed 0",
        "error": "无误差条；单 seed 诊断样本",
        "supports": "输出约束形状及其与 latent 的可视对应",
        "cannot": "不能代表跨 seed 稳定性或证明控制优势",
    },
    "e1_cue_clusters.png": {
        "topic": "E1 matched simplex 的 cue 着色",
        "x": "simplex coordinate 1",
        "y": "simplex coordinate 2",
        "legend": "颜色为真实 cue，仅用于 held-out 诊断；seed 0",
        "error": "无误差条",
        "supports": "simplex 约束满足但 cue 类别高度重叠",
        "cannot": "不能由单 seed 图推出控制性能",
    },
    "e2_circular_phase.png": {
        "topic": "E2 matched circular block",
        "x": "circular block 1",
        "y": "circular block 2",
        "legend": "颜色为真实 phase，仅用于诊断；seed 0",
        "error": "无误差条",
        "supports": "单位圆约束满足但真实 phase order 不完整",
        "cannot": "不能把圆形外观等同于正确相位排序",
    },
    "e3_block_representation.png": {
        "topic": "E3 matched block：identity simplex 与 phase circle",
        "x": "identity/phase block coordinate 1",
        "y": "identity/phase block coordinate 2",
        "legend": "颜色为真实 identity 或 phase；seed 0",
        "error": "无误差条",
        "supports": "两块命名约束的输出形状",
        "cannot": "不能由形状本身证明 block 是性能提升原因",
    },
    "e4_hidden_velocity_prediction.png": {
        "topic": "E4 matched 表征的 held-out velocity probe",
        "x": "真实 velocity",
        "y": "线性 probe 预测",
        "legend": "虚线为理想 y=x；seed 0",
        "error": "无误差条",
        "supports": "可线性恢复部分 velocity，但预测被明显压缩",
        "cannot": "不能代表跨 seed 稳定性或控制优势",
    },
    "final_accuracy.png": {
        "topic": "core T-maze 末窗 trial accuracy",
        "x": "condition",
        "y": "final-window trial accuracy",
        "legend": "每柱为跨 seed 均值，柱上标 n",
        "error": "跨 seed SEM",
        "supports": "oracle 可学，而非 oracle 方法在三 seed pilot 中接近",
        "cannot": "不能证明方法等价或长期无差异",
    },
    "cue_decodability_by_position.png": {
        "topic": "core T-maze cue decodability 随位置变化",
        "x": "corridor position / junction",
        "y": "held-out cue balanced accuracy",
        "legend": "颜色对应 condition",
        "error": "跨 seed SEM 阴影",
        "supports": "多种表征在 junction 前后包含线性可解码 cue 信息",
        "cannot": "不能证明控制器实际利用了该信息",
    },
    "accuracy_vs_cue_decodability.png": {
        "topic": "core T-maze junction decodability 与末窗 accuracy",
        "x": "junction cue decodability",
        "y": "final-window trial accuracy",
        "legend": "颜色对应 condition；点为 seed",
        "error": "无误差条",
        "supports": "高 decodability 并非高控制表现的充分条件",
        "cannot": "不能证明 decodability 不必要或没有因果作用",
    },
    "accuracy_vs_isotropy_error.png": {
        "topic": "core T-maze isotropy error 与 accuracy",
        "x": "isotropy error",
        "y": "final-window trial accuracy",
        "legend": "颜色对应 condition；点为 seed",
        "error": "无误差条",
        "supports": "二阶几何改善与控制改善脱钩",
        "cannot": "不能证明 whitening 有害",
    },
    "accuracy_vs_effective_rank.png": {
        "topic": "core T-maze effective rank 与 accuracy",
        "x": "effective rank",
        "y": "final-window trial accuracy",
        "legend": "颜色对应 condition；点为 seed",
        "error": "无误差条",
        "supports": "effective rank 不是性能充分条件",
        "cannot": "不能证明 rank 与优化无关",
    },
    "gaussian_synthetic_histograms.png": {
        "topic": "gaussian_moment 的合成流分布前后对比",
        "x": "标准化特征值",
        "y": "概率密度",
        "legend": "before/after；不同 panel 为不同合成分布",
        "error": "无误差条；确定性合成诊断",
        "supports": "在线 moment shaping 改变偏度/尾部且保留双峰结构",
        "cannot": "不能保证真实流或一般分布高斯化",
    },
    "property_before_after.png": {
        "topic": "合成性质诊断前后对比",
        "x": "方法/合成流",
        "y": "相关、isotropy、skewness 或 kurtosis error",
        "legend": "before/after",
        "error": "无误差条；确定性合成诊断",
        "supports": "命名性质在合成流上的方向性变化",
        "cannot": "不能代替真实流性质门控或控制结果",
    },
    "property_pass_fail.png": {
        "topic": "性质门控通过/失败汇总",
        "x": "method×stream×check",
        "y": "pass/fail",
        "legend": "绿色为通过；空白/0 为失败",
        "error": "无误差条",
        "supports": "检查覆盖范围及失败项存在",
        "cannot": "标签密集，必须结合 pass_fail_summary.csv 解读具体失败",
    },
    "real_stream_effective_rank.png": {
        "topic": "matched representation 的真实流 effective rank",
        "x": "environment",
        "y": "effective rank",
        "legend": "单次诊断流",
        "error": "无误差条",
        "supports": "不同 matched 输出维度/秩结构",
        "cannot": "不能支持控制优越性",
    },
    "real_stream_matched_geometry.png": {
        "topic": "真实流 matched prior 输出几何",
        "x": "matched coordinate 1",
        "y": "matched coordinate 2",
        "legend": "四个 panel 对应环境；单诊断流",
        "error": "无误差条",
        "supports": "约束输出形状",
        "cannot": "无 latent 着色，不能判断任务语义排序",
    },
    "matched_prior_geometry.png": {
        "topic": "合成 M2/M3 prior 几何",
        "x": "matched coordinate 1",
        "y": "matched coordinate 2",
        "legend": "合成诊断",
        "error": "无误差条",
        "supports": "合成输入上圆/单纯形约束",
        "cannot": "不能代表真实在线流或控制",
    },
    "cumulative_reward.png": {
        "topic": "累计 reward",
        "x": "condition",
        "y": "cumulative reward",
        "legend": "柱为跨 seed 均值",
        "error": "跨 seed SEM",
        "supports": "同一环境内累计回报差异",
        "cannot": "不能跨不同 reward 单位环境直接比较",
    },
    "trial_accuracy_learning_curve.png": {
        "topic": "core T-maze trial accuracy 学习曲线",
        "x": "trial",
        "y": "moving trial accuracy",
        "legend": "颜色对应 condition",
        "error": "跨 seed SEM",
        "supports": "短预算内的学习过程",
        "cannot": "不能外推 full-run 收敛",
    },
    "gvf_prediction_error.png": {
        "topic": "GVF TD error 学习曲线",
        "x": "interaction",
        "y": "GVF mean squared TD error",
        "legend": "颜色对应 condition",
        "error": "跨 seed SEM",
        "supports": "预测更新动态",
        "cannot": "不能直接推出控制质量",
    },
    "condition_number.png": {
        "topic": "协方差 condition number",
        "x": "condition",
        "y": "regularized condition number",
        "legend": "柱为跨 seed 均值",
        "error": "跨 seed SEM",
        "supports": "二阶条件性差异",
        "cannot": "不能单独解释控制表现",
    },
    "covariance_eigenvalue_spectrum.png": {
        "topic": "core T-maze 协方差特征值谱",
        "x": "eigenvalue rank",
        "y": "eigenvalue（log）",
        "legend": "颜色对应 condition；跨 seed 均值",
        "error": "无误差条",
        "supports": "秩亏和二阶谱差异",
        "cannot": "不能直接推出任务信息",
    },
    "cue_conditioned_feature_projection.png": {
        "topic": "按 cue 着色的 PCA 投影",
        "x": "PC1",
        "y": "PC2",
        "legend": "颜色为 cue；每 condition 仅使用首个找到的 seed",
        "error": "无误差条；单 seed",
        "supports": "定性聚类结构",
        "cannot": "不能作跨 seed 或因果结论",
    },
    "cue_conditioned_feature_histograms.png": {
        "topic": "按 cue 分组的 PC1 直方图",
        "x": "PC1",
        "y": "density",
        "legend": "颜色为 cue；每 condition 仅首个 seed",
        "error": "无误差条；单 seed",
        "supports": "定性分离/重叠",
        "cannot": "不能替代 held-out decodability 统计",
    },
    "cue_decodability.png": {
        "topic": "cue decodability",
        "x": "condition/position",
        "y": "held-out decodability",
        "legend": "依批次而定",
        "error": "依生成脚本而定",
        "supports": "早期 cue 可解码性诊断",
        "cannot": "早期/轻量批次不能替代正式 pilot",
    },
    "effective_rank.png": {
        "topic": "effective rank",
        "x": "condition",
        "y": "effective rank",
        "legend": "柱为跨 seed 均值",
        "error": "跨 seed SEM",
        "supports": "表示秩差异",
        "cannot": "不能单独推出控制质量",
    },
    "isotropy_error.png": {
        "topic": "isotropy error",
        "x": "condition",
        "y": "covariance isotropy error",
        "legend": "柱为跨 seed 均值",
        "error": "跨 seed SEM",
        "supports": "二阶各向同性差异",
        "cannot": "不能等同于高斯性或控制质量",
    },
    "kurtosis_error.png": {
        "topic": "kurtosis error",
        "x": "condition",
        "y": "mean absolute kurtosis error",
        "legend": "柱为跨 seed 均值",
        "error": "跨 seed SEM",
        "supports": "四阶矩差异",
        "cannot": "不能保证分布形状或控制质量",
    },
    "skewness_error.png": {
        "topic": "skewness error",
        "x": "condition",
        "y": "mean absolute skewness",
        "legend": "柱为跨 seed 均值",
        "error": "跨 seed SEM",
        "supports": "三阶矩差异",
        "cannot": "不能保证分布形状或控制质量",
    },
    "mean_abs_corr.png": {
        "topic": "平均绝对非对角相关",
        "x": "condition",
        "y": "mean absolute correlation",
        "legend": "柱为跨 seed 均值",
        "error": "跨 seed SEM",
        "supports": "相关结构差异",
        "cannot": "不能等同于 whitening 或控制质量",
    },
    "norm_mean.png": {
        "topic": "平均 feature norm",
        "x": "condition",
        "y": "mean feature norm",
        "legend": "柱为跨 seed 均值",
        "error": "跨 seed SEM",
        "supports": "幅值/尺度差异",
        "cannot": "不能单独解释几何或性能",
    },
    "update_norm.png": {
        "topic": "平均控制更新范数",
        "x": "condition",
        "y": "mean controller update norm",
        "legend": "柱为跨 seed 均值",
        "error": "跨 seed SEM",
        "supports": "优化尺度差异",
        "cannot": "不能等同于稳定高性能",
    },
}


def rel(path: Path) -> str:
    return path.relative_to(ROOT).as_posix()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def load_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {"_type": type(value).__name__}
    except Exception as error:  # preserved as audit evidence
        return {"_read_error": f"{type(error).__name__}: {error}"}


def csv_header(path: Path) -> list[str]:
    try:
        with path.open("r", encoding="utf-8-sig", newline="") as handle:
            return next(csv.reader(handle), [])
    except Exception:
        return []


def png_size(path: Path) -> tuple[int | None, int | None]:
    try:
        with path.open("rb") as handle:
            if handle.read(8) != b"\x89PNG\r\n\x1a\n":
                return None, None
            length = struct.unpack(">I", handle.read(4))[0]
            if handle.read(4) != b"IHDR" or length < 8:
                return None, None
            return struct.unpack(">II", handle.read(8))
    except Exception:
        return None, None


def package_root(path: Path) -> Path | None:
    candidates: list[Path] = []
    for parent in path.parents:
        if parent == RESULTS.parent:
            break
        if parent == RESULTS:
            continue
        try:
            relative = parent.relative_to(RESULTS)
        except ValueError:
            continue
        if "runs" in relative.parts:
            continue
        if (parent / "manifest.json").exists():
            candidates.append(parent)
    if candidates:
        return max(candidates, key=lambda item: len(item.relative_to(RESULTS).parts))
    return None


def infer_run_identity(path: Path) -> tuple[str, str, str]:
    parts = path.parts
    if "runs" not in parts:
        return "聚合/多环境", "聚合/多 condition", "聚合/多 seed"
    index = parts.index("runs")
    tail = parts[index + 1 :]
    if len(tail) >= 4 and tail[2].startswith("seed_"):
        return tail[0], tail[1], tail[2].replace("seed_", "")
    if len(tail) >= 3 and tail[1].startswith("seed_"):
        return "tmaze(core)", tail[0], tail[1].replace("seed_", "")
    return "未确认", "未确认", "未确认"


PURPOSE = {
    "aggregate_summary.csv": "run-level 主指标聚合",
    "condition_summary.csv": "condition-level 均值与 SEM",
    "aggregate_representation.csv": "run-level 表征统计聚合",
    "aggregate_task_information.csv": "run-level held-out 任务信息指标",
    "aggregate_updates.csv": "在线更新轨迹聚合",
    "aggregate_steps.csv": "在线 reward/performance 轨迹聚合",
    "aggregate_decisions.csv": "离散决策事件聚合",
    "aggregate_prediction.csv": "预测指标聚合",
    "aggregate_hidden_state.csv": "held-out hidden-state 指标聚合",
    "aggregate_trials.csv": "trial 指标聚合",
    "summary.csv": "单 run 主指标",
    "summary.json": "单 run 主指标与元数据",
    "representation_metrics.csv": "单 run 表征统计",
    "task_information_metrics.csv": "单 run held-out task probe",
    "hidden_state_metrics.csv": "单 run held-out cue/hidden-state probe",
    "prediction_metrics.csv": "单 run GVF/预测误差轨迹",
    "update_metrics.csv": "单 run 控制/预测更新轨迹",
    "step_metrics.csv": "单 run step-level reward/performance",
    "decision_metrics.csv": "单 run decision-level accuracy",
    "per_trial_metrics.csv": "单 run trial-level 指标",
    "per_step_metrics.csv": "单 run step-level 指标",
    "config.json": "实际运行配置副本",
    "manifest.json": "运行 provenance、状态与完整性",
    "predictive_definitions.json": "固定预测问题定义",
    "gvf_definitions.json": "固定 GVF 定义",
    "predictive_weights.npy": "最终线性预测权重",
    "gvf_weights.npz": "最终 GVF 权重",
    "diagnostic_samples.npz": "held-out 表征/latent 诊断样本",
    "junction_features.npz": "junction 表征与 cue 诊断样本",
    "stdout.log": "单 run 执行日志",
    "pass_fail_summary.csv": "性质门控逐项通过/失败证据",
    "real_stream_metrics.csv": "真实流性质统计",
    "synthetic_before_after_metrics.csv": "合成流变换前后统计",
}


def result_file_level(path: Path) -> str:
    if path.suffix.lower() == ".png":
        return "可视化（由已保存数据生成）"
    if "runs" in path.parts:
        return "单 run 原始/派生 artifact"
    if path.name.startswith(("aggregate_", "condition_summary")):
        return "聚合结果"
    if "diagnostics" in path.parts:
        return "诊断结果"
    return "批次级元数据/日志"


def selected_conclusion(path: Path) -> str:
    p = rel(path)
    if p in SELECTED_FIGURES:
        return "用于正文图表与对应受限结论"
    if "preregistered-cross-pilot-20260713-v1" in p:
        return "主 cross-pilot 证据"
    if "preregistered-pilot-20260713-v3" in p:
        return "core T-maze 正式 pilot 证据"
    if "preregistered-cross-20260713-v2" in p:
        return "superseding property gate（含失败项）"
    if any(tag in p for tag in ("compact", "bank-mixed", "short-horizon", "matched-horizon")):
        return "配对 bank/horizon ablation"
    return "不进入主要结论；保留作 provenance/重复/失败证据"


def make_result_inventory() -> dict[str, Any]:
    files = sorted(path for path in RESULTS.rglob("*") if path.is_file())
    hashes: dict[Path, str] = {path: sha256(path) for path in files}
    groups: dict[str, list[Path]] = defaultdict(list)
    for path, digest in hashes.items():
        groups[digest].append(path)
    canonical = {digest: sorted(items, key=lambda item: rel(item))[0] for digest, items in groups.items()}

    package_roots = sorted(
        {
            root
            for path in files
            if (root := package_root(path)) is not None
        },
        key=rel,
    )
    packages: list[dict[str, Any]] = []
    for root in package_roots:
        manifest = load_json(root / "manifest.json")
        package_files = [path for path in files if root in path.parents or path == root]
        run_summaries = list((root / "runs").rglob("summary.csv")) if (root / "runs").exists() else []
        expected = manifest.get("validation", {}).get("expected_runs") if isinstance(manifest.get("validation"), dict) else None
        recorded_runs = manifest.get("validation", {}).get("runs") if isinstance(manifest.get("validation"), dict) else None
        packages.append(
            {
                "path": rel(root),
                "profile": manifest.get("profile", root.parent.name),
                "status": manifest.get("exit_status", "未记录"),
                "expected": expected if expected is not None else "—",
                "recorded": recorded_runs if recorded_runs is not None else "—",
                "summary_files": len(run_summaries),
                "files": len(package_files),
                "images": sum(path.suffix.lower() == ".png" for path in package_files),
                "commit": str(manifest.get("git_commit", "—"))[:12],
                "dirty": manifest.get("git_dirty", "—"),
            }
        )

    duplicate_files = sum(len(items) - 1 for items in groups.values())
    lines = [
        "# 结果文件盘点",
        "",
        "> 本文件由 `audit_existing_results.py` 只读扫描生成。逐文件 SHA-256 用于识别完全重复项；相同文件名但不同哈希不会被视为重复。",
        "",
        "## 总览",
        "",
        f"- 结果目录文件总数：**{len(files)}**。",
        f"- 唯一 SHA-256：**{len(groups)}**；逐字节重复副本：**{duplicate_files}**。",
        f"- 识别批次/诊断根目录：**{len(packages)}**。",
        "- 正式解释优先级：`cross_pilot/...v1` 主矩阵；compact/mixed 与 short/matched-horizon 配对消融；`diagnostics/...cross...v2` superseding property gate；`pilot/...v3` core T-maze pilot。",
        "- `pilot/...v2` 的顶层 manifest 实际记录 `ok`、30/30，与 `docs/work_log.md` 中“v2 被中断”的文字不一致；正文不使用 v2，避免版本争议。",
        "",
        "## 批次级完整性",
        "",
        "| 路径 | profile | status | manifest expected/recorded | 实际 summary.csv | 文件 | 图片 | commit | dirty |",
        "|---|---|---:|---:|---:|---:|---:|---|---:|",
    ]
    for item in packages:
        lines.append(
            f"| `{item['path']}` | `{item['profile']}` | `{item['status']}` | "
            f"{item['expected']}/{item['recorded']} | {item['summary_files']} | {item['files']} | "
            f"{item['images']} | `{item['commit']}` | `{item['dirty']}` |"
        )

    lines.extend(
        [
            "",
            "## 已调查的冲突、缺失与统计口径",
            "",
            "- `results/diagnostics/cross_environment/preregistered-cross-20260713-v2` 为 29/30、`failed`；唯一失败是 E2 circular real-stream phase order（0.2406，固定阈值 0.3），不是数值发散。",
            "- 主 cross-pilot 为 120/120、`ok`，四环境各 10 conditions×3 seeds；NaN、Inf、divergence 均为 0。",
            "- core pilot v1 因旧 validator 对 not-applicable 字段处理错误而顶层失败；v3 为正式 30/30 证据。",
            "- smoke 和多次 final/remote-deploy smoke 中存在大量逐字节重复副本；不把它们计作独立科学证据。",
            "- E1-E3 的 `final_performance` 是末窗 accuracy；E4 是末窗 reward。不同环境的原始 performance 不做合并均值或总体相关。",
            "- `update_norm_stability.png` 的 SEM 是对聚合 update rows 计算，并非先按 seed 聚合后的 seed 间 SEM；仅作定性稳定性图。",
            "",
            "## 逐文件记录",
            "",
            "| 路径 | 类型/用途 | 环境 | condition | seed | metrics/字段 | 原始或聚合 | 可视化 | 正文使用 | 对应结论 | 重复 | 冲突/统计口径/无法解释字段 | SHA-256 |",
            "|---|---|---|---|---|---|---|---:|---:|---|---|---|---|",
        ]
    )
    for path in files:
        environment, condition, seed = infer_run_identity(path)
        header = csv_header(path) if path.suffix.lower() == ".csv" else []
        metrics = ", ".join(header[:10]) + ("…" if len(header) > 10 else "")
        if not metrics and path.suffix.lower() == ".json":
            metrics = ", ".join(list(load_json(path).keys())[:10])
        duplicate_note = "否"
        if len(groups[hashes[path]]) > 1:
            duplicate_note = f"是；canonical=`{rel(canonical[hashes[path]])}`；group={len(groups[hashes[path]])}"
        conflict = "无已知冲突"
        p = rel(path)
        if "preregistered-pilot-20260713-v2" in p:
            conflict = "manifest 30/30 ok，但 work_log 文字称 v2 中断；正文排除"
        elif "cross-smoke-20260713-v1" in p:
            conflict = "工程批次顶层 failed；仅保留失败证据"
        elif "preregistered-cross-20260713-v2" in p:
            conflict = "property gate 29/30；E2 real-stream phase order 失败"
        elif path.name == "aggregate_updates.csv":
            conflict = "行级 update 样本非独立；不得把行级 SEM 写成 seed 间 SEM"
        used = "是" if p in SELECTED_FIGURES else "否"
        purpose = PURPOSE.get(path.name, FIGURE_META.get(path.name, {}).get("topic", "结果 artifact/未单独命名用途"))
        lines.append(
            f"| `{p}` | {path.suffix.lower() or '无扩展名'}；{purpose} | `{environment}` | `{condition}` | `{seed}` | "
            f"{metrics or '二进制/日志字段见文件'} | {result_file_level(path)} | {'是' if path.suffix.lower()=='.png' else '否'} | {used} | "
            f"{selected_conclusion(path)} | {duplicate_note} | {conflict} | `{hashes[path]}` |"
        )
    (OUT / "result_inventory.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return {
        "files": len(files),
        "unique_hashes": len(groups),
        "duplicate_files": duplicate_files,
        "packages": packages,
    }


def make_figure_inventory() -> dict[str, Any]:
    extensions = {".png", ".jpg", ".jpeg", ".svg", ".pdf", ".eps"}
    excluded_roots = {".git", ".venv", ".pytest_cache", ".mplconfig", OUT.name}
    images = sorted(
        path
        for path in ROOT.rglob("*")
        if path.is_file()
        and path.suffix.lower() in extensions
        and not any(part in excluded_roots for part in path.relative_to(ROOT).parts)
    )
    hashes = {path: sha256(path) for path in images}
    groups: dict[str, list[Path]] = defaultdict(list)
    for path, digest in hashes.items():
        groups[digest].append(path)
    canonical = {digest: sorted(items, key=lambda item: rel(item))[0] for digest, items in groups.items()}
    duplicate_files = sum(len(items) - 1 for items in groups.values())
    lines = [
        "# 候选图片审计",
        "",
        "> 审计模式：`academic-figure` 的 `figure-audit`。所有图均由本地已有结果生成；没有外部图片或模拟补图。",
        "",
        "## 总览与 QA 结论",
        "",
        f"- 候选图片：**{len(images)}**；唯一 SHA-256：**{len(groups)}**；完全重复副本：**{duplicate_files}**。",
        f"- 正文采用：**{len(SELECTED_FIGURES)}**；其余按补充价值、重复、批次地位和可读性标记。",
        "- 关键 QA 风险：现有图片均为 160 dpi PNG，不是可编辑 SVG；本任务保留其数据真实性并在 PDF 中按可读宽度排版。",
        "- 现有多 condition 图使用超过六种颜色，且颜色是主要编码；图注会列 condition，正文不依赖颜色单独识别结论。",
        "- `control_learning_curves_by_environment.png` 因拥挤和 two_loop 长对角伪影排除。",
        "- short/matched-horizon 的四面板图含两个 n=0 空 panel；消融改用 CSV 表格，图排除。",
        "- 所有单 seed latent 几何图均在图注中标明“诊断性、不能代表跨 seed 稳定性”。",
        "",
        "## 逐图记录",
        "",
        "| 原始路径 | 尺寸 | 主题 | 横轴 | 纵轴 | 图例/颜色/点线 | 误差条 | 数据来源 | 支持 | 不支持 | 重复 | 可读性/组合 | 最终决定 | 原因 | SHA-256 |",
        "|---|---:|---|---|---|---|---|---|---|---|---|---|---|---|---|",
    ]
    for path in images:
        p = rel(path)
        meta = FIGURE_META.get(
            path.name,
            {
                "topic": "未在正式绘图脚本中单独恢复的早期/中间图",
                "x": "见图内标签",
                "y": "见图内标签",
                "legend": "见图内图例",
                "error": "未确认",
                "supports": "仅作历史/中间诊断",
                "cannot": "不能进入主要结论",
            },
        )
        width, height = png_size(path) if path.suffix.lower() == ".png" else (None, None)
        duplicate_note = "否"
        if len(groups[hashes[path]]) > 1:
            duplicate_note = f"是；canonical=`{rel(canonical[hashes[path]])}`；group={len(groups[hashes[path]])}"
        if p in SELECTED_FIGURES:
            decision = "正文采用"
            reason = "来自正式/主证据批次，研究问题明确，正文将逐图分析"
        elif path.name == "control_learning_curves_by_environment.png":
            decision = "排除"
            reason = "曲线拥挤；two_loop 存在长对角伪影，避免误导"
        elif any(tag in p for tag in ("short-horizon", "matched-horizon")) and path.name == "final_performance_by_environment.png":
            decision = "排除"
            reason = "E3/E4 空 panel；改用配对 CSV 表格"
        elif len(groups[hashes[path]]) > 1 and canonical[hashes[path]] != path:
            decision = "排除"
            reason = "逐字节重复副本，不计作独立证据"
        elif any(tag in p for tag in ("smoke", "local-pilot", "pilot-20260713-v1", "pilot-20260713-v2")):
            decision = "排除"
            reason = "工程/smoke/失败/非正式批次，已有更高优先级正式结果"
        elif "diagnostics" in p:
            decision = "补充结果采用"
            reason = "保留作性质/失败门控补充证据，正文优先用表格或已选代表图"
        elif any(tag in p for tag in ("compact", "bank-mixed", "short-horizon", "matched-horizon")):
            decision = "补充结果采用"
            reason = "配对消融候选，但正文优先用数值表减少重复图"
        else:
            decision = "排除"
            reason = "与正式批次图语义重复或研究解释增量有限"
        data_source = "生成脚本与同批次 CSV/NPZ；详见 result_inventory.md"
        readability = "PNG 160 dpi；标签可读但非矢量"
        if path.name in {"property_pass_fail.png", "control_learning_curves_by_environment.png"}:
            readability += "；标签/曲线密集"
        lines.append(
            f"| `{p}` | {width or '—'}×{height or '—'} | {meta['topic']} | {meta['x']} | {meta['y']} | {meta['legend']} | "
            f"{meta['error']} | {data_source} | {meta['supports']} | {meta['cannot']} | {duplicate_note} | {readability} | "
            f"{decision} | {reason} | `{hashes[path]}` |"
        )
    (OUT / "figure_inventory.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return {
        "candidates": len(images),
        "unique_hashes": len(groups),
        "duplicate_files": duplicate_files,
        "selected": len(SELECTED_FIGURES),
        "decisions": Counter(
            "正文采用" if rel(path) in SELECTED_FIGURES else "其他" for path in images
        ),
    }


def pearson(x: pd.Series, y: pd.Series) -> float:
    mask = x.notna() & y.notna() & np.isfinite(x) & np.isfinite(y)
    if mask.sum() < 3 or float(x[mask].std()) == 0.0 or float(y[mask].std()) == 0.0:
        return float("nan")
    return float(np.corrcoef(x[mask], y[mask])[0, 1])


def spearman(x: pd.Series, y: pd.Series) -> float:
    return pearson(x.rank(), y.rank())


def sem(values: pd.Series) -> float:
    values = values.dropna().astype(float)
    return float(values.std(ddof=1) / math.sqrt(len(values))) if len(values) > 1 else 0.0


def make_derived_statistics() -> dict[str, Any]:
    main = RESULTS / "cross_pilot" / "preregistered-cross-pilot-20260713-v1"
    summary = pd.read_csv(main / "aggregate_summary.csv")
    representation = pd.read_csv(main / "aggregate_representation.csv")
    task = pd.read_csv(main / "aggregate_task_information.csv")
    joined = summary.merge(representation, on=["environment", "condition", "seed"], suffixes=("", "_rep"))
    joined = joined.merge(task, on=["environment", "condition", "seed"], suffixes=("", "_task"))
    rows: list[dict[str, Any]] = []

    metrics = ["task_decodability", "effective_rank", "isotropy_error", "skewness_error", "kurtosis_error"]
    predictive = joined[~joined.condition.isin(["observation_only", "oracle"])]
    for environment, frame in predictive.groupby("environment", sort=False):
        for metric in metrics:
            mask = frame[metric].notna() & np.isfinite(frame[metric])
            sample = frame.loc[mask]
            rows.append(
                {
                    "analysis": "seed_level_correlation_predictive_conditions",
                    "environment": environment,
                    "condition": "predictive_only",
                    "metric": metric,
                    "value": pearson(sample[metric], sample["final_performance"]),
                    "sem": "",
                    "n": len(sample),
                    "unit": "condition×seed",
                    "note": "Pearson r；不跨环境混合；含 raw/transforms/matched，排除 observation_only/oracle",
                }
            )
            rows.append(
                {
                    "analysis": "seed_level_spearman_predictive_conditions",
                    "environment": environment,
                    "condition": "predictive_only",
                    "metric": metric,
                    "value": spearman(sample[metric], sample["final_performance"]),
                    "sem": "",
                    "n": len(sample),
                    "unit": "condition×seed",
                    "note": "Spearman rho；不跨环境混合；聚类结构可能影响相关",
                }
            )

    for environment, frame in summary.groupby("environment", sort=False):
        raw = frame[frame.condition == "raw"].set_index("seed")["final_performance"]
        for condition, part in frame.groupby("condition", sort=False):
            if condition in {"raw", "observation_only", "oracle"}:
                continue
            values = part.set_index("seed")["final_performance"].reindex(raw.index) - raw
            rows.append(
                {
                    "analysis": "paired_difference_vs_raw",
                    "environment": environment,
                    "condition": condition,
                    "metric": "final_performance",
                    "value": float(values.mean()),
                    "sem": sem(values),
                    "n": int(values.notna().sum()),
                    "unit": "paired seed",
                    "note": "condition - raw；E1-E3 accuracy，E4 reward",
                }
            )

    ablations = [
        (
            "bank_compact_minus_mixed",
            RESULTS / "cross_pilot_compact" / "preregistered-cross-pilot-compact-20260713-v1" / "aggregate_summary.csv",
            RESULTS / "cross_pilot_bank_mixed" / "preregistered-cross-pilot-bank-mixed-20260713-v1" / "aggregate_summary.csv",
        ),
        (
            "short_minus_matched_horizon",
            RESULTS / "cross_pilot_short_horizon" / "preregistered-cross-pilot-short-horizon-20260713-v1" / "aggregate_summary.csv",
            RESULTS / "cross_pilot_matched_horizon" / "preregistered-cross-pilot-matched-horizon-20260713-v1" / "aggregate_summary.csv",
        ),
    ]
    for name, left_path, right_path in ablations:
        left = pd.read_csv(left_path)
        right = pd.read_csv(right_path)
        merged = left.merge(right, on=["environment", "condition", "seed"], suffixes=("_left", "_right"))
        merged["difference"] = merged.final_performance_left - merged.final_performance_right
        for (environment, condition), frame in merged.groupby(["environment", "condition"], sort=False):
            rows.append(
                {
                    "analysis": name,
                    "environment": environment,
                    "condition": condition,
                    "metric": "final_performance",
                    "value": float(frame.difference.mean()),
                    "sem": sem(frame.difference),
                    "n": len(frame),
                    "unit": "paired seed",
                    "note": "left - right；预算一致",
                }
            )

    derived = pd.DataFrame(rows)
    derived.to_csv(OUT / "derived_statistics.csv", index=False, encoding="utf-8-sig")
    return {
        "rows": len(derived),
        "main_runs": len(summary),
        "environments": sorted(summary.environment.unique().tolist()),
        "conditions": sorted(summary.condition.unique().tolist()),
        "seeds": sorted(int(value) for value in summary.seed.unique()),
        "nonfinite_or_divergent": int(summary[["nan_count", "inf_count", "divergence_flag"]].to_numpy().sum()),
    }


def main() -> None:
    result = make_result_inventory()
    figures = make_figure_inventory()
    derived = make_derived_statistics()
    summary = {"result_inventory": result, "figure_inventory": figures, "derived_statistics": derived}
    (OUT / "audit_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2, default=lambda value: dict(value)),
        encoding="utf-8",
    )
    print(json.dumps(summary, ensure_ascii=False, indent=2, default=lambda value: dict(value)))


if __name__ == "__main__":
    main()
