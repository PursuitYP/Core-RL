# 报告结构与章节契约

## 总体论证链

严格流式、线性且隔离 oracle 的控制设置 → 在四种部分可观测环境中固定 GVF questions 与 controller，只改变 predictive feature 的统计/几何性质 → 先验证属性是否实现，再比较末窗控制表现 → 检查 task decodability、effective rank、二阶 isotropy 与矩误差是否能解释表现 → 用 core T-maze pilot 与配对消融检验替代解释 → 得出“属性满足与控制收益可分离、收益强烈依赖环境和优化耦合”的有限结论。

## 章节结构

1. **研究背景与问题定义**
   - 进入状态：读者只知道主题是部分可观测的流式强化学习。
   - 离开状态：读者理解实验变量是 predictive feature property，而不是更换问题或 controller；理解报告不做外部文献综述。
   - 证据钩子：C02、C03、C20。
2. **研究问题与可检验假设**
   - 离开状态：读者能区分属性满足、任务信息、控制收益和稳定性四层问题。
   - 证据钩子：`CROSS_ENV_HYPOTHESES.md`、`CROSS_ENV_EXPERIMENT_MATRIX.md`、C08–C14。
3. **四个环境与部分可观测结构**
   - 离开状态：读者理解 E1–E4 各自隐藏变量、动作/回报和 matched prior 目标。
   - 证据钩子：环境源码、实际 config、C04–C07、C10–C11。
4. **预测特征与表征条件**
   - 离开状态：读者知道十条件的输入边界、变换顺序和术语边界。
   - 证据钩子：`predictive.py`、`transforms.py`、`priors.py`、C03、C10、C13。
5. **实验协议、指标与统计口径**
   - 离开状态：读者能复核 run 数、seed、budget、末窗指标、SEM 与 held-out probe 的角色。
   - 证据钩子：主 config/manifest/CSV、C01、C02、C14、C20。
6. **结果完整性与数据质量审计**
   - 离开状态：读者知道哪些批次是主证据，哪些重复/失败/冲突被排除。
   - 证据钩子：C01、C11、C12、C18–C20；`result_inventory.md`、`figure_inventory.md`。
7. **逐环境结果**（全篇主体）
   - 7.1 E1：null result 与 oracle gap（C04、图 1、11）。
   - 7.2 E2：均值方向、巨大 SEM 与 circular phase-order failure（C05、C11、图 1、2、12）。
   - 7.3 E3：局部正向结果及其非普适性（C06、图 1、2、13）。
   - 7.4 E4：raw 末窗最好这一负结果及 decodability–reward 分离（C07、图 1、14）。
   - 7.5 属性、谱与更新诊断（C08、C13–C15、图 3–5、18）。
   - 7.6 bank/horizon 配对消融（C16–C17，数值表，不使用空 panel 图）。
8. **任务可解码性与控制性能的关系**
   - 离开状态：读者理解“可解码”不是“在线控制可用”的同义词。
   - 证据钩子：C08–C09；图 6–9、15–17。
9. **跨环境综合分析**
   - 离开状态：读者看到一致的反例结构，而不是把不同尺度 performance 粗暴合并。
   - 证据钩子：C04–C10、C15–C17；图 2、10。
10. **主要发现**
    - 只综合已验证观察：局部正向、null、负结果、属性门禁失败和可解码性反例并列。
11. **局限性**
    - n=3 pilots、无 remote full、无推断检验、单 seed 几何图、row-level update SEM、E2 gate failure、版本冲突、现有 PNG 非矢量。
12. **结论**
    - 回答主问题：预设属性可改变表征与局部控制，但现有证据不支持跨环境普适增益；更关键的是属性满足、信息可解码和在线可用性必须分开验证。

## 写作与复核契约

- 摘要最后写，只复述正文已稳定的结果。
- 每个数字必须能在 `evidence_map.md` 或主 CSV 中定位。
- 结果段遵循“问题 → 数值/图 → 支持什么 → 不支持什么”。
- 不写 Related Work、参考文献或外部背景事实；用户的本地证据约束优先于通用论文模板。
- 不使用“显著、稳健、普适、证明因果”等超出三 seed pilot 的措辞。
- `whitened` 始终称“二阶变换”；`gaussian_moment` 始终称“探索性在线矩整形”，不作分布保证。
- 图注必须说明 panel/轴、颜色或点线、seed 数、误差条口径和关键局限。
