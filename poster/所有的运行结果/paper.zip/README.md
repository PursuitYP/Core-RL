# 交付说明

本目录包含一份完全基于仓库既有 artifacts 的中文研究报告。生成过程没有联网、没有外部引用、没有运行新的 RL 训练，也没有以报告任务修改原始项目文件。科学证据冻结在已保存的正式主批次、core pilot v3、属性 diagnostics 与配对消融；报告生成期间出现的其他未提交源代码/配置变化未被纳入证据。

审计快照于 2026-07-17 01:15:29 冻结。其后并发流程继续写入 `results/local_validation_20260717`、`results/smoke/overnight-extension-regression-20260717` 等目录；终检时结果树已增至 8,676 个文件。快照后创建或修改的 2,243 个文件（含 144 张图片）未追加入报告，因为它们不是任务开始时已有材料，也未经过同一冻结审计。

## 主要交付

- `report.md`：完整中文报告，12 节，含摘要、4 张表、18 张正文图及逐图中文图注与解释。
- `report.tex`：由 `report.md` 确定性生成的 XeLaTeX 源码。
- `report.pdf`：已编译并逐页渲染核验的 48 页 PDF。
- `figures/`：仅包含正文实际使用的 18 张图片副本；原结果图未改写。
- `result_inventory.md`：对 `results/` 下 6,694 个文件的逐文件用途、来源、哈希、重复与冲突清单。
- `figure_inventory.md`：对 392 张候选图片的逐图 QA、证据用途与采用/排除决定。
- `evidence_map.md`：重要主张到本地字段、表、manifest、图与措辞边界的映射。
- `report_outline.md`：报告论证链、章节契约与图表顺序。
- `derived_statistics.csv`：从已有 CSV 重算的环境内描述性相关、同 seed 配对差和消融差值，共 80 行。
- `audit_summary.json`：审计计数和批次级摘要。
- `audit_existing_results.py`：只读扫描 `results/` 并生成清单/派生统计的脚本。
- `build_latex.py`：无第三方 Markdown 转换依赖的 `report.md`→`report.tex` 生成器。
- `build_log.txt`：审计、编译、渲染与终检记录。

## 证据与图片口径

- 主 cross-pilot：4 environments × 10 conditions × 3 seeds = 120/120 runs；总 interactions 1,680,000。
- 正文图：18 张；候选但未进入正文 374 张。其中 320 张直接标记排除，54 张保留为补充候选但为避免重复未放入最终 `figures/`。
- 未用图的主要原因：217 张为逐字节重复副本，90 张来自 smoke/失败/非正式批次，45 张为配对消融重复视图而正文改用数值表，11 张学习曲线拥挤且有伪影，9 张仅作补充门禁，2 张含 n=0 空 panel。
- `update_norm_stability.png` 的误差条不是 seed-level SEM，只作定性诊断；E1–E4 latent 专图主要为 matched seed 0。

## 重建命令

在本目录中运行：

```powershell
python build_latex.py
xelatex --disable-installer -interaction=nonstopmode -halt-on-error report.tex
xelatex --disable-installer -interaction=nonstopmode -halt-on-error report.tex
```

`--disable-installer` 用于确保构建不会自动安装新依赖。当前源码只依赖本机已有的 XeLaTeX base、`fontspec` 与 `graphicx`。若系统缺少这些组件，保留 `report.tex` 并参照 `build_log.txt` 中的原始错误处理，不应由本任务自动安装。

## 复核入口

先读 `evidence_map.md` 确认主张边界，再读 `report.md`；若需追踪任一数字或图片，分别查 `result_inventory.md`、`derived_statistics.csv` 与 `figure_inventory.md`。`report.tex` 不应手工单独修改；修改 `report.md` 后重新运行 `build_latex.py`，以保持 Markdown、LaTeX 与 PDF 一致。
