# 证据—主张映射

> 本文件先于正文建立。所有结论仅绑定到本仓库已有代码、配置、结果表、manifest、日志和图片；不使用互联网、外部文献或新训练结果。数值默认报告均值 ± 跨 seed 标准误（SEM），除非另有说明。

## 证据层级与解释边界

1. **主证据**：`results/cross_pilot/preregistered-cross-pilot-20260713-v1`，四环境 × 十条件 × 三 seed，共 120/120 个成功 run；用于跨环境主结论。
2. **核心复核证据**：`results/pilot/preregistered-pilot-20260713-v3`，单一 T-maze 十条件 × 三 seed，共 30/30 个成功 run；用于“可解码性不充分”的独立实例。
3. **配对消融证据**：compact/mixed bank 与 short/matched horizon 四个批次；每个可比单元为同环境、同条件、同 seed 配对，n=3。
4. **属性门禁证据**：`results/diagnostics/cross_environment/preregistered-cross-20260713-v2` 与 `results/diagnostics/preregistered-20260713-v3`；用于验证变换的命名属性和失败项，不用于证明控制优势。
5. **补充或排错证据**：smoke、旧 pilot、旧 diagnostics 与失败批次；用于 provenance、守卫和冲突核对，不计作独立科学重复。

## 逐主张映射

| ID | 拟写主张 | 本地证据与字段 | 范围/样本单位 | 证据强度 | 允许措辞 | 禁止措辞与局限 |
|---|---|---|---|---|---|---|
| C01 | 主 cross-pilot 结果包完整，且没有记录到 NaN、Inf 或 divergence。 | `results/cross_pilot/preregistered-cross-pilot-20260713-v1/manifest.json` 的 `expected_runs=120`、`recorded_runs=120`、`exit_status=ok`；`aggregate_summary.csv` 的 `nan_count`、`inf_count`、`divergence_flag`；`condition_summary.csv`。 | 4 环境 × 10 条件 × seeds 0–2；120 run，1,680,000 interactions。 | 强（完整正式批次） | “在该三 seed pilot 中完整且数值稳定。” | 不得称为 full profile、远程全量结果或普适稳定性证明。 |
| C02 | 实验是严格流式、线性、单遍更新；诊断 probe 不反馈给智能体。 | `src/streaming_rl_feature_geometry/cross_experiment.py` 的 transition/update 顺序；`predictive.py`、`transforms.py`、`controller.py`；`CROSS_ENV_IMPLEMENTATION_REPORT.md` 的 causal-order 与 isolation 说明；相关测试文件。 | 实现与已保存运行配置。 | 强（实现 + 文档 + 测试闭环） | “实现按当前 transition 一次处理、变换仅使用当前/过去统计，held-out probe 仅分析。” | 不得把实现约束写成对所有未来修改的保证；不得把 probe 指标说成训练目标。 |
| C03 | Oracle 是隔离的上界参照，不能与 predictive-feature 方法混作同一输入来源。 | `cross_experiment.py` 中 oracle 分支；`cross_env.py`/环境类的 `oracle_features`；`aggregate_summary.csv` 的 oracle rows。 | 四环境、三 seed。 | 强 | “oracle 仅作隔离参照；预测特征方法不读取 oracle state。” | 不得把 oracle 增益归因于某种 predictive geometry。 |
| C04 | E1 T-maze 中，非 oracle 条件的末窗准确率都接近机会水平，未见可重复提升。 | 主 `condition_summary.csv`：raw 0.506±0.009、whitened 0.506±0.011、matched 0.497±0.015、gaussian_moment 0.497±0.021；oracle 0.979±0.004。 | E1，n=3 seeds，末窗 500 decisions。 | 中（n=3） | “观察到非 oracle 条件高度重叠、接近 0.5。” | 不得写“统计无差异”或“证明所有几何都无效”；未做推断检验。 |
| C05 | E2 Ringworld 中 standardized、whitened、gaussian_moment 的均值高于 raw，但 seed 间不确定性很大。 | 主 `condition_summary.csv`：raw 0.493±0.003；standardized 0.622±0.086；whitened 0.613±0.119；gaussian_moment 0.610±0.185；`derived_statistics.csv` 的 paired differences。 | E2，n=3 paired seeds。 | 中偏弱（大 SEM） | “均值方向为正，但三 seed 证据不稳定。” | 不得称“显著提升”“稳健提升”或跨环境规律。 |
| C06 | E3 Two-loop 中 gaussian_moment、whitened、matched、standardized 均高于 raw；其中 gaussian_moment 的局部均值最高。 | 主 `condition_summary.csv`：raw 0.495±0.004；standardized 0.613±0.016；matched 0.637±0.039；whitened 0.697±0.011；gaussian_moment 0.797±0.068；`derived_statistics.csv` 中相对 raw 的配对差。 | E3，n=3 paired seeds。 | 中（局部一致但 n 小） | “在该环境和预算下观察到较大正向差值。” | 不得称为普适最优、因果机制已确定或 distributional guarantee。 |
| C07 | E4 Hidden-velocity 中 raw 的末窗 reward 最高；所有变换/先验条件的均值都低于 raw。 | 主 `condition_summary.csv`：raw −0.063±0.018；observation_only −0.079±0.003；oracle −0.085±0.009；unit_sphere −0.084±0.019；whitened −0.087±0.021；gaussian_moment −0.088±0.014；matched −0.098±0.010；standardized −0.121±0.042；`derived_statistics.csv`。 | E4，n=3 paired seeds；reward 越大越好。 | 中 | “在末窗 reward 上 raw 最好；变换没有带来正向结果。” | 不得忽略负结果；不得因 oracle 末窗不占优而声称 oracle state 无信息。 |
| C08 | 特征属性满足与控制改善可以分离：更低 isotropy error、更高 effective rank 或更小矩误差都不是高表现的充分条件。 | 主 `aggregate_representation.csv`、`aggregate_task_information.csv`、`aggregate_summary.csv`；`property_fulfillment_summary.png`、`isotropy_vs_control.png`、`effective_rank_vs_control.png`、`moment_error_vs_control_performance.png`；`derived_statistics.csv` 的环境内相关。 | 每环境 predictive-only 8 条件 × 3 seeds = 24 点；相关不跨环境混合。 | 中（描述性） | “散点与环境内相关未呈现一致单调对应；这些属性单独不充分。” | 不得写“属性与性能完全无关”或因果否定；condition×seed 点有聚类结构，n=24 不是 24 个独立方法。 |
| C09 | Task decodability 也不是控制成功的充分条件。 | 主 `decodability_vs_control.png` 与相应 CSV；core pilot v3 `aggregate_hidden_state.csv`、`condition_summary.csv`、`accuracy_vs_cue_decodability.png`：trace_only junction cue decodability=1.000（3/3 seed），末窗 accuracy=0.567±0.009；oracle=0.985±0.006。 | 主 cross-pilot 环境内点 + core T-maze 3 seeds。 | 中偏强（两套已有批次相互印证） | “可线性解码的信息可与在线控制收益分离；可解码性不充分。” | 不得声称可解码性不必要、没有作用或是因果中介。 |
| C10 | Matched prior 实现了预先命名的输出形状，但不跨环境一致占优。 | `priors.py`；cross diagnostics v2；主 `task_matched_vs_generic.png`、`environment_specific_latent_geometry.png` 与 `condition_summary.csv`。 | 四环境、三 seed；几何可视化主要为 matched seed 0。 | 中 | “先验形状被实现；控制结果依环境而异。” | 单 seed 图不得作为跨 seed 稳定性证据；不得把形状外观等同于 latent 语义正确。 |
| C11 | E2 circular prior 的单位圆约束通过，但真实流相位顺序门禁失败。 | `results/diagnostics/cross_environment/preregistered-cross-20260713-v2/pass_fail_summary.csv`：mean_radius=1.000000；phase alignment=0.2406，shuffled=0.0098，阈值 0.3，False；manifest 29/30、failed；`e2_circular_phase.png`。 | 固定 diagnostics seed 20260713，5,000 real-stream samples。 | 强（明确 preregistered gate） | “圆约束满足，但相位顺序不足以通过预设门禁。” | 不得称 E2 circular semantic property 已完全实现；不得隐去 failed 顶层状态。 |
| C12 | Synthetic 属性检查全部通过，但不能替代真实流检查。 | cross diagnostics v2 `pass_fail_summary.csv` 的 synthetic rows；core diagnostics v3 12/12；`gaussian_synthetic_histograms.png`。 | 固定诊断流；非 RL 控制 run。 | 强（属性测试） | “合成流验证实现方向和数值有限性。” | 不得外推为真实环境中同样成立或控制性能保证。 |
| C13 | Whitening 是二阶变换；gaussian_moment 只是在线矩整形扩展。 | `transforms.py`；diagnostics v3；`gaussian_synthetic_histograms.png`；AGENTS.md/实现文档术语。 | 实现与诊断。 | 强 | “whitening 降低二阶 isotropy error”；“gaussian_moment 降低部分偏度/峰度误差”。 | 不得称 whitening 为 Gaussian transform；不得说 gaussian_moment 保证高斯分布或完整分布匹配。 |
| C14 | 变换会改变控制更新尺度，但现有 update-norm 图只适合定性比较。 | 主 `aggregate_updates.csv`、`update_norm_stability.png`；绘图实现中的行级 `_mean_sem`。 | 聚合 update rows；误差条不是先按 seed 聚合后的 seed 间 SEM。 | 中偏弱 | “更新尺度存在条件依赖差异；图作定性稳定性诊断。” | 不得把误差条解释为独立 seed 不确定性，不得据此作显著性判断。 |
| C15 | 协方差谱揭示秩亏和二阶变换差异，但谱形本身不能推出任务信息或控制收益。 | 主 `covariance_eigenvalue_spectra.png`、`aggregate_representation.csv`。 | 四环境 × 条件；图为跨 seed 均值曲线，无误差条。 | 中 | “谱形与变换目标一致/不一致。” | 不得单凭谱图声称控制机制已解释。 |
| C16 | Compact 与 mixed bank 的多数配对差较小或不确定；hidden_velocity matched 的差值也有大 SEM。 | compact/mixed 两批 `aggregate_summary.csv`；`derived_statistics.csv`：例如 hidden_velocity matched compact−mixed=0.082±0.092。 | 四环境 × raw/matched × 3 paired seeds。 | 中偏弱 | “未观察到跨环境一致的大 bank 效应。” | 不得称严格等价或无效。 |
| C17 | Short-vs-matched horizon 消融在 E2 matched 上方向为负但高度不确定。 | short/matched-horizon 两批 `aggregate_summary.csv`；`derived_statistics.csv`：ringworld matched short−matched=−0.141±0.140。 | E1/E2 × raw/matched × 3 paired seeds。 | 弱到中 | “方向性结果不稳定，不足以锁定 horizon 机制。” | 不得写确定性 horizon 结论；空 E3/E4 panel 不进入正文。 |
| C18 | 现有结果包含大量逐字节重复副本，smoke/旧批次不能增加独立证据量。 | `result_inventory.md`：6,694 文件、3,641 唯一哈希、3,053 重复副本；`figure_inventory.md`：392 图、168 唯一哈希、224 重复副本。 | 全 `results/` 逐文件 SHA-256。 | 强（穷举审计） | “重复副本用于 provenance，不计作独立重复实验。” | 不得把文件数或图片数当作样本量。 |
| C19 | Core pilot v3 是正式可用版本；v2 的 manifest 与工作日志存在冲突。 | v3 manifest/summary：30/30、ok；v2 manifest：30/30、ok；`docs/work_log.md` 称 v2 被中断。 | 版本级 provenance。 | 强（冲突已定位） | “正文仅用 v3，避免依赖冲突版本。” | 不得用 v2 加倍样本量，也不得未经解释采用 v2。 |
| C20 | 当前证据只是本地三 seed pilots 与 diagnostics，没有 remote full run。 | 实际 manifest/profile/config；`CROSS_ENV_RESULTS.md`、远程指南中 full 尚待执行的状态；仓库结果目录审计。 | 当前已有 artifacts。 | 强 | “所有科学结论限定在现有 pilot 预算。” | 不得称 full study、最终统计结论或大样本验证。 |

## 数值口径

- 主矩阵 E1–E3 的 `final_performance` 为末窗 accuracy；E4 为末窗 reward，且 reward 越大越好。不同环境的原始 performance 不做合并均值。
- 主图误差条在 `condition_summary.csv` 中对应跨 seeds 0、1、2 的 SEM；n=3。
- `derived_statistics.csv` 的 paired difference 均以同 seed 配对，写作 “condition − raw” 或 “left − right”；这些是描述性均值 ± SEM，不附显著性标签。
- 环境内相关仅用于辅助描述：每环境 predictive-only 条件为 raw、rms_raw、standardized、whitened、gaussian_moment、unit_sphere、sparse、matched，共 8×3=24 个 condition×seed 点；不跨环境混合原始尺度。
- 单 seed E1–E4 latent 可视化只展示诊断样本，必须在图注中标注 seed 0 和不可代表跨 seed 稳定性。

## 已排除的证据用法

- 不使用拥挤且在 two_loop panel 出现长对角伪影的 `control_learning_curves_by_environment.png`。
- 不使用 short/matched-horizon 中含 E3/E4 空 panel（n=0）的四面板图；消融只使用 CSV 配对表。
- 不把 smoke、失败 run、重复目录或旧版本拼接成更大的样本量。
- 不用 proposal 中的计划预算替代实际 `config.json`：主矩阵实际 interactions 为 T-maze 12,000、Ringworld 12,000、Two-loop 14,000、Hidden-velocity 18,000。
- 不从当前未提交的源代码/配置变化提取任何新事实；报告证据冻结于已盘点的既有结果与其保存配置。
- 全量清单冻结时间为 2026-07-17 01:15:29。冻结后并发写入的 `results/local_validation_20260717`、`results/smoke/overnight-extension-regression-20260717` 等 post-snapshot artifacts 不属于任务开始时已有证据，不追加入样本量或图片候选数。
