"""Generate report.tex from the audited Markdown report without external dependencies."""

from __future__ import annotations

import re
from pathlib import Path


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "report.md"
TARGET = ROOT / "report.tex"


PREAMBLE = r"""\documentclass[11pt,a4paper]{article}
\usepackage{fontspec}
\setmainfont{Microsoft YaHei}
\setsansfont{Microsoft YaHei}
\setmonofont{Microsoft YaHei}
\XeTeXlinebreaklocale "zh"
\XeTeXlinebreakskip = 0pt plus 1pt
\usepackage{graphicx}
\setlength{\oddsidemargin}{0pt}
\setlength{\evensidemargin}{0pt}
\setlength{\topmargin}{-0.5in}
\setlength{\textwidth}{6.3in}
\setlength{\textheight}{9.3in}
\setlength{\parindent}{2em}
\setlength{\parskip}{0.35em}
\setlength{\emergencystretch}{2em}
\sloppy
\renewcommand{\arraystretch}{1.25}
\pagestyle{plain}
\title{严格流式部分可观测强化学习中\\预测特征统计与几何性质的现有证据审计}
\author{基于仓库既有结果的审计报告}
\date{2026年7月17日}
\begin{document}
\maketitle
\begin{center}
\small 证据范围：本地既有三 seed pilots、属性 diagnostics 与配对消融；无外部文献、无新增训练。
\end{center}
\tableofcontents
\clearpage
"""


POSTAMBLE = "\\end{document}\n"


def escape_plain(text: str) -> str:
    replacements = {
        "\\": r"\textbackslash{}",
        "&": r"\&",
        "%": r"\%",
        "#": r"\#",
        "_": r"\_",
        "{": r"\{",
        "}": r"\}",
        "~": r"\textasciitilde{}",
        "^": r"\textasciicircum{}",
    }
    return "".join(replacements.get(char, char) for char in text)


def inline(text: str) -> str:
    tokens: list[str] = []

    def stash(value: str) -> str:
        token = f"@@TOKEN{len(tokens)}@@"
        tokens.append(value)
        return token

    text = re.sub(
        r"`([^`]+)`",
        lambda match: stash(r"\texttt{" + escape_plain(match.group(1)) + "}"),
        text,
    )
    text = re.sub(r"\$([^$]+)\$", lambda match: stash("$" + match.group(1) + "$"), text)
    text = re.sub(
        r"\*\*([^*]+)\*\*",
        lambda match: stash(r"\textbf{" + escape_plain(match.group(1)) + "}"),
        text,
    )
    text = escape_plain(text)
    for index, value in enumerate(tokens):
        text = text.replace(f"@@TOKEN{index}@@", value)
    return text


def strip_caption_marker(text: str, kind: str) -> str:
    text = text.strip()
    text = re.sub(r"^\*\*|\*\*$", "", text)
    text = re.sub(r"^\*|\*$", "", text)
    return re.sub(rf"^{kind}\s*\d+\s*[　 ]*", "", text).strip()


def render_table(rows: list[list[str]], caption: str) -> str:
    ncols = len(rows[0])
    width = 0.86 / ncols
    colspec = "|" + "|".join([rf"p{{{width:.3f}\textwidth}}"] * ncols) + "|"
    rendered = [
        r"\begin{table}[p]",
        r"\centering",
        r"\caption{" + inline(caption) + "}",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{2pt}",
        rf"\begin{{tabular}}{{{colspec}}}",
        r"\hline",
        " & ".join(r"\textbf{" + inline(cell) + "}" for cell in rows[0]) + r" \\",
        r"\hline",
    ]
    for row in rows[2:]:  # skip Markdown separator row
        rendered.append(" & ".join(inline(cell) for cell in row) + r" \\")
        rendered.append(r"\hline")
    rendered.extend([r"\end{tabular}", r"\end{table}", r"\clearpage"])
    return "\n".join(rendered)


def render_figure(path: str, caption: str) -> str:
    clean_caption = strip_caption_marker(caption, "图")
    return "\n".join(
        [
            r"\begin{figure}[p]",
            r"\centering",
            rf"\includegraphics[width=\textwidth,height=0.72\textheight,keepaspectratio]{{{path}}}",
            r"\caption{" + inline(clean_caption) + "}",
            r"\end{figure}",
            r"\clearpage",
        ]
    )


def convert(markdown: str) -> str:
    lines = markdown.splitlines()
    out: list[str] = [PREAMBLE]
    i = 1  # title is supplied by the preamble
    pending_table_caption = ""
    list_kind: str | None = None
    in_abstract = False

    def close_list() -> None:
        nonlocal list_kind
        if list_kind:
            out.append(r"\end{" + list_kind + "}")
            list_kind = None

    while i < len(lines):
        line = lines[i].rstrip()
        stripped = line.strip()
        if not stripped:
            close_list()
            i += 1
            continue

        if stripped == "## 摘要":
            close_list()
            out.append(r"\begin{abstract}")
            in_abstract = True
            i += 1
            continue

        if stripped.startswith("## "):
            close_list()
            if in_abstract:
                out.append(r"\end{abstract}")
                in_abstract = False
            title = re.sub(r"^\d+\.\s*", "", stripped[3:])
            out.append(r"\section{" + inline(title) + "}")
            i += 1
            continue

        if stripped.startswith("### "):
            close_list()
            title = re.sub(r"^\d+(?:\.\d+)*\s*", "", stripped[4:])
            out.append(r"\subsection{" + inline(title) + "}")
            i += 1
            continue

        if stripped.startswith("**表 "):
            pending_table_caption = strip_caption_marker(stripped.replace("**", ""), "表")
            i += 1
            continue

        if stripped.startswith("|"):
            close_list()
            rows: list[list[str]] = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                rows.append([cell.strip() for cell in lines[i].strip().strip("|").split("|")])
                i += 1
            out.append(render_table(rows, pending_table_caption or "结果表"))
            pending_table_caption = ""
            continue

        image_match = re.match(r"!\[[^]]*\]\(([^)]+)\)", stripped)
        if image_match:
            close_list()
            j = i + 1
            while j < len(lines) and not lines[j].strip():
                j += 1
            caption = lines[j].strip() if j < len(lines) and lines[j].strip().startswith("*") else ""
            out.append(render_figure(image_match.group(1), caption))
            i = j + 1 if caption else i + 1
            continue

        if stripped == "$$":
            close_list()
            math_lines: list[str] = []
            i += 1
            while i < len(lines) and lines[i].strip() != "$$":
                math_lines.append(lines[i])
                i += 1
            out.extend([r"\[", "\n".join(math_lines), r"\]"])
            i += 1
            continue

        ordered = re.match(r"^(\d+)\.\s+(.*)", stripped)
        bullet = re.match(r"^-\s+(.*)", stripped)
        if ordered or bullet:
            desired = "enumerate" if ordered else "itemize"
            if list_kind != desired:
                close_list()
                out.append(r"\begin{" + desired + "}")
                list_kind = desired
            content = ordered.group(2) if ordered else bullet.group(1)
            out.append(r"\item " + inline(content))
            i += 1
            continue

        close_list()
        paragraph = [stripped]
        i += 1
        while i < len(lines):
            nxt = lines[i].strip()
            if not nxt or nxt.startswith(("## ", "### ", "|", "![", "**表 ", "$$")):
                break
            if re.match(r"^(?:\d+\.|-)\s+", nxt):
                break
            paragraph.append(nxt)
            i += 1
        out.append(inline(" ".join(paragraph)) + r"\par")

    close_list()
    if in_abstract:
        out.append(r"\end{abstract}")
    out.append(POSTAMBLE)
    return "\n".join(out)


def main() -> None:
    TARGET.write_text(convert(SOURCE.read_text(encoding="utf-8")), encoding="utf-8")
    print(f"generated {TARGET} from {SOURCE}")


if __name__ == "__main__":
    main()
