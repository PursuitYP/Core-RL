# 严格流式部分可观测强化学习中预测特征统计与几何性质的现有证据审计

## 摘要

本报告审计预设统计与几何性质能否改善严格流式、线性、部分可观测强化学习中的预测特征。实验固定 GVF questions 与控制器，只在 T-maze、Ringworld、Two-loop 和 Hidden-velocity 四个环境中改变 raw、尺度/标准化、二阶 whitening、探索性 gaussian_moment、单位球、稀疏和 task-matched priors，并以 observation-only 与隔离 oracle 为参照。主 cross-pilot 完成 4 环境×10 条件×3 seeds 的 120/120 runs，共 1,680,000 interactions，未记录 NaN、Inf 或 divergence。结果高度依赖环境：E1 的非 oracle 条件接近机会水平；E2 的 standardized、whitened 与 gaussian_moment 均值高于 raw，但 SEM 很大；E3 中 gaussian_moment、whitened、matched 与 standardized 相对 raw 的 paired differences 分别为 0.302±0.069、0.201±0.007、0.141±0.035 和 0.118±0.012；E4 则由 raw 取得最高末窗 reward（−0.063±0.018），所有变换/先验均低于 raw。属性门禁进一步表明，E2 circular 输出满足单位圆约束，却未通过真实流 phase-order 阈值（0.2406<0.3）。环境内 task decodability 与控制表现相关均弱；core T-maze 中 trace_only 的 junction cue decodability 为 1.0，但末窗 accuracy 仅 0.567±0.009。现有三 seed pilot 因而不支持任何属性的跨环境普适优势；它支持的更有限结论是：属性满足、任务信息可解码和在线控制可用性是必须分别验证的三个层次。

## 1. 研究背景与问题定义

部分可观测控制的困难不只在于当前观测缺少隐藏状态，还在于历史信息即使进入了预测特征，也未必能被在线控制器有效使用。本报告关注一个更窄且可检验的问题：在严格流式、非深度、线性强化学习系统中，给预测特征预先规定统计或几何性质，是否能够改善下游控制？这里的实验变量是预测特征的表征性质；广义价值函数（general value function, GVF）问题集合和线性控制器保持不变，除非已有的预登记消融明确改变预测 bank 或 horizon。

报告不把“性质被实现”“隐藏变量可从特征中线性解码”和“控制表现提高”视为同一件事。三者分别对应表征约束、离线诊断和在线决策。一个特征向量可以有更接近单位协方差的二阶结构，也可以允许 held-out 线性 probe 恢复任务变量，但控制器仍可能因尺度、条件数、时序信用分配或短预算下的优化耦合而得不到收益。相反，局部控制收益也不能自动证明预设性质是其原因。

现有仓库提供了四类互补环境、十种主表征条件、三 seed 主 pilot、核心 T-maze 复核、两组配对消融以及属性 diagnostics。它们足以进行受限的机制审计，但不构成 remote full study。报告因此采用“观察到”“与某一解释一致”“不足以支持”一类措辞；不使用统计显著性、普适优越性或因果证明语言。

本报告的证据全部来自本地已有 artifacts。主科学证据冻结在 `results/cross_pilot/preregistered-cross-pilot-20260713-v1` 保存的配置、manifest 和 CSV；正文不吸收报告生成期间出现的未提交源代码或配置变化。完整逐文件哈希、重复项、失败批次和图像选择分别见 `result_inventory.md`、`evidence_map.md` 与 `figure_inventory.md`。

## 2. 研究问题与可检验假设

研究问题分为四层。

**RQ1：预设性质是否在在线真实流中实现？** 对标准化、二阶白化、单位球、稀疏化和 task-matched prior，首先检查均值、方差、相关、协方差谱、半径、active dimensions 与命名结构。属性 diagnostics 是进入控制解释的门禁，而不是控制优势证据。

**RQ2：预测特征是否携带任务相关信息？** 使用 held-out 线性 probe 估计 cue、phase、loop identity 或 velocity 的可恢复程度。probe 不回传梯度、不改变动作，也不更新预测器；它只回答“保存下来的特征是否含有线性可读信息”。

**RQ3：属性或信息是否改善严格流式控制？** E1–E3 以末窗决策准确率为主，E4 以末窗 reward 为主。比较必须在同一环境、同一 seed、同一预算内进行；不同环境的 performance 原始尺度不合并。

**RQ4：若控制表现变化，哪类解释仍与证据一致？** 通过 raw 对照、observation-only、oracle、bank compact-vs-mixed、short-vs-matched horizon，以及 update norm、effective rank、isotropy error 和矩误差分析，区分“表征性质本身”“任务信息”“优化尺度”和“问题/时间尺度”几种可能解释。

据此，现有材料允许检验的工作假设是：某些统计或几何性质可能在特定环境中改善学习，但单一性质不应被预设为跨环境充分条件；task-matched prior 只有在输出结构与真实流语义同时对齐时才可能形成优势；可解码性高仍可能与控制失败并存。报告将正向、零效应、负效应和门禁失败置于同一证据框架中。

## 3. 四个环境与部分可观测结构

表 1 汇总四个环境的隐藏结构、控制信号、实际主 pilot 预算与 matched prior。所有环境都是 continuing stream；不存在 episode replay 或 future-data fitting。

**表 1　四环境的任务结构与实际运行预算。** `interactions` 来自主结果目录保存的 `config.json`，不是 proposal 中的计划值。

| 环境 | 部分可观测来源 | 动作与反馈 | 主指标 | interactions | matched prior |
|---|---|---|---|---:|---|
| E1 T-maze | cue 只在走廊起点出现；junction 对两类 cue 给出相同观测 | junction 二动作；正确 +1，错误 −1 | 末窗 accuracy ↑ | 12,000 | 2 维 simplex |
| E2 Ringworld | 两个 decision phase 共享观测；landmark 只允许从因果历史推断 phase | 二动作；两 decision phase 的正确动作相反 | 末窗 accuracy ↑ | 12,000 | 2 维 circular block |
| E3 Two-loop | loop identity cue 短暂出现；不同长度 loop 的 decision 观测混叠 | 二动作；正确动作等于 loop identity | 末窗 accuracy ↑ | 14,000 | identity simplex + phase circle |
| E4 Hidden-velocity | 观测含位置但不含速度；动力学有惯性、噪声和反射边界 | 三动作；reward 为位置、速度与控制 effort 总成本的负值 | 末窗 reward ↑ | 18,000 | anisotropic scaling |

E1 的一条 trial 依次经过 cue、五个 corridor position、junction 和 outcome。junction 的当前观测不能区分左右 cue，只有历史信息可决定正确动作。outcome 提供延迟 cue echo 作为预测学习的 cumulant 来源，但它在 junction 动作之后出现，因此不能作为同一步的未来泄漏。

E2 是长度 12 的确定性环。相位 0 和 6 是不同 landmark，位置 3 和 9 是共享同一 observation 的 decision states，且要求相反动作。因果历史理论上可区分相位，但 matched circular 输出是否按真实 phase 排序必须另做门禁；“点落在单位圆上”本身不回答排序问题。

E3 在长度 8 和 10 的两个循环之间切换。每段开始时出现 identity cue，之后经过 generic/landmark observations，在各自半周期处决策。控制既需要记住 identity，又可能受 phase 表征影响；因此 matched 条件将前两维映射到 identity simplex、另两维映射到 phase circle。

E4 的观测为 bias、归一化位置和左右位置指示，不含速度；oracle 才含归一化位置与速度。动作 0、1、2 对应负、零、正加速度。reward 等于位置平方成本、速度平方成本和动作成本之和的负值，所以数值越大越好。该环境的所有 decision steps 都产生连续控制反馈，不能把其 reward 与前三个环境的 decision accuracy 合并平均。

## 4. 预测特征与表征条件

主矩阵在每个环境运行同样的十种条件。

- `observation_only`：控制器只使用当前 observation，不接收预测特征。
- `oracle`：控制器使用隔离的隐藏状态表示，仅作可达上界/诊断参照；oracle state 不进入其他条件。
- `raw`：直接使用在线 GVF 预测向量。
- `rms_raw`：以因果运行 RMS 做全局尺度归一，不改变相关结构的目标。
- `standardized`：对各维做因果均值与方差标准化。
- `whitened`：用截至前一时刻的在线二阶统计降低协方差的 isotropy error；这是**二阶变换**，不是“高斯变换”。
- `gaussian_moment`：在二阶处理基础上进行探索性的在线偏度/峰度矩整形；它只以矩误差为目标，不提供分布为高斯的保证。
- `unit_sphere`：将向量投影到单位范数方向。
- `sparse`：保留固定 top-k 活跃结构。
- `matched`：只对预测向量预先指定的语义索引施加 simplex、circle、block 或 anisotropic 变换；API 不接收 latent label。

预测 bank 为 mixed bank，主配置含 horizons 0.65 与 0.9，`predictive_alpha=0.006`。控制器是线性 on-policy SARSA(λ) 形式，主配置 `epsilon=0.05`、`lambda=0.8`、默认 `gamma=0.98`、`control_alpha=0.006`；E4 单独使用 `gamma=0.95` 和更小的 `control_alpha=0.002`。这些环境特定参数来自预先保存的实际 config，报告不根据 pilot 结果追调。

每个时刻的因果顺序是：基于当前可用特征选动作；环境只推进一次；预测器用刚发生的 transition 更新；以旧统计变换当前/下一特征后再更新统计；控制器以当前 transition 更新。transform 的输出使用更新前的统计状态，随后才吸收当前样本。held-out probe 和 latent diagnostic 只读取已保存的特征与标签，不进入动作、GVF、transform 或 controller 的更新路径。

matched transform 也保持这一顺序。simplex 通过两维 softmax 产生非负且和为 1 的输出；circle 将指定两维单位化；block 拼接 identity simplex 和 phase circle；anisotropic 对因果标准化后的预测向量施加预声明尺度比。命名结构被实现不意味着其坐标与真实 latent 已正确对齐，这正是后续 real-stream diagnostics 的作用。

## 5. 实验协议、指标与统计口径

主 cross-pilot 使用 seeds 0、1、2；四环境各十条件，共 120 runs。总交互数为

$$
3\times 10\times(12000+12000+14000+18000)=1{,}680{,}000.
$$

末窗长度为 500。E1–E3 的 `final_window_accuracy` 是末窗 decision correctness 均值；E4 的 `final_window_reward` 是末窗逐步 reward 均值。表格中的 `均值 ± SEM` 按三个 seed 计算，SEM 为样本标准差除以 $\sqrt{3}$。n=3 只适合描述方向和跨 seed 波动，不足以支撑常规显著性语言。

表征指标在 burn-in 后的保存样本上计算，包括 active dimensions、near-zero fraction、均值误差、方差范围、平均绝对相关、effective rank、isotropy error、condition number、偏度误差、峰度误差和范数统计。task-information 指标由环境特定 held-out probe 给出：E1 cue、E2 phase、E3 identity/phase、E4 velocity。它们是分析 probe，而非训练 loss。

描述性相关只在每个环境内部计算，排除 `observation_only` 和 `oracle`，保留 8 个 predictive conditions × 3 seeds = 24 个 condition×seed 点。Pearson $r$ 与 Spearman $\rho$ 都报告，但这些点具有 condition 聚类结构，不能当作 24 个相互独立的方法样本。不同环境的 accuracy 与 reward 不混合做总体相关。

两组消融采用同 seed 配对差。bank 消融比较 compact 与 mixed；horizon 消融比较 short 与 matched。差值写作 left − right，并报告三个 paired seeds 的均值 ± SEM。消融图中若有 n=0 空 panel，正文不使用该图，只使用对应 CSV 的实际配对单元。

## 6. 结果完整性与数据质量审计

主 cross-pilot 的 manifest 记录 `exit_status=ok`、120/120 runs、干净 Git commit `408dcf6858b5...`。120 个 summary 中 NaN、Inf 和 divergence 的聚合计数均为 0。该结果说明已保存 pilot 在其预算内完整且数值有限，但不能外推为更长 full profile 的稳定性。

全 `results/` 逐文件审计得到 6,694 个文件、3,641 个唯一 SHA-256 和 3,053 个逐字节重复副本；29 个批次/诊断根目录中混有正式 pilot、smoke、旧版本、失败批次和重复部署检查。392 张候选图只有 168 个唯一哈希，224 张是完全重复副本。文件或图片副本不计作额外 seed 或独立科学重复。

属性门禁呈现一项重要失败。cross diagnostics v2 的 30 项检查通过 29 项，顶层状态为 `failed`。唯一失败是 E2 circular prior 的 real-stream phase-order：单位圆半径检查通过（mean radius 1.000000），但 circular phase alignment 为 0.2406，虽高于 shuffled 0.0098，却低于固定门槛 0.3。因此，正文保留“圆约束实现”，同时拒绝“真实相位顺序充分实现”。

core T-maze pilot 的版本 provenance 也有冲突：v2 顶层 manifest 实际记录 30/30、`ok`，而 `docs/work_log.md` 将 v2 描述为中断。为避免把冲突版本加入证据量，正文只采用 v3 的 30/30 runs。v1 的失败来自旧 validator 对 not-applicable 字段的处理问题，也不与 v3 拼接。

图像 QA 排除了两个容易误导的来源。主批次 `control_learning_curves_by_environment.png` 过于拥挤，且 two-loop panel 出现长对角伪影；short/matched-horizon 四面板图包含 E3/E4 的 n=0 空 panel。`update_norm_stability.png` 虽保留作定性诊断，但其误差条按聚合 update rows 计算，不是 seed 间独立 SEM。所有现有图均为 160 dpi PNG，而不是可编辑 SVG，这限制了排版与无损放大。

最后，仓库没有可确认的 remote full 结果。正式结论仅覆盖本地三 seed pilots、属性 diagnostics 和已有配对消融。报告不把 full 配置文件、远程指南或未执行计划当作实验结果。

本次全量清单在 2026-07-17 01:15:29 完成并冻结。其后并发流程继续写入 `results/local_validation_20260717` 与 `results/smoke/overnight-extension-regression-20260717` 等目录；终检时 `results/` 已由快照的 6,694 个文件增至 8,676 个，并有 2,243 个文件的创建或修改时间晚于冻结点（其中 144 张图片）。这些 post-snapshot smoke/local-validation artifacts 不是任务开始时已有材料，未被追加入本报告，以避免把并发新实验与既定证据混合。

## 7. 逐环境结果

表 2 给出主矩阵全部条件的末窗结果。前三列是 accuracy，E4 列是 reward；四列不能横向求平均。表中最重要的不是单一最大值，而是方向随环境改变：相同二阶或矩变换在 E2/E3 可以呈现正向均值，在 E1 接近零效应，在 E4 则低于 raw。

**表 2　主 cross-pilot 的末窗表现（均值 ± 跨 seed SEM，n=3）。** E1–E3：accuracy ↑；E4：reward ↑。粗体仅标示每环境数值最高的条件，不表示统计显著。

| condition | E1 T-maze accuracy ↑ | E2 Ringworld accuracy ↑ | E3 Two-loop accuracy ↑ | E4 Hidden-velocity reward ↑ |
|---|---:|---:|---:|---:|
| observation_only | 0.505 ± 0.012 | 0.501 ± 0.004 | 0.471 ± 0.003 | −0.079 ± 0.003 |
| oracle | **0.979 ± 0.004** | **0.975 ± 0.001** | **0.977 ± 0.004** | −0.085 ± 0.009 |
| raw | 0.506 ± 0.009 | 0.493 ± 0.003 | 0.495 ± 0.004 | **−0.063 ± 0.018** |
| rms_raw | 0.505 ± 0.001 | 0.493 ± 0.005 | 0.501 ± 0.013 | −0.117 ± 0.013 |
| standardized | 0.498 ± 0.007 | 0.622 ± 0.086 | 0.613 ± 0.016 | −0.121 ± 0.042 |
| whitened | 0.506 ± 0.011 | 0.613 ± 0.119 | 0.697 ± 0.011 | −0.087 ± 0.021 |
| gaussian_moment | 0.497 ± 0.021 | 0.610 ± 0.185 | 0.797 ± 0.068 | −0.088 ± 0.014 |
| unit_sphere | 0.503 ± 0.010 | 0.503 ± 0.003 | 0.471 ± 0.004 | −0.084 ± 0.019 |
| sparse | 0.487 ± 0.020 | 0.496 ± 0.011 | 0.471 ± 0.007 | −0.101 ± 0.013 |
| matched | 0.497 ± 0.015 | 0.501 ± 0.004 | 0.637 ± 0.039 | −0.098 ± 0.010 |

![四环境末窗表现](figures/fig01_final_performance_by_environment.png)

*图 1　四环境末窗控制表现。四个 panel 分别对应 E1–E4；横轴为 condition，E1–E3 纵轴为末窗 accuracy，E4 纵轴为末窗 reward（越大越好）。柱/点颜色区分 condition，误差条为 seeds 0–2 的 SEM（n=3）。该图支持环境内方向和不确定性比较，不支持统计显著性或跨环境原始尺度合并。*

### 7.1 E1 T-maze：清晰的 oracle gap 与预测条件零效应

E1 的非 oracle 条件集中在 0.487–0.506；raw 与 whitened 都为 0.506，而 matched 与 gaussian_moment 都为 0.497。相对于 raw 的 paired difference，whitened 为 0.000±0.012，standardized 为 −0.008±0.010，gaussian_moment 与 matched 均为 −0.009 左右。三个 seed 内没有出现某种统计或几何处理持续把 accuracy 推离机会水平的证据。

oracle 达到 0.979±0.004，说明任务在隐藏 cue 可用时可被线性控制器解决；失败不应解释为动作/奖励定义本身不可学。observation_only 为 0.505±0.012，与 predictive conditions 重叠，说明当前 GVF 特征及其变换在这一预算下没有形成可复现的控制增益。

![E1 matched simplex 的 cue 着色](figures/fig11_e1_cue_clusters.png)

*图 2　E1 matched simplex 的诊断性 cue 着色。横纵轴为两个 simplex coordinates，颜色为真实左右 cue，仅用于离线诊断；图取 matched seed 0，无误差条。点满足 simplex 输出形状，但两类 cue 高度重叠，因此该图既不能证明语义分离，也不能代表跨 seed 稳定性。*

图 2 揭示了“命名结构正确但任务语义不足”的具体实例：simplex 只保证非负和归一化，不保证两顶点对应左右 cue。cross diagnostics 对 simplex 的 real-stream named property 通过，但控制准确率没有提高；这两条证据并不矛盾。

### 7.2 E2 Ringworld：正向均值、巨大不确定性与相位门禁失败

E2 中 standardized、whitened、gaussian_moment 的均值分别为 0.622、0.613、0.610，高于 raw 的 0.493；相对 raw 的 paired differences 分别为 0.129±0.085、0.120±0.117、0.117±0.182。然而 SEM 与均值差同量级甚至更大，尤其 gaussian_moment 的 0.185 表明三 seed 结果强烈分散。因此，数据只支持“某些 seed/条件出现改善方向”，不支持稳定提升。

matched 只有 0.501±0.004，几乎等于 observation_only 0.501±0.004，也远低于 oracle 0.975±0.001。matched circular 输出在几何上落于单位圆，但 real-stream phase-order gate 失败，提供了一个直接解释：输出形状约束没有确保沿圆的角度与真实任务 phase 保持足够顺序。

![E2 circular phase](figures/fig12_e2_circular_phase.png)

*图 3　E2 matched circular block。横纵轴为 circular block 的两个坐标，颜色为真实 phase；图取 matched seed 0，无误差条。单位圆外观与 radius gate 一致，但颜色沿圆的顺序不完整；真实流 alignment=0.2406，高于 shuffled=0.0098，却未达到预设 0.3 门槛。*

图 3 不能被写成“学到了正确相位流形”。更准确的结论是：固定的单位化操作实现了圆约束，预测 bank 的指定坐标含有某些 phase 结构，但其顺序对齐不足。它同时说明 task-matched prior 的成功条件比外形匹配更严格。

### 7.3 E3 Two-loop：最强局部正向结果，但不是跨环境规律

E3 提供了本仓库最清楚的局部正向结果。raw 为 0.495±0.004；standardized 为 0.613±0.016，matched 为 0.637±0.039，whitened 为 0.697±0.011，gaussian_moment 为 0.797±0.068。相对 raw 的同 seed 配对差依次为 0.118±0.012、0.141±0.035、0.201±0.007 和 0.302±0.069。即使不做显著性推断，这些差值也远大于 E1 的近零差值。

但 gaussian_moment 的结果必须按探索性矩整形解释。它在 E3 的均值最高，不意味着输出分布被保证为高斯，更不能证明矩误差降低是控制增益的唯一原因。whitened 和 standardized 也有明显正向结果，提示尺度与二阶条件可能与 two-loop 的 identity/phase 结构共同作用。

matched 的 block 表征同时约束 identity simplex 与 phase circle，准确率高于 raw，却低于 whitened 和 gaussian_moment。该排序反驳“语义命名先验必然优于通用变换”的强假设，同时保留“部分结构对齐可能有用”的较弱解释。

![E3 block representation](figures/fig13_e3_block_representation.png)

*图 4　E3 matched block 的两个子图。左图横纵轴为 identity simplex 两维，颜色为真实 loop identity；右图横纵轴为 phase circle 两维，颜色为真实 phase。图取 matched seed 0，无误差条。图支持两块输出约束的可视检查，不足以证明任一块是 0.637 准确率的因果来源。*

### 7.4 E4 Hidden-velocity：raw 末窗最好，信息恢复没有转化为 reward

E4 的 reward 越接近零越好。raw 为 −0.063±0.018，是十条件中最高的末窗均值；observation_only 为 −0.079±0.003，oracle 为 −0.085±0.009。所有 predictive transforms/priors 均低于 raw：unit_sphere −0.084、whitened −0.087、gaussian_moment −0.088、matched −0.098、sparse −0.101、rms_raw −0.117、standardized −0.121。

同 seed paired differences 更直接：相对 raw，unit_sphere −0.021±0.002、whitened −0.023±0.038、gaussian_moment −0.024±0.028、matched −0.034±0.022、standardized −0.058±0.052。这里不存在可被隐藏的正向均值；E4 是主矩阵中明确的负结果环境。

oracle 在末窗不优于 raw，不等于速度无用。oracle 的 task decodability 约为 1，而其控制参数、尺度与有限预算下的在线优化路径不同；末窗排序还可能受 controller step size 与状态分布影响。证据只允许说“在当前 E4 配置与 18,000 interactions 内，oracle 输入没有形成更高末窗 reward”。

![E4 velocity prediction](figures/fig14_e4_hidden_velocity_prediction.png)

*图 5　E4 matched 表征的 held-out velocity probe。横轴为真实 velocity，纵轴为线性 probe 预测；虚线为理想 $y=x$，点来自 matched seed 0。预测与真实值存在方向关系但幅度明显压缩；该单 seed 图不代表跨 seed 稳定性，也不能推出控制优势。*

matched 的 task decodability 为 0.323±0.123，高于 observation_only 的 0.096±0.009；whitened 为 0.510±0.071，gaussian_moment 为 0.367±0.117。尽管这些特征比 observation-only 含有更多可线性恢复的 velocity 信息，它们的 reward 均未超过 raw。这是“信息存在但在线控制不可用或代价更大”的环境级反例。

### 7.5 属性满足、协方差谱与更新尺度

![task-matched 与通用变换](figures/fig02_task_matched_vs_generic.png)

*图 6　matched、raw、whitened 与 gaussian_moment 的环境内比较。四个 panel 分别对应 E1–E4；横轴为四个条件，纵轴为 E1–E3 末窗 accuracy 或 E4 末窗 reward，颜色区分条件，误差条为跨 seed SEM（n=3）。图显示 matched 不跨环境一致占优：E3 有正向均值，E1/E2 近 null，E4 为负向。*

图 6 将最直接的 task-matched 假设与两个通用变换并列。E1 中四者重叠；E2 的 whitened/gaussian_moment 均值高于 matched；E3 三种处理均高于 raw，但 gaussian_moment 和 whitened 高于 matched；E4 则 raw 最高。这种交叉排序与单一“正确几何就更好”的解释不一致。

![属性满足热图](figures/fig03_property_fulfillment_summary.png)

*图 7　真实流中的二阶 isotropy error 热图。横轴为 condition，纵轴为 environment，颜色和格内数字为跨 seed 平均 error（越低越接近单位协方差），无误差条。oracle/observation-only 的维度与预测条件不同，不能作纯变换公平比较。热图支持属性满足与控制表现分离，不支持把低 error 解释为因果收益。*

图 7 中，某些二阶处理确实把 isotropy error 压低，但表 2 的控制排序没有同步单调变化。尤其 E4 中二阶结构改善并未带来 reward 提升；E1 中多种几何的末窗准确率仍接近 0.5。E3 的确出现较低 error 与较高表现同时发生，但这一关系没有跨环境复制。

![协方差特征值谱](figures/fig04_covariance_eigenvalue_spectra.png)

*图 8　表征协方差特征值谱。四个 panel 对应环境；横轴为按大小排序的特征值秩，纵轴为协方差特征值（对数尺度），颜色为 condition，曲线为跨 seed 均值且无误差条。谱图可识别秩亏、尺度集中和二阶变换效果，但不能单独推出任务信息或控制表现。*

协方差谱说明 effective rank 和 isotropy 并非同一指标：一个表征可以避免单维主导，却仍有远离单位协方差的尺度；也可以通过变换得到较平坦谱，却压缩或旋转了控制器短期最容易利用的方向。谱图为优化耦合提供了合理诊断，但没有因果干预，因此只能作为与结果一致的机制线索。

![控制更新范数](figures/fig05_update_norm_stability.png)

*图 9　控制器 update norm 的条件比较。四个 panel 对应环境；横轴为 condition，纵轴为 control update norm，颜色区分条件。误差条基于聚合 update rows，而不是先按 seed 汇总后的 seed 间 SEM，因此只作定性稳定性诊断，不用于显著性或独立重复判断。*

图 5 表明表征处理会改变线性控制器看到的更新尺度。该观察可解释为何“属性更好”不自动等于“在固定 step size 下更易学”：变换不仅改变几何，也改变特征幅度、condition number 和 TD update path。由于误差条口径不是 seed-level，本报告不报告精确组间不确定性结论。

![gaussian_moment 合成流诊断](figures/fig18_gaussian_synthetic_histograms.png)

*图 10　gaussian_moment 的合成流 before/after histograms。各 panel 比较预设偏斜、重尾等诊断流在变换前后的分布形状；颜色/线型区分 before 与 after。诊断 manifest 为 12/12 checks passed，说明部分偏度/峰度误差按预设方向降低；它不是 RL 控制结果，也不提供输出严格高斯的分布保证。*

合成诊断验证了实现方向：positive/negative skew 与 heavy-tail 的目标误差降低，normal stream 未被固定容差判为实质破坏。但真实环境的矩误差与表现关系仍依环境变化，所以合成属性测试是必要门禁而非充分证据。

### 7.6 Bank 与 horizon 配对消融

**表 3　已有配对消融的代表性差值（均值 ± paired-seed SEM，n=3）。** 正值表示左侧设置更高；E1–E3 为 accuracy，E4 为 reward。

| 消融 | 环境/条件 | 差值 | 解释边界 |
|---|---|---:|---|
| compact − mixed bank | E1 raw | 0.010 ± 0.003 | 小幅方向，不能称 bank 优势 |
| compact − mixed bank | E2 raw | 0.005 ± 0.003 | 小幅方向 |
| compact − mixed bank | E3 raw | 0.006 ± 0.005 | 与零同量级 |
| compact − mixed bank | E4 raw | −0.016 ± 0.018 | 方向不确定 |
| compact − mixed bank | E4 matched | 0.082 ± 0.092 | 均值较大但 SEM 更大 |
| short − matched horizon | E1 matched | 0.006 ± 0.002 | 小幅方向 |
| short − matched horizon | E2 matched | −0.141 ± 0.140 | 方向为负、证据高度不确定 |

compact 与 mixed 的多数差值很小；E4 matched 的 0.082 也伴随 0.092 SEM。short horizon 在 E2 matched 上可能损害表现，但三 seed 不确定性几乎覆盖均值幅度。这些消融不足以把主结果归因于 bank 宽度或 horizon 选择，也没有支持事后调参以追求正结果。

## 8. 任务可解码性与控制性能的关系

### 8.1 主 cross-pilot 的环境内关系

![可解码性与控制](figures/fig06_decodability_vs_control.png)

*图 11　held-out task decodability 与末窗控制表现。四个 panel 对应环境；横轴为环境特定 task decodability，纵轴为 E1–E3 accuracy 或 E4 reward，颜色为 condition，每个点为一个 condition×seed，无误差条。图用于环境内描述，不跨环境混合；它不能证明 decodability 的因果中介作用。*

在排除 observation-only 与 oracle 后，每环境 24 个点的 task-decoding Pearson $r$ / Spearman $\rho$ 分别为：E1 0.116/0.112，E2 −0.050/−0.220，E3 0.021/0.088，E4 0.068/0.096。四个环境都没有一致的强单调关系。尤其 E3 的控制差异很大，但 task-decoding 相关接近零；E4 中更可解码的 velocity 也未转换为更高 reward。

这一结果不表示任务信息“没有用”。probe 检查的是离线线性可读性，控制器面临的则是在线状态访问频率、动作信用分配、step size、特征尺度和策略诱导分布。更谨慎的结论是：当前定义的 task decodability 单独不足以预测控制表现。

![effective rank 与控制](figures/fig07_effective_rank_vs_control.png)

*图 12　effective rank 与末窗控制表现。四个 panel 对应环境；横轴为 effective rank，纵轴为环境内末窗表现，颜色为 condition，每点为 condition×seed，无误差条。图显示高 rank 不是高表现的充分条件；它不排除 rank 在特定环境中的作用。*

![isotropy error 与控制](figures/fig08_isotropy_vs_control.png)

*图 13　二阶 isotropy error 与末窗控制表现。横轴 error 越低越接近单位协方差，纵轴为环境内末窗表现；颜色为 condition，每点为 condition×seed，无误差条。E3 呈现局部负关系，但其他环境不复制；散点不能作因果解释。*

![矩误差与控制](figures/fig09_moment_error_vs_control.png)

*图 14　skewness/kurtosis error 与末窗控制表现。左右 panel 分别以偏度误差和峰度误差为横轴，纵轴混合显示各环境原始 performance，颜色为 condition，每点为 condition×seed，无误差条。由于 accuracy 与 reward 尺度不同，本报告不从跨环境整体云团计算总体相关，只使用环境内数值。*

E3 是唯一在多个几何指标上出现较强描述性关系的环境：effective rank 的 $r=0.711$、$\rho=0.551$；isotropy error 的 $r=-0.745$、$\rho=-0.781$；skewness error 的 $r=-0.431$、$\rho=-0.694$。但 E1、E2、E4 的相应关系弱、方向变化或 Pearson/Spearman 不一致。例如 E2 effective rank 的 $r=0.337$ 而 $\rho=-0.165$。因此 E3 的模式可作为局部机制线索，不能提升为跨环境定律。

### 8.2 Core T-maze 的“可解码但不可控制”反例

core pilot v3 与主 E1 使用不同但相关的十条件矩阵，20,000 interactions、三 seeds、30/30 runs。其末窗准确率见图 15。

![core pilot 末窗准确率](figures/fig15_core_pilot_final_accuracy.png)

*图 15　core T-maze pilot v3 的末窗准确率。横轴为十条件，纵轴为最后 200 trials 的 accuracy，颜色区分条件，误差条为跨 seed SEM（n=3）。oracle=0.985±0.006；其余条件位于 0.522–0.568，误差条多有重叠。该批次独立用于 E1 机制复核，不与主 cross-pilot 拼接样本量。*

最关键的条件是 `trace_only`。它只向控制器提供固定因果 trace，不是 oracle；在 junction 的 held-out cue decodability 为 1.000，三个 seed 的所有 corridor positions 也均为 1.000。然而其末窗 accuracy 只有 0.567±0.009，与 observation_only 0.563±0.009、unit_sphere 0.568±0.004 和 whitened 0.562±0.025 同一量级，远低于 oracle 0.985±0.006。

![core pilot cue decodability](figures/fig16_core_pilot_cue_decodability.png)

*图 16　core pilot 的 cue decodability 随 corridor position 变化。横轴为 corridor/junction position，纵轴为 held-out cue decodability，颜色为 condition，曲线/点汇总三 seeds。trace_only 在所有位置均为 1.0；部分预测条件也明显高于 observation-only。该图只说明线性可读信息，不说明在线控制器已学会在 junction 使用它。*

![core pilot accuracy vs decodability](figures/fig17_core_pilot_accuracy_vs_decodability.png)

*图 17　core pilot 的末窗 accuracy 与 junction cue decodability。横轴为 junction held-out decodability，纵轴为末窗 accuracy，颜色为 condition；点按 condition 汇总三 seed。trace_only 位于 decodability=1.0 但 accuracy≈0.567，oracle 同样 decodability=1.0 而 accuracy≈0.985，直接显示“相同可解码性、不同控制可用性”。*

图 17 是全报告最强的反例之一：若 decodability 是充分条件，trace_only 与 oracle 不应在相同 1.0 可解码性下产生约 0.42 的准确率差距。该差距可能来自特征进入控制器的尺度、位置特异访问、在线权重学习或表示形式，但现有数据没有隔离唯一机制。它足以否定“高 decodability 自动保证高 control”这一强命题，却不能否定 decodability 的必要性或潜在作用。

## 9. 跨环境综合分析

### 9.1 同一变换的方向随环境改变

跨环境最稳定的事实不是某种变换占优，而是效果方向发生反转。whitened 相对 raw 的 paired difference 在 E1 为 0.000±0.012，在 E2 为 0.120±0.117，在 E3 为 0.201±0.007，在 E4 为 −0.023±0.038。gaussian_moment 对应为 −0.009±0.016、0.117±0.182、0.302±0.069、−0.024±0.028。standardized 对应为 −0.008±0.010、0.129±0.085、0.118±0.012、−0.058±0.052。

这组符号变化排除了“只要做尺度/二阶/矩处理就总能提高控制”的解释。E3 中，identity 与 phase 的联合混叠可能使通用条件改善更容易转化为控制；E1 的决策稀疏且要求在特定 junction 使用遥远 cue，E4 则是连续动力学与固定 step size 耦合。后两句只是与结果一致的机制假设，而不是已验证因果结论。

matched prior 的跨环境结果同样异质：相对 raw，E1 −0.009±0.014，E2 0.007±0.006，E3 0.141±0.035，E4 −0.034±0.022。E2 的 real-stream phase-order failure 解释了为何“匹配”标签不能直接视为语义匹配；E3 的正向结果也没有超过通用 whitening 和 gaussian_moment。matched prior 的当前证据角色更接近结构化探针，而不是普适方法。

![环境特定 latent geometry](figures/fig10_environment_specific_latent_geometry.png)

*图 18　matched representation 的环境特定 latent geometry。各 panel 展示不同环境中 matched 坐标或 PCA 坐标，并用真实 latent 着色；数据取 matched seed 0，无误差条。图可检查输出形状与 latent 的可视对应，但不能代表跨 seed 稳定性，也不能证明图中的分离/环形结构导致了控制差异。*

图 18 将四种 matched prior 的意图放在一起：E1 simplex、E2 circle、E3 identity/phase block、E4 anisotropic coordinates。视觉上出现命名形状并不足以评价语义质量；E2 已有定量 gate 失败，E4 也展示 velocity probe 幅度压缩。正式解释必须优先采用量化 diagnostics 与控制 CSV，而不是依赖单 seed 图形印象。

### 9.2 属性—表现相关不是跨环境不变量

表 4 汇总 predictive-only 点的环境内相关。每个单元为 Pearson $r$ / Spearman $\rho$，样本单位是 24 个 condition×seed 点；没有 p 值或显著性标记。

**表 4　环境内表征指标与末窗表现的描述性相关。** E4 的表现为 reward；isotropy/skewness/kurtosis error 越低表示越接近相应目标。

| 指标 | E1 T-maze | E2 Ringworld | E3 Two-loop | E4 Hidden-velocity |
|---|---:|---:|---:|---:|
| task decodability | 0.116 / 0.112 | −0.050 / −0.220 | 0.021 / 0.088 | 0.068 / 0.096 |
| effective rank | 0.035 / −0.015 | 0.337 / −0.165 | 0.711 / 0.551 | 0.098 / −0.008 |
| isotropy error | 0.042 / 0.045 | −0.137 / 0.007 | −0.745 / −0.781 | −0.066 / 0.082 |
| skewness error | 0.132 / −0.080 | −0.107 / 0.007 | −0.431 / −0.694 | −0.248 / −0.088 |
| kurtosis error | −0.100 / −0.137 | −0.049 / 0.395 | −0.317 / −0.328 | −0.125 / 0.087 |

E3 同时呈现较高 rank 与较高表现、较低 error 与较高表现；其他环境没有复制这一组合。E2 的 rank Pearson 与 Spearman 异号，kurtosis Pearson 近零而 Spearman 为 0.395，说明少量条件簇和非线性排序会明显影响相关估计。E1/E4 的绝大多数系数接近零。现有数据因此支持“关系依环境而定”，不支持建立统一标量质量指标。

### 9.3 Oracle gap 的正确用途

E1–E3 的 oracle 末窗 accuracy 都在 0.975–0.979，而 observation-only 约为 0.47–0.50。这表明三个离散环境确实需要被当前观测隐藏的信息，也说明控制器在显式状态表示下有能力解决任务。predictive conditions 与 oracle 的差距则量化了“在线学到并利用隐藏信息”的未闭合部分。

E4 的 oracle 末窗 reward 低于 raw，提醒 oracle 不是所有有限预算优化路径上的数值上界。oracle 只保证输入含隐藏状态，不保证与固定 controller step size、特征尺度和访问分布最匹配。报告因此将 oracle 称作隔离参照，而不把每个末窗数值都解释为理论上界。

### 9.4 证据支持的机制图景

将属性门禁、主结果、相关、core 反例和消融合在一起，最节制的机制图景包含三层。

第一，统计/几何变换确实能按设计改变表征。例如二阶 whitening 降低 isotropy error，unit_sphere 约束范数，gaussian_moment 在合成流降低部分矩误差，matched prior 产生 simplex/circle/block/anisotropic 输出。

第二，真实流语义不是由输出形状自动保证。E2 圆半径通过但 phase order 失败；E1 simplex 中 cue 仍重叠；E4 matched 的 velocity 预测幅度被压缩。属性门禁必须分成“代数约束”和“任务语义对齐”两部分。

第三，即使任务信息可解码，固定在线线性控制器能否利用它仍取决于优化耦合。core trace_only 的 perfect decodability 与近机会控制、E4 的较高 velocity decodability 与较低 reward 都是直接反例。特征评价若只看几何或 probe，会遗漏控制学习路径。

## 10. 主要发现

1. **主矩阵完整但证据规模有限。** 120/120 runs 完成，三 seed 内没有 NaN、Inf 或 divergence；这是 pilot 级数值完整性，不是 full-study 证明。
2. **不存在跨环境一致占优的统计或几何条件。** E1 基本为 null；E2 有正向均值但不确定性大；E3 有清楚的局部正向结果；E4 的所有变换/先验均低于 raw。
3. **E3 是最强局部正向环境。** gaussian_moment、whitened、matched 与 standardized 分别比 raw 高 0.302、0.201、0.141、0.118（paired mean）；该结果限定于 three-seed、14,000-interaction Two-loop pilot。
4. **E4 是不可省略的负结果。** raw 的末窗 reward 最高，standardized、rms_raw、matched 等均更差；这反驳“规范化总能改善固定线性控制”的简单假设。
5. **属性满足不等于语义对齐。** E2 的单位圆约束通过而真实 phase-order gate 失败，主 diagnostics 因此为 29/30、`failed`。
6. **可解码性不是控制成功的充分条件。** 主矩阵的环境内 task-decoding 相关均弱；core T-maze 中 trace_only 在 junction 的 cue decodability=1.0，但末窗 accuracy 只有 0.567±0.009。
7. **几何—性能关系是环境特定的。** E3 中 effective rank 与 isotropy/moment errors 呈现较强描述性关系，E1/E2/E4 不复制；不能把 E3 的局部相关提升为统一设计原则。
8. **当前 bank/horizon 消融未锁定替代机制。** 多数 paired differences 较小或 SEM 大；没有理由根据已有 pilot 事后调参以追求正结果。

## 11. 局限性

**样本规模。** 主矩阵和消融都只有三个 seeds。SEM 能显示明显的 seed 波动，但不足以支撑稳定的推断检验；报告也没有进行多重比较或置信区间校正。

**运行规模。** 仓库没有 remote full run。E1/E2/E3/E4 的 interactions 分别为 12k/12k/14k/18k，结果可能受学习尚未收敛影响。拥挤且有伪影的 learning-curve 图被排除后，报告不对收敛速度作强结论。

**环境与控制器范围。** 四个环境是受控的非深度 POMDP/连续控制诊断环境；控制器是固定线性方法。结论不应外推到深度网络、replay、batch optimization、其他 GVF questions 或不同 controller family。

**超参数耦合。** 同一 controller step size 与不同特征尺度可能产生不同有效更新大小。E4 使用较小 control alpha，但仍可能不是每种表示的最优值。为避免 outcome-driven tuning，本报告不进行按条件追调；代价是不能区分“表示本身不足”和“固定优化器不匹配”。

**诊断测量。** held-out probe 衡量线性可读性而非在线可用性；effective rank、isotropy error 和矩误差也只是表征摘要。condition×seed 相关点存在聚类结构，不是独立方法样本。

**属性门禁。** E2 circular real-stream phase-order 未通过，matched 的语义解释必须降级。synthetic checks 只验证实现方向，不替代真实流语义检查。

**图像统计口径。** latent geometry 与 E1–E4 专门图主要来自 matched seed 0；不能代表跨 seed 稳定性。update norm 图的误差条是 row-level 聚合而非 seed-level SEM。现有图为 160 dpi PNG，放大和编辑受限。

**版本与重复 artifacts。** core pilot v2 的 manifest 与工作日志冲突，因此被排除。结果目录中 3,053 个文件副本和 224 张图副本不增加独立证据量。某些 smoke/部署检查由 dirty commit 生成，只用于工程 provenance，不进入主要科学结论。

**并发工作区漂移。** 结果和源码在报告生成期间继续被其他流程修改；本报告按 01:15:29 的审计快照冻结，不覆盖随后出现的 local-validation、overnight smoke 或扩展实现。该边界保证正文内部一致，但意味着交付时工作区的最新并发 artifacts 需要另行审计，不能与本报告样本量直接相加。

**因果解释。** 现有消融没有分别干预“信息含量”“几何”“尺度”和“控制器条件数”，所以不能把 E3 增益归因于单一机制。报告的机制段落均是与证据一致的解释，不是因果识别。

## 12. 结论

现有证据回答了一个比“哪种表示最好”更有约束力的问题：在严格流式、线性、部分可观测控制中，预先规定预测特征的统计或几何性质能够改变表征，并可在特定环境产生较大局部控制收益，但它们没有形成跨环境一致增益。

E3 的 gaussian_moment、二阶 whitening、matched block 和 standardization 均高于 raw，说明表征处理在合适任务结构中可能有价值；E1 的零效应、E2 的高不确定性与 phase-order failure、E4 的全面负向结果又共同限制了这一结论。最可靠的新认识不是某个变换获胜，而是三个评价层必须分开：代数/统计属性是否满足，任务变量是否可解码，以及固定在线控制器是否真正得到收益。

core T-maze 的 trace_only 反例尤其清楚：完美 cue decodability 与近机会控制可以同时存在。因此，后续验证若继续推进，应优先扩大预登记 seed/full profile，并设计能隔离表征尺度、语义对齐和在线控制可用性的干预，而不是在看到 pilot 后追调条件以制造正结果。在当前 artifacts 范围内，结论应停留在 pilot 级、环境依赖且保留负结果的证据边界内。
