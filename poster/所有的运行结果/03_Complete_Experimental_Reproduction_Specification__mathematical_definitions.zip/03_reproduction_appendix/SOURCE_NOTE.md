## Source and version selection

This package translates the standalone technical appendix (`流式部分可观测强化学习_完整实验复现附录.pdf`). It is a distinct reproducibility document, not a minor revision of the integrated results paper.
