# Complete Experimental Reproduction Specification and Mathematical Definitions

**Core topic:** implementation-level reproducibility for the entire experimental program, including environment dynamics, predictive banks, all feature conditions, fixed nonlinear adapters, probes, metrics, random seeds, validity checks, and exact run commands.

This package is the English LaTeX edition of the standalone reproduction appendix returned at the end of the conversation. It is separate from the integrated results paper and is intended to be read as its technical companion.

## Build

```bash
./build.sh
```

A standard TeX Live/MiKTeX installation with `latexmk` and `pdflatex` is sufficient.
