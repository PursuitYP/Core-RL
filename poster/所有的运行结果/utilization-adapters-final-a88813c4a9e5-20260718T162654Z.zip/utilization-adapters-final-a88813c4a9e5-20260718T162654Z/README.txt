Utilization Adapter Experiments

Source commit:
a88813c4a9e5a2c8c36eb936d64ac34e17d4dfd3

Completed experiment stages:
- Stage A: 1120 logical results
- Stage B1: 120 logical results
- Stage B2: 150 logical results

Total:
- 1390 logical results
- 1290 physical runs
- 100 Stage B2 cells reused from Stage A
- 0 NaN
- 0 Inf
- 0 divergence
- 4 formal figures

This is a lightweight aggregate package.
It does not contain all 1290 per-run directories.
