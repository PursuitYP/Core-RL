# Utilization adapter experiment summary

- Logical cells: 1390
- Valid summaries: 1390
- Failed or missing: 0
