$ErrorActionPreference = 'Stop'
$OutputEncoding = [System.Text.UTF8Encoding]::new($false)
$ReportDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$Python = 'D:\download\utilization-adapters-final-analysis\.venv\Scripts\python.exe'
$AssetScript = Join-Path $ReportDir 'generate_report_assets.py'
$LogPath = Join-Path $ReportDir 'build.log'

Set-Location -LiteralPath $ReportDir

if (-not (Test-Path -LiteralPath $Python)) {
    throw "Python environment not found: $Python"
}

& $Python $AssetScript
if ($LASTEXITCODE -ne 0) {
    throw "Report asset generation failed with exit code $LASTEXITCODE"
}

$XeLaTeX = Get-Command xelatex -ErrorAction Stop
if (Test-Path -LiteralPath $LogPath) {
    Remove-Item -LiteralPath $LogPath -Force
}

# MiKTeX's latexmk wrapper emits the installation's update-sync warning to
# stderr and PowerShell raises NativeCommandError before preserving the real
# exit code.  Direct XeLaTeX passes are deterministic here; three passes also
# settle longtable widths, the table of contents, and cross-references.
for ($Pass = 1; $Pass -le 3; $Pass++) {
    "===== XELATEX PASS $Pass =====" | Out-File -LiteralPath $LogPath -Append -Encoding utf8
    $PreviousErrorAction = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    & $XeLaTeX.Source -interaction=nonstopmode -halt-on-error main.tex 2>&1 |
        ForEach-Object { $_.ToString() } |
        Tee-Object -FilePath $LogPath -Append
    $BuildStatus = $LASTEXITCODE
    $ErrorActionPreference = $PreviousErrorAction
    if ($BuildStatus -ne 0) {
        throw "XeLaTeX pass $Pass failed with exit code $BuildStatus; inspect $LogPath"
    }
}

$MainPdf = Join-Path $ReportDir 'main.pdf'
$ReportPdf = Join-Path $ReportDir 'report.pdf'
if (-not (Test-Path -LiteralPath $MainPdf)) {
    throw "Expected PDF was not produced: $MainPdf"
}
Copy-Item -LiteralPath $MainPdf -Destination $ReportPdf -Force

if ((Get-Item -LiteralPath $ReportPdf).Length -le 0) {
    throw "Compiled report is empty: $ReportPdf"
}

Write-Host "REPORT_PDF=$ReportPdf"
Write-Host "BUILD_LOG=$LogPath"
