from __future__ import annotations

import hashlib
import json
import shutil
from pathlib import Path

import numpy as np
import pandas as pd


REPORT = Path(__file__).resolve().parent
ROOT = REPORT.parent
PKG = next((ROOT / "extracted").glob("utilization-adapters-final-*"))
TABLES = REPORT / "tables"
DATA = REPORT / "generated_data"
FIGURES = REPORT / "figures"
for directory in (TABLES, DATA, FIGURES):
    directory.mkdir(parents=True, exist_ok=True)

ENV_ZH = {
    "tmaze": "T-maze",
    "ringworld": "Ringworld",
    "two_loop": "Two-loop",
    "hidden_velocity": "Hidden velocity",
}
COND_ZH = {
    "observation_only": "仅观测",
    "raw": "原始 GVF",
    "matched": "匹配变换",
    "standardized": "标准化",
    "whitened": "白化（二阶变换）",
    "gaussian_moment": "在线矩整形",
    "oracle": "Oracle",
    "trace_only": "仅 trace",
}
ADAPTER_ZH = {"identity": "Identity", "residual_rff": "RFF", "tile_coding": "Tile"}


def tex_escape(value: object) -> str:
    text = str(value)
    replacements = {
        "\\": r"\textbackslash{}",
        "&": r"\&",
        "%": r"\%",
        "$": r"\$",
        "#": r"\#",
        "_": r"\_",
        "{": r"\{",
        "}": r"\}",
        "~": r"\textasciitilde{}",
        "^": r"\textasciicircum{}",
        "−": "-",
    }
    return "".join(replacements.get(char, char) for char in text)


def fmt(value: float, digits: int = 4) -> str:
    if pd.isna(value):
        return "--"
    value = float(value)
    if value != 0 and (abs(value) >= 1e5 or abs(value) < 1e-4):
        return f"{value:.2e}"
    return f"{value:.{digits}f}"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_longtable(
    path: Path,
    caption: str,
    label: str,
    headers: list[str],
    rows: list[list[object]],
    column_spec: str,
    note: str | None = None,
) -> None:
    header = " & ".join(headers) + r" \\"
    lines = [
        r"\begingroup",
        r"\small",
        rf"\begin{{longtable}}{{{column_spec}}}",
        rf"\caption{{{caption}}}\label{{{label}}}\\",
        r"\toprule",
        header,
        r"\midrule",
        r"\endfirsthead",
        rf"\multicolumn{{{len(headers)}}}{{c}}{{续表~\thetable}}\\",
        r"\toprule",
        header,
        r"\midrule",
        r"\endhead",
        r"\midrule",
        rf"\multicolumn{{{len(headers)}}}{{r}}{{下页继续}}\\",
        r"\endfoot",
        r"\bottomrule",
        r"\endlastfoot",
    ]
    lines.extend(" & ".join(tex_escape(v) for v in row) + r" \\" for row in rows)
    lines.extend([r"\end{longtable}"])
    if note:
        lines.append(rf"\noindent\footnotesize\textit{{注：{tex_escape(note)}}}")
    lines.extend([r"\endgroup", ""])
    path.write_text("\n".join(lines), encoding="utf-8")


def write_tabular(
    path: Path,
    caption: str,
    label: str,
    headers: list[str],
    rows: list[list[object]],
    column_spec: str,
    note: str | None = None,
) -> None:
    lines = [
        r"\begin{table}[!htbp]",
        r"\centering",
        rf"\caption{{{caption}}}\label{{{label}}}",
        r"\small",
        rf"\begin{{tabular}}{{{column_spec}}}",
        r"\toprule",
        " & ".join(headers) + r" \\",
        r"\midrule",
    ]
    lines.extend(" & ".join(tex_escape(v) for v in row) + r" \\" for row in rows)
    lines.extend([r"\bottomrule", r"\end{tabular}"])
    if note:
        lines.append(rf"\parbox{{0.96\linewidth}}{{\footnotesize\textit{{注：{tex_escape(note)}}}}}")
    lines.extend([r"\end{table}", ""])
    path.write_text("\n".join(lines), encoding="utf-8")


def value_cell(frame: pd.DataFrame, **filters: object) -> pd.Series:
    subset = frame
    for key, value in filters.items():
        subset = subset.loc[subset[key] == value]
    if len(subset) != 1:
        raise ValueError(f"Expected one row for {filters}, found {len(subset)}")
    return subset.iloc[0]


def main() -> None:
    runs = pd.read_csv(PKG / "run_summaries.csv")
    quantitative = pd.read_csv(ROOT / "quantitative_summary.csv")
    performance = pd.read_csv(ROOT / "adapter_performance_summary.csv")
    runtime = pd.read_csv(ROOT / "runtime_stage_environment_summary.csv")
    diagnostic = pd.read_csv(ROOT / "diagnostic_summary.csv")
    catastrophic = pd.read_csv(ROOT / "catastrophic_like_runs.csv")
    audit = json.loads((ROOT / "integrity_audit_recomputed.json").read_text(encoding="utf-8"))

    # Preserve exactly the derived data used by the report.
    derived_files = {
        "quantitative_summary.csv": quantitative,
        "adapter_performance_summary.csv": performance,
        "runtime_stage_environment_summary.csv": runtime,
        "diagnostic_summary.csv": diagnostic,
        "catastrophic_like_runs.csv": catastrophic,
    }
    for name, frame in derived_files.items():
        frame.to_csv(DATA / name, index=False)
    shutil.copy2(ROOT / "integrity_audit_recomputed.json", DATA / "integrity_audit_recomputed.json")

    # Compact experiment matrix derived from run_summaries.csv.
    matrix_rows = []
    for stage, group in runs.groupby("stage", sort=False):
        matrix_rows.append(
            [
                {"stage-a": "A", "stage-b1": "B1", "stage-b2": "B2"}[stage],
                ", ".join(ENV_ZH.get(v, v) for v in sorted(group.environment.unique())),
                str(group.condition.nunique()),
                ", ".join(ADAPTER_ZH.get(v, v) for v in sorted(group.adapter.unique())),
                str(group.seed.nunique()),
                str(len(group)),
                str(group.source_summary.nunique()),
            ]
        )
    write_tabular(
        TABLES / "experiment_matrix.tex",
        "三阶段实验矩阵总览",
        "tab:experiment-matrix",
        ["阶段", "环境", "条件数", "adapter", "seeds", "逻辑结果", "唯一来源"],
        matrix_rows,
        "p{1.1cm}p{3.4cm}p{1.5cm}p{2.5cm}rrr",
        "Stage B2 的 Identity/RFF 100 条逻辑结果复用 Stage A 物理运行；逻辑结果与物理运行不得混淆。",
    )

    audit_rows = [
        ["ZIP SHA-256", "通过" if audit["checks"]["zip_sha_ok"] else "失败", audit["actual_zip_sha256"][:16] + "…"],
        ["package manifest", "通过" if audit["checks"]["manifest_files_ok"] else "失败", f"{len(audit['manifest_files'])} 个条目逐文件 size/SHA 一致"],
        ["逻辑结果", "通过", "1390"],
        ["唯一物理来源", "通过", str(audit["unique_physical_sources"])],
        ["Stage B2 复用", "通过" if audit["checks"]["stage_b2_reuse_ok"] else "失败", "100 条；关键字段逐项一致"],
        ["阶段内重复", "通过" if audit["stage_duplicate_rows"] == 0 else "失败", str(audit["stage_duplicate_rows"])],
        ["failed runs", "通过" if audit["checks"]["failed_runs_empty"] else "失败", "0"],
        ["NaN/Inf/runtime divergence", "通过" if audit["checks"]["numerical_counters_zero"] else "失败", "均为 0"],
        ["source commit", "通过" if audit["checks"]["source_commit_ok"] else "失败", "a88813c4a9e5…"],
        ["聚合/配对/运行时重算", "通过", "均与包内汇总一致"],
    ]
    write_tabular(
        TABLES / "audit_summary.tex",
        "结果包完整性与有效性审计",
        "tab:audit-summary",
        ["检查项", "状态", "证据摘要"],
        audit_rows,
        "lll",
        "跨阶段四元组重叠不等于阶段内重复：100 组为预注册 A→B2 复用，另 60 组为 Stage B1 与 Stage A 的独立阶段运行。",
    )

    # Stage A complete table.
    stage_a = quantitative.loc[quantitative.stage == "stage-a"].copy()
    stage_a_rows = []
    for _, row in stage_a.iterrows():
        stage_a_rows.append(
            [
                ENV_ZH[row.environment],
                COND_ZH[row.condition],
                fmt(row.baseline_mean),
                fmt(row.comparison_mean),
                fmt(row.paired_mean),
                fmt(row.paired_sem),
                fmt(row.paired_median),
                f"{int(row.wins)}/{int(row.losses)}/{int(row.ties)}",
            ]
        )
    write_longtable(
        TABLES / "stage_a_full.tex",
        "Stage A 全部环境与条件的 Identity--RFF 配对结果",
        "tab:stage-a-full",
        ["环境", "条件", "Identity", "RFF", "差值均值", "SEM", "中位数", "W/L/T"],
        stage_a_rows,
        "llrrrrrr",
        "差值方向统一为 RFF−Identity；T-maze、Ringworld、Two-loop 为 accuracy，Hidden velocity 为 reward，禁止跨环境直接平均。W/L/T 按逐 seed 正/负/零差值计。",
    )

    stage_a_key_rows = []
    for env, condition in [
        ("tmaze", "raw"),
        ("ringworld", "raw"),
        ("two_loop", "raw"),
        ("hidden_velocity", "standardized"),
    ]:
        row = value_cell(stage_a, environment=env, condition=condition)
        stage_a_key_rows.append(
            [ENV_ZH[env], COND_ZH[condition], fmt(row.baseline_mean), fmt(row.comparison_mean), fmt(row.paired_mean), fmt(row.paired_sem), f"{int(row.wins)}/{int(row.losses)}/{int(row.ties)}"]
        )
    write_tabular(
        TABLES / "stage_a_key.tex",
        "Stage A 代表性配对结果",
        "tab:stage-a-key",
        ["环境", "条件", "Identity", "RFF", "差值", "SEM", "W/L/T"],
        stage_a_key_rows,
        "llrrrrr",
        "这里只列正文代表项；完整 28 个环境×条件单元见附录表。accuracy 与 reward 不跨环境合并。",
    )

    # B1 and B2 full comparison tables.
    for stage, stem, caption, label in [
        ("stage-b1", "stage_b1_full.tex", "Stage B1 全部 adapter 配对比较", "tab:stage-b1-full"),
        ("stage-b2", "stage_b2_full.tex", "Stage B2 全部 adapter 配对比较", "tab:stage-b2-full"),
    ]:
        subset = quantitative.loc[quantitative.stage == stage]
        rows = []
        for _, row in subset.iterrows():
            contrast = f"{ADAPTER_ZH[row.comparison_adapter]}−{ADAPTER_ZH[row.baseline_adapter]}"
            rows.append(
                [
                    COND_ZH[row.condition],
                    contrast,
                    fmt(row.baseline_mean),
                    fmt(row.comparison_mean),
                    fmt(row.paired_mean),
                    fmt(row.paired_sem),
                    fmt(row.paired_median),
                    f"{int(row.wins)}/{int(row.losses)}/{int(row.ties)}",
                ]
            )
        write_longtable(
            TABLES / stem,
            caption,
            label,
            ["条件", "对比", "基线", "比较项", "差值均值", "SEM", "中位数", "W/L/T"],
            rows,
            "llrrrrrr",
            "配对差值方向为“比较项−基线”，n=10 paired seeds per cell；不提供 p-value 或显著性标记。",
        )

    b1_perf = performance.loc[(performance.stage == "stage-b1")]
    b1_key_specs = [
        ("trace_only", "identity"),
        ("trace_only", "residual_rff"),
        ("trace_only", "tile_coding"),
        ("oracle", "identity"),
    ]
    b1_key_rows = []
    for condition, adapter in b1_key_specs:
        row = value_cell(b1_perf, condition=condition, adapter=adapter)
        b1_key_rows.append([COND_ZH[condition], ADAPTER_ZH[adapter], fmt(row["mean"]), fmt(row["sem"]), fmt(row["median"]), f"[{fmt(row.minimum)}, {fmt(row.maximum)}]"])
    write_tabular(
        TABLES / "stage_b1_key.tex",
        "Stage B1 机制验证关键均值",
        "tab:stage-b1-key",
        ["条件", "adapter", "mean", "SEM", "median", "范围"],
        b1_key_rows,
        "llrrrr",
        "指标为最后 200 trials accuracy；每项 n=10。",
    )

    b2 = quantitative.loc[quantitative.stage == "stage-b2"]
    b2_body_rows = []
    for condition in ["observation_only", "raw", "matched", "whitened", "oracle"]:
        rff = value_cell(b2, condition=condition, baseline_adapter="identity", comparison_adapter="residual_rff")
        tile = value_cell(b2, condition=condition, baseline_adapter="identity", comparison_adapter="tile_coding")
        tile_rff = value_cell(b2, condition=condition, baseline_adapter="residual_rff", comparison_adapter="tile_coding")
        b2_body_rows.append([COND_ZH[condition], fmt(rff.paired_mean), fmt(rff.paired_median), fmt(tile.paired_mean), fmt(tile.paired_median), fmt(tile_rff.paired_mean)])
    write_tabular(
        TABLES / "stage_b2_key.tex",
        "Stage B2 各条件的 adapter 配对差值",
        "tab:stage-b2-key",
        ["条件", "RFF-Id mean", "RFF-Id median", "Tile-Id mean", "Tile-Id median", "Tile-RFF mean"],
        b2_body_rows,
        "lrrrrr",
        "指标为 final-window mean reward，n=10；长尾情况下均值与中位数须同时解读。",
    )

    runtime_rows = []
    for _, row in runtime.iterrows():
        runtime_rows.append(
            [
                row.stage.replace("stage-", "").upper(),
                ENV_ZH[row.environment],
                ADAPTER_ZH[row.adapter],
                str(int(row.unique_physical_sources)),
                fmt(row.wall_mean, 1),
                fmt(row.wall_median, 1),
                fmt(row.wall_mean_vs_identity, 3),
            ]
        )
    write_longtable(
        TABLES / "runtime_full.tex",
        "阶段、环境与 adapter 的物理运行 wall time",
        "tab:runtime-full",
        ["阶段", "环境", "adapter", "物理来源", "均值/s", "中位数/s", "相对 Id"],
        runtime_rows,
        "lllrrrr",
        "wall time 以 source_summary 去重；Stage B2 Identity/RFF 是复用来源，不表示新增 B2 计算。",
    )

    diag_rows = []
    for _, row in diagnostic.iterrows():
        diag_rows.append(
            [
                row.stage.replace("stage-", "").upper(),
                ENV_ZH[row.environment],
                COND_ZH[row.condition],
                ADAPTER_ZH[row.adapter],
                fmt(row.controller_dim_median, 0),
                fmt(row.parameter_norm_median),
                fmt(row.parameter_norm_max),
                fmt(row.feature_squared_norm_median),
                fmt(row.update_norm_max),
            ]
        )
    write_longtable(
        TABLES / "diagnostic_full.tex",
        "全部分组的 controller dimension 与数值范数诊断",
        "tab:diagnostic-full",
        ["阶段", "环境", "条件", "adapter", "维度", "参数范数中位", "参数范数最大", "特征二范数中位", "更新范数最大"],
        diag_rows,
        "llllrrrrr",
        "max update norm 统一取 max_control_update_norm；Core T-maze 对缺失列使用同义字段 max_update_norm。科学计数法表示极端尺度。",
    )

    wlt_rows = []
    for _, row in quantitative.iterrows():
        contrast = f"{ADAPTER_ZH[row.comparison_adapter]}−{ADAPTER_ZH[row.baseline_adapter]}"
        wlt_rows.append([row.stage.replace("stage-", "").upper(), ENV_ZH[row.environment], COND_ZH[row.condition], contrast, str(int(row.wins)), str(int(row.losses)), str(int(row.ties)), str(int(row.valid_seed_count))])
    write_longtable(
        TABLES / "wins_losses_ties.tex",
        "全部定量比较的 wins/losses/ties",
        "tab:wlt-full",
        ["阶段", "环境", "条件", "对比", "wins", "losses", "ties", "n"],
        wlt_rows,
        "llllrrrr",
        "win 表示逐 seed 的“比较 adapter−基线 adapter”大于 0；未使用统计显著性阈值。",
    )

    # Data-derived macros keep prose values synchronized with CSVs.
    macros: dict[str, str] = {
        "LogicalRuns": str(len(runs)),
        "PhysicalRuns": str(runs.source_summary.nunique()),
        "ReusedRuns": str(int((runs.reuse_type == "planned_stage_a_reuse").sum())),
        "CatLogical": str(len(catastrophic)),
        "CatPhysical": str(catastrophic.source_summary.nunique()),
        "MaxUpdateNorm": fmt(runs.max_control_update_norm.fillna(runs.max_update_norm).max(), 2),
        "MaxParameterNorm": fmt(runs.final_parameter_norm.max(), 2),
    }
    for macro, env, condition in [
        ("TmazeRaw", "tmaze", "raw"),
        ("RingRaw", "ringworld", "raw"),
        ("TwoLoopRaw", "two_loop", "raw"),
        ("HiddenStandardized", "hidden_velocity", "standardized"),
    ]:
        row = value_cell(stage_a, environment=env, condition=condition)
        macros[macro + "Diff"] = fmt(row.paired_mean)
        macros[macro + "Sem"] = fmt(row.paired_sem)
        macros[macro + "WLT"] = f"{int(row.wins)}/{int(row.losses)}/{int(row.ties)}"
    for macro, condition, adapter in [
        ("BOneTraceId", "trace_only", "identity"),
        ("BOneTraceRff", "trace_only", "residual_rff"),
        ("BOneTraceTile", "trace_only", "tile_coding"),
        ("BOneOracleId", "oracle", "identity"),
    ]:
        macros[macro] = fmt(value_cell(b1_perf, condition=condition, adapter=adapter)["mean"])
    b1_trace_tile = value_cell(quantitative, stage="stage-b1", condition="trace_only", baseline_adapter="identity", comparison_adapter="tile_coding")
    b1_trace_rff = value_cell(quantitative, stage="stage-b1", condition="trace_only", baseline_adapter="identity", comparison_adapter="residual_rff")
    macros["BOneTileDiff"] = fmt(b1_trace_tile.paired_mean)
    macros["BOneTileSem"] = fmt(b1_trace_tile.paired_sem)
    macros["BOneRffDiff"] = fmt(b1_trace_rff.paired_mean)
    macros["BOneRffSem"] = fmt(b1_trace_rff.paired_sem)
    for macro, condition, left, right in [
        ("BTwoObsTile", "observation_only", "identity", "tile_coding"),
        ("BTwoWhitenRff", "whitened", "identity", "residual_rff"),
        ("BTwoMatchedRff", "matched", "identity", "residual_rff"),
    ]:
        row = value_cell(b2, condition=condition, baseline_adapter=left, comparison_adapter=right)
        macros[macro + "Mean"] = fmt(row.paired_mean)
        macros[macro + "Median"] = fmt(row.paired_median)
        macros[macro + "WLT"] = f"{int(row.wins)}/{int(row.losses)}/{int(row.ties)}"
    macro_lines = [rf"\newcommand{{\{name}}}{{{tex_escape(value)}}}" for name, value in macros.items()]
    (TABLES / "report_macros.tex").write_text("\n".join(macro_lines) + "\n", encoding="utf-8")

    # Copy only figures actually referenced by the report.
    figure_map = {
        "fig01_stage_a_paired_seed_effects.png": "Stage A paired seed effects",
        "fig02_stage_b1_trace_only_rescue.png": "Stage B1 trace-only rescue",
        "fig03_stage_b2_all_conditions.png": "Stage B2 all-condition comparisons",
        "fig04_stability_runtime_diagnostics.png": "stability and runtime diagnostics",
    }
    for name in figure_map:
        shutil.copy2(ROOT / "improved_figures" / name, FIGURES / name)

    inventory_rows = [
        ["实验矩阵", "table", "tables/experiment_matrix.tex", "extracted/.../run_summaries.csv", "all valid logical rows", "stage", "logical count; unique source count", "正文"],
        ["完整性审计", "table", "tables/audit_summary.tex", "integrity_audit_recomputed.json + package_manifest.json", "manifest-verified package", "check", "boolean validation and counts", "正文"],
        ["Stage A 代表项", "table", "tables/stage_a_key.tex", "run_summaries.csv", "Stage A selected representative conditions", "environment×condition×adapter; paired seed", "mean; SEM; paired mean; W/L/T", "正文；完整表在附录"],
        ["Stage A 全表", "table", "tables/stage_a_full.tex", "run_summaries.csv", "Stage A, Identity vs RFF", "environment×condition; seed pairing", "mean; SEM; median; W/L/T", "附录"],
        ["Stage B1 关键值", "table", "tables/stage_b1_key.tex", "run_summaries.csv", "trace_only adapters + oracle identity", "condition×adapter", "mean; SEM; median; range", "正文"],
        ["Stage B1 全表", "table", "tables/stage_b1_full.tex", "run_summaries.csv", "Stage B1 all 12 contrasts", "condition×adapter pair; seed", "paired mean; SEM; median; W/L/T", "附录"],
        ["Stage B2 关键值", "table", "tables/stage_b2_key.tex", "run_summaries.csv", "Stage B2 all five conditions", "condition×adapter pair; seed", "paired mean and median", "正文"],
        ["Stage B2 全表", "table", "tables/stage_b2_full.tex", "run_summaries.csv", "Stage B2 all 15 contrasts", "condition×adapter pair; seed", "paired mean; SEM; median; W/L/T", "附录"],
        ["运行时全表", "table", "tables/runtime_full.tex", "run_summaries.csv", "drop_duplicates(source_summary)", "stage×environment×adapter", "wall mean/median and identity ratio", "附录"],
        ["范数诊断全表", "table", "tables/diagnostic_full.tex", "run_summaries.csv", "all valid logical rows", "stage×environment×condition×adapter", "dimension and norm summaries", "附录"],
        ["W/L/T 全表", "table", "tables/wins_losses_ties.tex", "run_summaries.csv", "all 55 prespecified comparisons", "stage×environment×condition×contrast", "sign counts by paired seed", "附录"],
    ]
    for name, purpose in figure_map.items():
        source_name = {
            "fig01_stage_a_paired_seed_effects.png": "source_stage_a_paired_differences.csv",
            "fig02_stage_b1_trace_only_rescue.png": "source_stage_b1_trace_profiles.csv",
            "fig03_stage_b2_all_conditions.png": "source_stage_b2_paired_differences.csv",
            "fig04_stability_runtime_diagnostics.png": "source_stability_runtime.csv",
        }[name]
        inventory_rows.append([purpose, "figure", f"figures/{name}", f"improved_figures/{source_name}", "see figure generation script", "see source CSV", "seed points + mean±SEM or physical-run diagnostics", "正文"])

    inventory_header = ["report_item", "item_type", "output_file", "source_file", "filter", "grouping", "statistic", "notes"]
    inventory_md = ["# 报告图表与数据来源清单", "", "| " + " | ".join(inventory_header) + " |", "|" + "|".join(["---"] * len(inventory_header)) + "|"]
    inventory_md.extend("| " + " | ".join(str(v).replace("|", r"\|") for v in row) + " |" for row in inventory_rows)
    inventory_md.extend(
        [
            "",
            "## 生成链",
            "",
            "1. `generate_report_assets.py` 读取只读 `extracted` 原始 CSV/JSON 和已审计派生表。",
            "2. `tables/*.tex`、`generated_data/*`、`figures/*` 均由本脚本生成或复制。",
            "3. 性能差值统一为 comparison adapter minus baseline adapter；不跨环境平均 accuracy 与 reward。",
            "4. 图的逐 seed 数据与 SVG/PNG 由 `improved_figures/generate_improved_figures.py` 生成。",
            "5. 原始 `extracted` 文件未被修改。",
        ]
    )
    (REPORT / "source_inventory.md").write_text("\n".join(inventory_md) + "\n", encoding="utf-8")

    artifact_audit = {
        "status": "valid",
        "tables": sorted(p.name for p in TABLES.glob("*.tex")),
        "generated_data": sorted(p.name for p in DATA.iterdir()),
        "figures": sorted(p.name for p in FIGURES.glob("*.png")),
        "figure_sha256": {p.name: sha256(p) for p in FIGURES.glob("*.png")},
        "source_package": str(PKG),
    }
    (DATA / "report_asset_manifest.json").write_text(json.dumps(artifact_audit, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(artifact_audit, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
