# 中文 LaTeX 研究报告

本目录由已完成的正式实验结果包生成，不运行新的 RL 实验，也不修改 `extracted` 中的原始文件。

## 环境

- Python：`D:\download\utilization-adapters-final-analysis\.venv\Scripts\python.exe`
- LaTeX：MiKTeX XeLaTeX
- 文档类：`article`，A4，11 pt；使用 MiKTeX 自带 Fandol 开源字体与 XeTeX 中文断行

## 重建报告资产

```powershell
& 'D:\download\utilization-adapters-final-analysis\.venv\Scripts\python.exe' `
  'D:\download\utilization-adapters-final-analysis\latex_report\generate_report_assets.py'
```

该脚本生成：

- `tables\`：自动生成的 LaTeX 表格和关键数值宏；
- `generated_data\`：报告实际使用的派生 CSV/JSON；
- `figures\`：报告实际引用的改进图副本；
- `source_inventory.md`：图表来源、筛选、分组和统计口径。

## 编译

```powershell
powershell -ExecutionPolicy Bypass -File `
  'D:\download\utilization-adapters-final-analysis\latex_report\build_report.ps1'
```

成功后生成 `report.pdf`，三遍 XeLaTeX 的完整终端编译输出保存到 `build.log`。脚本会先运行报告资产生成器，再调用 `xelatex -interaction=nonstopmode -halt-on-error main.tex` 三次，以稳定目录、引用和 longtable 宽度，因此可重复执行。此机的 `ctex` 与 LaTeX kernel 版本不同步，且 `latexmk` 的 stderr 会被 PowerShell 误判为包装器异常，所以采用任务允许的直接 XeLaTeX 回退路径。

## 目录结构

- `main.tex`：统一叙事的中文主报告；
- `report.pdf`：最终 PDF；
- `build_report.ps1`：可重复编译脚本；
- `build.log`：完整编译日志；
- `generate_report_assets.py`：表格、派生数据与图副本生成器；
- `source_inventory.md`：可追溯来源清单；
- `venue-brief.md`：本地中文内部研究报告的版式与写作约束。
