# 报告图表与数据来源清单

| report_item | item_type | output_file | source_file | filter | grouping | statistic | notes |
|---|---|---|---|---|---|---|---|
| 实验矩阵 | table | tables/experiment_matrix.tex | extracted/.../run_summaries.csv | all valid logical rows | stage | logical count; unique source count | 正文 |
| 完整性审计 | table | tables/audit_summary.tex | integrity_audit_recomputed.json + package_manifest.json | manifest-verified package | check | boolean validation and counts | 正文 |
| Stage A 代表项 | table | tables/stage_a_key.tex | run_summaries.csv | Stage A selected representative conditions | environment×condition×adapter; paired seed | mean; SEM; paired mean; W/L/T | 正文；完整表在附录 |
| Stage A 全表 | table | tables/stage_a_full.tex | run_summaries.csv | Stage A, Identity vs RFF | environment×condition; seed pairing | mean; SEM; median; W/L/T | 附录 |
| Stage B1 关键值 | table | tables/stage_b1_key.tex | run_summaries.csv | trace_only adapters + oracle identity | condition×adapter | mean; SEM; median; range | 正文 |
| Stage B1 全表 | table | tables/stage_b1_full.tex | run_summaries.csv | Stage B1 all 12 contrasts | condition×adapter pair; seed | paired mean; SEM; median; W/L/T | 附录 |
| Stage B2 关键值 | table | tables/stage_b2_key.tex | run_summaries.csv | Stage B2 all five conditions | condition×adapter pair; seed | paired mean and median | 正文 |
| Stage B2 全表 | table | tables/stage_b2_full.tex | run_summaries.csv | Stage B2 all 15 contrasts | condition×adapter pair; seed | paired mean; SEM; median; W/L/T | 附录 |
| 运行时全表 | table | tables/runtime_full.tex | run_summaries.csv | drop_duplicates(source_summary) | stage×environment×adapter | wall mean/median and identity ratio | 附录 |
| 范数诊断全表 | table | tables/diagnostic_full.tex | run_summaries.csv | all valid logical rows | stage×environment×condition×adapter | dimension and norm summaries | 附录 |
| W/L/T 全表 | table | tables/wins_losses_ties.tex | run_summaries.csv | all 55 prespecified comparisons | stage×environment×condition×contrast | sign counts by paired seed | 附录 |
| Stage A paired seed effects | figure | figures/fig01_stage_a_paired_seed_effects.png | improved_figures/source_stage_a_paired_differences.csv | see figure generation script | see source CSV | seed points + mean±SEM or physical-run diagnostics | 正文 |
| Stage B1 trace-only rescue | figure | figures/fig02_stage_b1_trace_only_rescue.png | improved_figures/source_stage_b1_trace_profiles.csv | see figure generation script | see source CSV | seed points + mean±SEM or physical-run diagnostics | 正文 |
| Stage B2 all-condition comparisons | figure | figures/fig03_stage_b2_all_conditions.png | improved_figures/source_stage_b2_paired_differences.csv | see figure generation script | see source CSV | seed points + mean±SEM or physical-run diagnostics | 正文 |
| stability and runtime diagnostics | figure | figures/fig04_stability_runtime_diagnostics.png | improved_figures/source_stability_runtime.csv | see figure generation script | see source CSV | seed points + mean±SEM or physical-run diagnostics | 正文 |

## 生成链

1. `generate_report_assets.py` 读取只读 `extracted` 原始 CSV/JSON 和已审计派生表。
2. `tables/*.tex`、`generated_data/*`、`figures/*` 均由本脚本生成或复制。
3. 性能差值统一为 comparison adapter minus baseline adapter；不跨环境平均 accuracy 与 reward。
4. 图的逐 seed 数据与 SVG/PNG 由 `improved_figures/generate_improved_figures.py` 生成。
5. 原始 `extracted` 文件未被修改。
