
# Report profile

- Target: standalone internal Chinese research analysis report (not a venue submission)
- Authoritative formatting source: pasted task specification
- Language: Chinese
- Class: ctexart, UTF8, A4, 11pt
- Engine: XeLaTeX via latexmk
- External literature/network search: prohibited by task; no bibliography claims are introduced
- Page limit: none; readability and complete appendices take priority
