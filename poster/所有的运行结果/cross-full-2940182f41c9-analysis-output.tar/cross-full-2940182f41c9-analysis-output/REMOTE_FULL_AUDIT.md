# Remote Full 结果完整性审计

## 审计结论

**链路与运行完整性通过，但存在两个必须保留的数值/展示异常。** 下载包 SHA-256、实验 commit、分支、run name、manifest、800 个唯一运行键和逐运行有限性检查均通过；`aggregate_summary.csv` 的核心数值均为有限值，所有 `run_status` 为 `ok`。异常是：

1. `condition_summary.csv` 的 `ringworld × gaussian_moment × control_td_variance_sem` 为 `Inf`。这是对极大但仍有限的逐 seed 数值计算 SEM 时发生的浮点溢出；原始 20 个逐 seed 值仍有限，本分析使用缩放后的稳定方差算法给出有限 SD/SEM/CI。该单元格不能直接用于推断。
2. `gaussian_moment` 在 E1/E2/E3、以及 E4 的 `whitened`、`standardized`、`matched` 中出现极端但有限的控制更新/参数范数。`nan_count=inf_count=divergence_flag=0` 只能证明没有触发当前的非有限值守卫，不能证明数值上稳定。

## 输入与保管链

| 项目 | 核对值 | 结论 |
|---|---|---|
| 压缩包 | `D:\download\RL_results\cross-full-2940182f41c9-analysis-core.tar.gz` | 存在，3,295,202 bytes |
| 实算 SHA-256 | `8eb6dd4c7c849a82f6f3bb8d696e8cf1442c957d10e0e0f0ffe87dc3db21f1a9` | 通过 |
| `.sha256` 文件 | 含同一 SHA-256 | 通过 |
| 解压目录 | `D:\download\RL_results\cross-full-2940182f41c9-analysis-core` | 独立目录，未覆盖来源不明文件 |
| 实验 commit | `2940182f41c9c855a26b4fd740e41907856f2f7f` | 与 manifest、仓库 HEAD 一致 |
| 分支 | `codex/cross-environment-representation-priors` | 一致 |
| run name | `cross-full-2940182f41c9` | 一致 |
| Git dirty | `false` | 干净实验出处 |

解压后要求的 `manifest.json`、`config.json`、四个汇总 CSV、`remote_launcher.log` 和 `figures/` 均存在；15 张规定 PNG 均存在并已逐张目视审计。

## 实验运行出处

| 字段 | Manifest 值 |
|---|---|
| profile | `cross_full` |
| workers | 16（命令行覆盖 config 内的 4） |
| start | `2026-07-14T08:51:52.819048+00:00` |
| end | `2026-07-14T10:06:37.777635+00:00` |
| elapsed | 约 1 小时 14 分 45 秒 |
| exit_status | `ok` |
| validation | 800 / 800 |
| host | `streamlearning-rl-gvf-research--d77e77437018-k2h7y7x2an` |
| OS | Linux 5.15 / glibc 2.35 |
| Python | 3.10.12 |
| 依赖 | numpy 1.24.4；pandas 2.2.1；matplotlib 3.8.4；pytest 8.1.1 |

实际命令为：

```text
python3 scripts/run_cross_experiment.py --config configs/cross_full.json --allow-full-run --workers 16 --run-name cross-full-2940182f41c9
```

这同时满足 full profile 的远端双重守卫要求：远端运行上下文已由服务器启动流程提供，且命令显式包含 `--allow-full-run`。

## 配置矩阵

- 环境：`tmaze`、`ringworld`、`two_loop`、`hidden_velocity`。
- 条件：10 个，分别为 `observation_only`、`oracle`、`raw`、`rms_raw`、`standardized`、`whitened`、`gaussian_moment`、`unit_sphere`、`sparse`、`matched`。
- Seeds：0–19，共 20 个。
- 期望运行数：4 × 10 × 20 = 800。
- 交互预算：T-maze 200,000；Ringworld 200,000；Two-loop 220,000；Hidden velocity 260,000。
- 所有环境使用固定 mixed predictive bank、horizons `[0.65, 0.9]` 和 16 维 trace；E1–E3 控制步长 0.006、折扣 0.98，E4 控制步长 0.002、折扣 0.95。
- 阈值：E1–E3 为准确率 0.8；E4 为移动奖励 -0.3。

`decorrelated`、`bounded` 和 `trace_only` 不在实际 full 配置中，因此没有虚构这些条件的结果或配对比较。

## 800 行完整性复算

| 检查 | 结果 |
|---|---:|
| `aggregate_summary.csv` 行数 | 800 |
| 唯一 `environment × condition × seed` | 800 |
| 重复键 | 0 |
| 缺失键 | 0 |
| 额外键 | 0 |
| 每单元 seed 数 | 20 |
| `run_status == ok` | 800 / 800 |
| `nan_count` 总和 | 0 |
| `inf_count` 总和 | 0 |
| `divergence_flag` 总和 | 0 |
| 核心数值列有限 | 是 |
| representation 一对一合并 | 800 / 800 |
| task-information 一对一合并 | 800 / 800 |
| task 指标与 summary 重叠列最大误差 | 0 |

`aggregate_summary.csv` 数值区有 8,400 个结构性 NaN，来自环境不适用的任务指标，例如 E1 没有 velocity decoding、E4 没有 cue/phase/identity 指标；这些不是运行缺失，也没有被当作零参与本分析的环境内统计。

## `condition_summary.csv` 复算

按源码相同规则重新 groupby `environment, condition` 并计算 mean/SEM，再将结构性不适用组填 0 后，所有 40 行、84 个数值汇总字段与文件一致。有限单元格最大差异为 0（在 `rtol=1e-10, atol=1e-12` 下完全一致）。

唯一非有限汇总单元格：

```text
environment=ringworld
condition=gaussian_moment
column=control_td_variance_sem
value=Inf
```

对应逐 seed 最大 `control_td_variance` 为 `5.3333e186`，全部仍为有限值。普通方差算法需要平方偏差，超过 float64 范围后得到 `Inf`。本分析的 `condition_statistics.csv` 先除以最大绝对值计算 SD，再缩放回来，因此该组的 SD/SEM/CI 保持有限。该修正只用于分析输出，没有修改原 CSV。

## 极端但有限的稳定性异常

以下阈值仅用于事后描述，不是预注册 divergence 判据：`mean_control_update_norm > 1` 或 `control_td_variance > 1e6`。

| 环境/条件 | update norm > 1 | update norm > 1e6 | TD variance > 1e6 | 主要异常 seeds |
|---|---:|---:|---:|---|
| tmaze / gaussian_moment | 7 | 6 | 7 | 1, 3, 4, 8, 9, 13, 14 |
| ringworld / gaussian_moment | 3 | 3 | 3 | 9, 10, 15 |
| two_loop / gaussian_moment | 15 | 6 | 12 | 0, 1, 2, 3, 5, 6, 7, 9, 10, 12, 13, 14, 15, 17, 18 |
| hidden_velocity / whitened | 2 | 1 | 1 | 1, 10 |
| hidden_velocity / standardized | 5 | 0 | 5 | 5, 7, 15, 18, 19 |
| hidden_velocity / matched | 7 | 1 | 6 | 2, 7, 11, 13, 14, 15, 17 |

典型极值包括：Ringworld `gaussian_moment` 的平均 control TD variance `2.67e185`、最大 `5.33e186`；T-maze 和 Two-loop `gaussian_moment` 的最大参数范数分别约 `1.34e66` 与 `1.30e65`；E4 `whitened` 的最大参数范数约 `1.19e23`。这些是有效的负面证据，不能因输出仍有限而删除。

## pandas FutureWarning

`remote_launcher.log` 记录了 `cross_experiment.py::_read_many` 中：

```python
pd.concat(frames, ignore_index=True, sort=False)
```

触发的 pandas `FutureWarning`。该 warning 没有导致失败：manifest 为 `ok`，800/800 键完整，源表合并无缺失，且 summary 与 task/condition 汇总可复算。因而它**不使当前结果无效**。它应列为兼容性维护项：未来 pandas 版本可能改变空或全 NA frame 的 dtype 推断，应在后续代码任务中显式过滤空 frame 或预声明 schema。按照本次结果审计边界，没有修改实验代码。

## 审计边界

轻量包不含 `aggregate_steps.csv`、`aggregate_decisions.csv`、`aggregate_updates.csv` 或全部 run-level 文件。因此：

- 最终性能、逐 seed 配对、终局数值稳定性和离线表示/任务信息可从当前 CSV 独立复算。
- 学习曲线、逐步更新爆发时间和决策级转折不能从原时间序列复算。
- 15 张原图可以审计，但其中时间序列图不能被重新生成验证。
- `environment_specific_latent_geometry` 与 E1–E4 专题图按源码只读取排序后的第一个 matched seed（通常为 seed 0），不是 20-seed 汇总。

## 未执行的操作

- 没有修改仓库代码或配置。
- 没有修改任何原始下载结果。
- 没有重跑 smoke、pilot、diagnostics 或 full。
- 没有调参。
- 没有 commit、push、merge 或改动 main。
- 没有下载外部数据。

完整统计解释、逐图审计和补充下载优先级见 `REMOTE_FULL_RESULTS_ANALYSIS.md`。
