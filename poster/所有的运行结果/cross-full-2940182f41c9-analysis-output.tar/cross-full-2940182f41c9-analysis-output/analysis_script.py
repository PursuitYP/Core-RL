"""Reproducible audit and statistical analysis for cross-full-2940182f41c9.

This script reads only the lightweight analysis-core export. It does not modify
the Git repository or source result files and does not rerun any experiment.
"""

from __future__ import annotations

import hashlib
import json
import math
import platform
import sys
import warnings
from datetime import datetime, timezone
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scipy
from scipy import stats


ARCHIVE = Path(r"D:\download\RL_results\cross-full-2940182f41c9-analysis-core.tar.gz")
CHECKSUM_FILE = Path(str(ARCHIVE) + ".sha256")
INPUT = Path(r"D:\download\RL_results\cross-full-2940182f41c9-analysis-core")
OUTPUT = Path(r"D:\download\RL_results\cross-full-2940182f41c9-analysis-output")
FIGURES = OUTPUT / "figures"
EXPECTED_SHA256 = "8eb6dd4c7c849a82f6f3bb8d696e8cf1442c957d10e0e0f0ffe87dc3db21f1a9"
EXPECTED_COMMIT = "2940182f41c9c855a26b4fd740e41907856f2f7f"
EXPECTED_RUN = "cross-full-2940182f41c9"
EXPECTED_BRANCH = "codex/cross-environment-representation-priors"
ENVIRONMENTS = ["tmaze", "ringworld", "two_loop", "hidden_velocity"]
CONDITIONS = [
    "observation_only", "oracle", "raw", "rms_raw", "standardized",
    "whitened", "gaussian_moment", "unit_sphere", "sparse", "matched",
]
VS_RAW = [
    "matched", "whitened", "gaussian_moment", "standardized",
    "rms_raw", "unit_sphere", "sparse",
]
SESOI = 0.02
BOOTSTRAP_RESAMPLES = 50_000
RNG_SEED = 2940182


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def finite_values(series: pd.Series, exclude_negative: bool = False) -> np.ndarray:
    values = pd.to_numeric(series, errors="coerce").to_numpy(dtype=float)
    values = values[np.isfinite(values)]
    if exclude_negative:
        values = values[values >= 0]
    return values


def summarize(values: np.ndarray) -> dict[str, float | int]:
    values = np.asarray(values, dtype=float)
    n = len(values)
    if n == 0:
        return {"n": 0, "mean": np.nan, "sd": np.nan, "sem": np.nan,
                "ci95_low": np.nan, "ci95_high": np.nan, "median": np.nan}
    mean = float(values.mean())
    # Scale before squaring so finite values as large as 1e186 retain a finite
    # sample SD instead of overflowing in the usual two-pass calculation.
    scale = float(np.max(np.abs(values)))
    sd = float(scale * (values / scale).std(ddof=1)) if n > 1 and scale > 0 else 0.0
    sem = sd / math.sqrt(n) if n else np.nan
    critical = float(stats.t.ppf(0.975, n - 1)) if n > 1 else np.nan
    half = critical * sem if n > 1 else np.nan
    return {
        "n": n, "mean": mean, "sd": sd, "sem": sem,
        "ci95_low": mean - half if n > 1 else np.nan,
        "ci95_high": mean + half if n > 1 else np.nan,
        "median": float(np.median(values)),
    }


def holm_adjust(pvalues: pd.Series) -> pd.Series:
    p = pvalues.to_numpy(dtype=float)
    m = len(p)
    order = np.argsort(p)
    adjusted_sorted = np.maximum.accumulate((m - np.arange(m)) * p[order])
    adjusted_sorted = np.minimum(adjusted_sorted, 1.0)
    adjusted = np.empty(m, dtype=float)
    adjusted[order] = adjusted_sorted
    return pd.Series(adjusted, index=pvalues.index)


def bootstrap_mean_ci(diff: np.ndarray, rng: np.random.Generator) -> tuple[float, float]:
    n = len(diff)
    means = np.empty(BOOTSTRAP_RESAMPLES, dtype=float)
    chunk = 5_000
    for start in range(0, BOOTSTRAP_RESAMPLES, chunk):
        stop = min(start + chunk, BOOTSTRAP_RESAMPLES)
        indices = rng.integers(0, n, size=(stop - start, n))
        means[start:stop] = diff[indices].mean(axis=1)
    low, high = np.quantile(means, [0.025, 0.975])
    return float(low), float(high)


def paired_row(
    summary: pd.DataFrame,
    environment: str,
    condition_a: str,
    condition_b: str,
    family: str,
    rng: np.random.Generator,
) -> dict[str, object]:
    subset = summary[
        (summary.environment == environment)
        & summary.condition.isin([condition_a, condition_b])
    ]
    pivot = subset.pivot(index="seed", columns="condition", values="final_performance")
    paired = pivot[[condition_a, condition_b]].dropna().sort_index()
    diff = (paired[condition_a] - paired[condition_b]).to_numpy(dtype=float)
    n = len(diff)
    if n < 2:
        raise RuntimeError(f"insufficient pairs for {environment} {condition_a}-{condition_b}")
    mean = float(diff.mean())
    sd = float(diff.std(ddof=1))
    boot_low, boot_high = bootstrap_mean_ci(diff, rng)
    t_result = stats.ttest_1samp(diff, 0.0)
    try:
        wilcoxon_p = float(stats.wilcoxon(diff, alternative="two-sided", method="approx").pvalue)
    except ValueError:
        wilcoxon_p = 1.0
    lower_p = float(stats.ttest_1samp(diff, -SESOI, alternative="greater").pvalue)
    upper_p = float(stats.ttest_1samp(diff, SESOI, alternative="less").pvalue)
    return {
        "environment": environment,
        "family": family,
        "condition_a": condition_a,
        "condition_b": condition_b,
        "difference_definition": f"{condition_a} - {condition_b}",
        "n_pairs": n,
        "mean_difference": mean,
        "median_difference": float(np.median(diff)),
        "sd_difference": sd,
        "sem_difference": sd / math.sqrt(n),
        "bootstrap_ci95_low": boot_low,
        "bootstrap_ci95_high": boot_high,
        "paired_effect_size_dz": mean / sd if sd > 0 else np.nan,
        "wins": int(np.sum(diff > 1e-12)),
        "ties": int(np.sum(np.abs(diff) <= 1e-12)),
        "losses": int(np.sum(diff < -1e-12)),
        "paired_t_statistic": float(t_result.statistic),
        "paired_t_p_raw_two_sided": float(t_result.pvalue),
        "wilcoxon_p_two_sided_sensitivity": wilcoxon_p,
        "equivalence_margin": SESOI,
        "tost_p_equivalence": max(lower_p, upper_p),
    }


def corr_pair(x: pd.Series, y: pd.Series) -> tuple[int, float, float, float, float]:
    frame = pd.DataFrame({"x": x, "y": y}).replace([np.inf, -np.inf], np.nan).dropna()
    n = len(frame)
    if n < 4 or frame.x.nunique() < 2 or frame.y.nunique() < 2:
        return n, np.nan, np.nan, np.nan, np.nan
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", stats.NearConstantInputWarning)
        pearson = stats.pearsonr(frame.x, frame.y)
        spearman = stats.spearmanr(frame.x, frame.y)
    return n, float(pearson.statistic), float(pearson.pvalue), float(spearman.statistic), float(spearman.pvalue)


def zscore_by(series: pd.Series, groups: pd.Series) -> pd.Series:
    def z(group: pd.Series) -> pd.Series:
        sd = group.std(ddof=0)
        return (group - group.mean()) / sd if sd > 0 else group * 0.0
    return series.groupby(groups, sort=False).transform(z)


def relationship_row(frame: pd.DataFrame, metric: str, environment: str | None) -> dict[str, object] | None:
    data = frame[["environment", "condition", "seed", "final_performance", metric]].copy()
    data = data.replace([np.inf, -np.inf], np.nan).dropna()
    if len(data) < 8 or data[metric].nunique() < 2:
        return None
    if environment is None:
        scope = "overall_environment_standardized"
        perf = zscore_by(data.final_performance, data.environment)
        geom = zscore_by(data[metric], data.environment)
        group_key = data.environment.astype(str) + "|" + data.condition.astype(str)
        means = data.groupby(["environment", "condition"], as_index=False)[["final_performance", metric]].mean()
        mean_perf = zscore_by(means.final_performance, means.environment)
        mean_geom = zscore_by(means[metric], means.environment)
        performance_definition = "within-environment z(final_performance)"
        environment_label = "all"
    else:
        scope = "within_environment"
        perf = data.final_performance
        geom = data[metric]
        group_key = data.condition
        means = data.groupby("condition", as_index=False)[["final_performance", metric]].mean()
        mean_perf = means.final_performance
        mean_geom = means[metric]
        performance_definition = "final accuracy" if environment != "hidden_velocity" else "final reward (higher is better)"
        environment_label = environment
    n, pr, pp, sr, sp = corr_pair(geom, perf)
    geom_resid = geom - geom.groupby(group_key, sort=False).transform("mean")
    perf_resid = perf - perf.groupby(group_key, sort=False).transform("mean")
    rn, rpr, rpp, rsr, rsp = corr_pair(geom_resid, perf_resid)
    bn, bpr, bpp, bsr, bsp = corr_pair(mean_geom, mean_perf)
    if bn < 4:
        confounding = "not_assessable"
    elif np.isfinite(bsr) and np.isfinite(rsr) and abs(bsr) >= 0.5 and abs(rsr) < 0.2:
        confounding = "likely_condition_driven"
    elif np.isfinite(bsr) and np.isfinite(rsr) and bsr * rsr < 0 and abs(bsr) >= 0.2 and abs(rsr) >= 0.2:
        confounding = "sign_reversal"
    else:
        confounding = "mixed_or_limited"
    return {
        "scope": scope,
        "environment": environment_label,
        "performance_definition": performance_definition,
        "metric": metric,
        "n_environments_with_data": int(data.environment.nunique()),
        "environments_with_data": ";".join(sorted(data.environment.unique())),
        "n": n,
        "pearson_r": pr,
        "pearson_p_unadjusted": pp,
        "spearman_rho": sr,
        "spearman_p_unadjusted": sp,
        "within_condition_n": rn,
        "within_condition_pearson_r": rpr,
        "within_condition_pearson_p_unadjusted": rpp,
        "within_condition_spearman_rho": rsr,
        "within_condition_spearman_p_unadjusted": rsp,
        "condition_mean_n": bn,
        "condition_mean_pearson_r": bpr,
        "condition_mean_pearson_p_unadjusted": bpp,
        "condition_mean_spearman_rho": bsr,
        "condition_mean_spearman_p_unadjusted": bsp,
        "condition_confounding_assessment": confounding,
    }


def make_figures(summary: pd.DataFrame, paired: pd.DataFrame, relationships: pd.DataFrame) -> None:
    FIGURES.mkdir(parents=True, exist_ok=True)
    plot = paired[paired.family == "vs_raw_preregistered"].copy()
    fig, axes = plt.subplots(2, 2, figsize=(13, 9))
    for ax, env in zip(axes.ravel(), ENVIRONMENTS):
        values = plot[plot.environment == env].set_index("condition_a").reindex(VS_RAW).reset_index()
        y = np.arange(len(values))
        x = values.mean_difference.to_numpy()
        low = values.bootstrap_ci95_low.to_numpy()
        high = values.bootstrap_ci95_high.to_numpy()
        ax.errorbar(x, y, xerr=np.vstack([x - low, high - x]), fmt="o", capsize=3)
        ax.axvline(0, color="black", linewidth=1)
        ax.axvspan(-SESOI, SESOI, color="gray", alpha=0.12)
        ax.set_yticks(y, values.condition_a)
        ax.set_title(env)
        ax.set_xlabel("Paired final-performance difference vs raw")
        ax.grid(axis="x", alpha=0.25)
    fig.suptitle("Paired effects versus raw (bootstrap 95% CI; gray = ±0.02)")
    fig.tight_layout()
    fig.savefig(FIGURES / "paired_effects_vs_raw.png", dpi=180, bbox_inches="tight")
    plt.close(fig)

    grouped_updates = summary.groupby(["environment", "condition"])["mean_control_update_norm"]
    med = grouped_updates.median().unstack().reindex(index=ENVIRONMENTS, columns=CONDITIONS)
    maximum = grouped_updates.max().unstack().reindex(index=ENVIRONMENTS, columns=CONDITIONS)
    matrices = [
        ("Median across seeds", np.log10(np.maximum(med.to_numpy(dtype=float), np.finfo(float).tiny))),
        ("Maximum across seeds", np.log10(np.maximum(maximum.to_numpy(dtype=float), np.finfo(float).tiny))),
    ]
    fig, axes = plt.subplots(2, 1, figsize=(14, 8.5))
    for ax, (title, matrix) in zip(axes, matrices):
        image = ax.imshow(matrix, aspect="auto", cmap="magma")
        ax.set_xticks(np.arange(len(CONDITIONS)), CONDITIONS, rotation=30, ha="right")
        ax.set_yticks(np.arange(len(ENVIRONMENTS)), ENVIRONMENTS)
        for i in range(len(ENVIRONMENTS)):
            for j in range(len(CONDITIONS)):
                ax.text(j, i, f"{matrix[i, j]:.1f}", ha="center", va="center", color="white", fontsize=8)
        ax.set_title(title)
        fig.colorbar(image, ax=ax, label="log10 mean control update norm")
    fig.suptitle("Control-update stability: typical behavior and worst-seed tails")
    fig.tight_layout()
    fig.savefig(FIGURES / "control_update_stability_log10.png", dpi=180, bbox_inches="tight")
    plt.close(fig)

    means = summary.groupby(["environment", "condition"], as_index=False)[["task_decodability", "final_performance"]].mean()
    fig, axes = plt.subplots(2, 2, figsize=(12, 9))
    for ax, env in zip(axes.ravel(), ENVIRONMENTS):
        values = means[means.environment == env]
        ax.scatter(values.task_decodability, values.final_performance, s=45)
        offsets = {
            "observation_only": (4, -10), "oracle": (4, 5), "raw": (4, -11),
            "rms_raw": (4, 6), "standardized": (-42, 9), "whitened": (4, 9),
            "gaussian_moment": (4, 6), "unit_sphere": (4, -10),
            "sparse": (4, 5), "matched": (4, 5),
        }
        if env == "hidden_velocity":
            offsets.update({
                "observation_only": (4, 7), "sparse": (4, -10),
                "gaussian_moment": (4, 8), "raw": (4, -12),
                "rms_raw": (-42, 8), "unit_sphere": (4, -11),
            })
        if env == "ringworld":
            offsets.update({"gaussian_moment": (-55, 7), "unit_sphere": (4, -10)})
        for row in values.itertuples():
            ax.annotate(
                row.condition, (row.task_decodability, row.final_performance), fontsize=7,
                xytext=offsets[row.condition], textcoords="offset points",
            )
        ax.margins(x=0.06, y=0.13)
        rho = stats.spearmanr(values.task_decodability, values.final_performance).statistic
        ax.set_title(f"{env}: condition-mean Spearman rho={rho:.2f}")
        ax.set_xlabel("Held-out task decodability")
        ax.set_ylabel("Final accuracy" if env != "hidden_velocity" else "Final reward")
        ax.grid(alpha=0.25)
    fig.suptitle("Task information versus control at condition-mean level")
    fig.tight_layout()
    fig.savefig(FIGURES / "condition_mean_task_decodability_vs_control.png", dpi=180, bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    OUTPUT.mkdir(parents=True, exist_ok=True)
    FIGURES.mkdir(parents=True, exist_ok=True)
    archive_sha = sha256(ARCHIVE)
    checksum_text = CHECKSUM_FILE.read_text(encoding="utf-8", errors="replace").lower()
    if archive_sha != EXPECTED_SHA256 or EXPECTED_SHA256 not in checksum_text:
        raise RuntimeError("archive SHA-256 verification failed")

    manifest = json.loads((INPUT / "manifest.json").read_text(encoding="utf-8"))
    config = json.loads((INPUT / "config.json").read_text(encoding="utf-8"))
    summary = pd.read_csv(INPUT / "aggregate_summary.csv")
    supplied_condition = pd.read_csv(INPUT / "condition_summary.csv")
    representation = pd.read_csv(INPUT / "aggregate_representation.csv")
    task = pd.read_csv(INPUT / "aggregate_task_information.csv")

    keys = ["environment", "condition", "seed"]
    expected_keys = pd.MultiIndex.from_product([ENVIRONMENTS, CONDITIONS, range(20)], names=keys)
    actual_keys = pd.MultiIndex.from_frame(summary[keys])
    missing_keys = expected_keys.difference(actual_keys)
    extra_keys = actual_keys.difference(expected_keys)
    duplicate_keys = int(summary.duplicated(keys).sum())
    numeric = summary.select_dtypes(include=[np.number])
    nonfinite_numeric = int((~np.isfinite(numeric.to_numpy(dtype=float))).sum())

    recomputed_parts: list[pd.DataFrame] = []
    numeric_columns = summary.select_dtypes(include=[np.number]).columns.tolist()
    grouped = summary.groupby(["environment", "condition"], sort=False)[numeric_columns]
    recomputed_parts.append(grouped.mean().add_suffix("_mean"))
    recomputed_parts.append(grouped.sem().fillna(0.0).add_suffix("_sem"))
    # The executable aggregator fills structurally inapplicable group means and
    # SEMs with zero; reproduce that exact convention for the reconciliation.
    recomputed_condition = pd.concat(recomputed_parts, axis=1).fillna(0.0).reset_index()
    common = [c for c in supplied_condition.columns if c in recomputed_condition.columns and c not in keys]
    supplied_sorted = supplied_condition.sort_values(keys[:2]).reset_index(drop=True)
    recomputed_sorted = recomputed_condition.sort_values(keys[:2]).reset_index(drop=True)
    supplied_array = supplied_sorted[common].to_numpy(dtype=float)
    recomputed_array = recomputed_sorted[common].to_numpy(dtype=float)
    close_mask = np.isclose(supplied_array, recomputed_array, rtol=1e-10, atol=1e-12, equal_nan=True)
    condition_allclose = bool(close_mask.all())
    finite_pair = np.isfinite(supplied_array) & np.isfinite(recomputed_array)
    finite_mismatch = finite_pair & ~close_mask
    condition_max_abs_error = (
        float(np.max(np.abs(supplied_array[finite_mismatch] - recomputed_array[finite_mismatch])))
        if finite_mismatch.any() else 0.0
    )

    stat_metrics = [
        "final_performance", "cumulative_reward", "predictive_td_mse",
        "control_td_variance", "mean_control_update_norm", "max_control_update_norm",
        "final_parameter_norm", "time_to_threshold", "overall_accuracy",
        "final_window_accuracy", "mean_reward", "final_window_reward",
        "stabilization_rate", "final_window_stabilization", "control_cost",
        "task_decodability", "cue_decodability", "cue_margin", "between_within_ratio",
        "phase_r2", "phase_absolute_error", "circular_correlation", "neighborhood_preservation",
        "identity_decodability", "identity_margin", "joint_state_decodability",
        "velocity_decoding_mse", "velocity_decoding_r2", "state_estimation_error",
    ]
    condition_rows: list[dict[str, object]] = []
    for (environment, condition), group in summary.groupby(["environment", "condition"], sort=False):
        row: dict[str, object] = {"environment": environment, "condition": condition, "n_seeds": len(group)}
        for metric in stat_metrics:
            if metric not in group:
                continue
            if metric == "time_to_threshold":
                reached = finite_values(group[metric], exclude_negative=True)
                row["time_to_threshold_reached_n"] = len(reached)
                row["time_to_threshold_reached_fraction"] = len(reached) / len(group)
                values = reached
                prefix = "time_to_threshold_reached"
            else:
                values = finite_values(group[metric])
                prefix = metric
            values_summary = summarize(values)
            for name, value in values_summary.items():
                row[f"{prefix}_{name}"] = value
            if metric in {"control_td_variance", "mean_control_update_norm", "max_control_update_norm", "final_parameter_norm"}:
                row[f"{metric}_max"] = float(values.max()) if len(values) else np.nan
        row["descriptive_count_control_td_variance_gt_1e6"] = int((group.control_td_variance > 1e6).sum())
        row["descriptive_count_mean_control_update_norm_gt_1"] = int((group.mean_control_update_norm > 1).sum())
        row["descriptive_count_mean_control_update_norm_gt_1e6"] = int((group.mean_control_update_norm > 1e6).sum())
        row["descriptive_count_final_parameter_norm_gt_1e6"] = int((group.final_parameter_norm > 1e6).sum())
        condition_rows.append(row)
    condition_stats = pd.DataFrame(condition_rows).sort_values(keys[:2]).reset_index(drop=True)
    condition_stats.to_csv(OUTPUT / "condition_statistics.csv", index=False)

    rng = np.random.default_rng(RNG_SEED)
    paired_rows: list[dict[str, object]] = []
    actual_conditions = set(summary.condition.unique())
    for environment in ENVIRONMENTS:
        for condition in VS_RAW:
            if condition in actual_conditions:
                paired_rows.append(paired_row(summary, environment, condition, "raw", "vs_raw_preregistered", rng))
        paired_rows.append(paired_row(summary, environment, "raw", "observation_only", "benchmark_context", rng))
        paired_rows.append(paired_row(summary, environment, "oracle", "raw", "benchmark_context", rng))
    paired = pd.DataFrame(paired_rows)
    paired["paired_t_p_holm_within_environment_family"] = np.nan
    for _, indices in paired.groupby(["environment", "family"]).groups.items():
        paired.loc[indices, "paired_t_p_holm_within_environment_family"] = holm_adjust(
            paired.loc[indices, "paired_t_p_raw_two_sided"]
        )
    def evidence(row: pd.Series) -> str:
        if row.paired_t_p_holm_within_environment_family < 0.05:
            return "clear_positive_evidence" if row.mean_difference > 0 else "clear_negative_evidence"
        if row.tost_p_equivalence < 0.05:
            return "effect_close_to_zero_within_0.02"
        return "insufficient_evidence"
    paired["evidence_classification"] = paired.apply(evidence, axis=1)
    paired.to_csv(OUTPUT / "paired_comparisons.csv", index=False)

    merged = summary.merge(representation, on=keys, how="inner", validate="one_to_one", suffixes=("", "_rep"))
    merged = merged.merge(task, on=keys, how="inner", validate="one_to_one", suffixes=("", "_task"))
    relationship_metrics = [
        "effective_rank", "isotropy_error", "condition_number", "mean_abs_corr",
        "variance_imbalance", "mean_error", "skewness_error", "kurtosis_error",
        "norm_mean", "norm_var", "norm_max", "active_dimensions", "mean_active_dimensions",
        "near_zero_fraction", "transformed_rms", "transform_condition_number",
        "transform_matrix_change_last", "transform_matrix_change_mean",
        "transform_matrix_change_max", "transform_refreshes", "active_fraction",
        "bounded_max_abs", "gaussian_parameter_change_mean", "gaussian_parameter_change_max",
        "gaussian_ew_skewness_error", "gaussian_ew_kurtosis_error", "matched_output_norm",
        "anisotropic_target_ratio", "circle_radius_error", "simplex_sum_error",
        "task_decodability", "cue_decodability", "cue_mean_distance", "cue_margin",
        "between_within_ratio", "phase_mse", "phase_r2", "phase_absolute_error",
        "circular_correlation", "neighborhood_preservation", "identity_decodability",
        "identity_margin", "joint_state_decodability", "velocity_decoding_mse",
        "velocity_decoding_r2", "state_estimation_error",
    ]
    relationship_rows: list[dict[str, object]] = []
    for metric in relationship_metrics:
        if metric not in merged:
            continue
        row = relationship_row(merged, metric, None)
        if row is not None:
            relationship_rows.append(row)
        for environment in ENVIRONMENTS:
            row = relationship_row(merged[merged.environment == environment], metric, environment)
            if row is not None:
                relationship_rows.append(row)
    relationships = pd.DataFrame(relationship_rows)
    relationships.to_csv(OUTPUT / "geometry_control_relationships.csv", index=False)

    lookup = paired.set_index(["environment", "condition_a", "condition_b"])
    def ev(env: str, cond: str) -> pd.Series:
        return lookup.loc[(env, cond, "raw")]
    reconciliation = pd.DataFrame([
        {
            "pilot_observation": "E1 approximately null",
            "classification": "Not supported",
            "remote_full_numeric_evidence": (
                f"whitened-raw={ev('tmaze','whitened').mean_difference:+.4f} "
                f"[{ev('tmaze','whitened').bootstrap_ci95_low:+.4f}, {ev('tmaze','whitened').bootstrap_ci95_high:+.4f}], "
                f"standardized-raw={ev('tmaze','standardized').mean_difference:+.4f}; both Holm classifications="
                f"{ev('tmaze','whitened').evidence_classification}, {ev('tmaze','standardized').evidence_classification}."
            ),
        },
        {
            "pilot_observation": "E2 uncertain",
            "classification": "Partially supported",
            "remote_full_numeric_evidence": (
                f"Pilot positive direction persisted but uncertainty narrowed: whitened-raw={ev('ringworld','whitened').mean_difference:+.4f}, "
                f"standardized-raw={ev('ringworld','standardized').mean_difference:+.4f}, "
                f"gaussian_moment-raw={ev('ringworld','gaussian_moment').mean_difference:+.4f}."
            ),
        },
        {
            "pilot_observation": "E3 positive signals for several conditioning methods",
            "classification": "Partially supported",
            "remote_full_numeric_evidence": (
                f"whitened-raw={ev('two_loop','whitened').mean_difference:+.4f}, standardized-raw={ev('two_loop','standardized').mean_difference:+.4f}; "
                f"gaussian_moment-raw={ev('two_loop','gaussian_moment').mean_difference:+.4f} and matched-raw={ev('two_loop','matched').mean_difference:+.4f}."
            ),
        },
        {
            "pilot_observation": "E4 often favors raw",
            "classification": "Partially supported",
            "remote_full_numeric_evidence": (
                f"raw beats matched ({ev('hidden_velocity','matched').mean_difference:+.4f}), standardized ({ev('hidden_velocity','standardized').mean_difference:+.4f}), "
                f"and whitened ({ev('hidden_velocity','whitened').mean_difference:+.4f}), but gaussian_moment-raw={ev('hidden_velocity','gaussian_moment').mean_difference:+.4f} "
                f"and rms_raw-raw={ev('hidden_velocity','rms_raw').mean_difference:+.4f} favor transforms."
            ),
        },
        {
            "pilot_observation": "Task-matched priors do not help universally",
            "classification": "Supported",
            "remote_full_numeric_evidence": (
                f"matched-raw: tmaze {ev('tmaze','matched').mean_difference:+.4f}, ringworld {ev('ringworld','matched').mean_difference:+.4f}, "
                f"two_loop {ev('two_loop','matched').mean_difference:+.4f}, hidden_velocity {ev('hidden_velocity','matched').mean_difference:+.4f}; heterogeneous signs/evidence."
            ),
        },
    ])
    reconciliation.to_csv(OUTPUT / "pilot_full_reconciliation.csv", index=False)

    make_figures(summary, paired, relationships)

    task_overlap = [c for c in task.columns if c in summary.columns and c not in keys]
    task_match_max_error = 0.0
    for column in task_overlap:
        left = summary[keys + [column]].sort_values(keys)[column].reset_index(drop=True)
        right = task[keys + [column]].sort_values(keys)[column].reset_index(drop=True)
        mask = left.notna() & right.notna()
        if mask.any():
            task_match_max_error = max(task_match_max_error, float(np.max(np.abs(left[mask] - right[mask]))))

    expected_runs = len(ENVIRONMENTS) * len(CONDITIONS) * 20
    key_numeric_columns = [
        "final_performance", "cumulative_reward", "predictive_td_mse",
        "control_td_variance", "mean_control_update_norm", "max_control_update_norm",
        "final_parameter_norm", "time_to_threshold", "nan_count", "inf_count",
        "divergence_flag",
    ]
    summary_numeric_array = numeric.to_numpy(dtype=float)
    condition_numeric_array = supplied_condition.select_dtypes(include=[np.number]).to_numpy(dtype=float)
    audit = {
        "archive_sha256_pass": archive_sha == EXPECTED_SHA256 and EXPECTED_SHA256 in checksum_text,
        "manifest_commit_pass": manifest.get("git_commit") == EXPECTED_COMMIT,
        "manifest_branch_pass": manifest.get("git_branch") == EXPECTED_BRANCH,
        "manifest_run_name_pass": manifest.get("run_name") == EXPECTED_RUN,
        "manifest_exit_status": manifest.get("exit_status"),
        "rows": len(summary),
        "expected_rows": expected_runs,
        "duplicate_keys": duplicate_keys,
        "missing_keys": len(missing_keys),
        "extra_keys": len(extra_keys),
        "all_run_status_ok": bool(summary.run_status.eq("ok").all()),
        "nan_count_sum": int(summary.nan_count.sum()),
        "inf_count_sum": int(summary.inf_count.sum()),
        "divergence_flag_sum": int(summary.divergence_flag.sum()),
        "aggregate_summary_numeric_nan_cells_structural": int(np.isnan(summary_numeric_array).sum()),
        "aggregate_summary_numeric_inf_cells": int(np.isinf(summary_numeric_array).sum()),
        "aggregate_summary_key_numeric_all_finite": bool(
            np.isfinite(summary[key_numeric_columns].to_numpy(dtype=float)).all()
        ),
        "condition_summary_numeric_inf_cells": int(np.isinf(condition_numeric_array).sum()),
        "condition_summary_allclose": condition_allclose,
        "condition_summary_max_abs_error": condition_max_abs_error,
        "representation_merge_rows": len(merged),
        "task_summary_overlap_max_abs_error": task_match_max_error,
        "conditions_present": sorted(summary.condition.unique().tolist()),
        "conditions_requested_but_absent": [c for c in ["decorrelated", "bounded", "trace_only"] if c not in actual_conditions],
    }

    artifact_paths = [p for p in OUTPUT.rglob("*") if p.is_file() and p.name != "analysis_manifest.json"]
    analysis_manifest = {
        "analysis_name": "cross-full-2940182f41c9 strict remote-full audit",
        "input_archive": str(ARCHIVE),
        "input_archive_sha256": archive_sha,
        "input_directory": str(INPUT),
        "experiment_commit": EXPECTED_COMMIT,
        "experiment_branch": EXPECTED_BRANCH,
        "run_name": EXPECTED_RUN,
        "analysis_timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "analysis_python": sys.version,
        "analysis_platform": platform.platform(),
        "analysis_dependencies": {
            "numpy": np.__version__, "pandas": pd.__version__,
            "scipy": scipy.__version__, "matplotlib": matplotlib.__version__,
        },
        "experiment_runtime_from_manifest": {
            "python": manifest.get("python_version"),
            "dependencies": manifest.get("dependency_versions"),
        },
        "methods": {
            "confidence_intervals": "two-sided t 95% CI for condition means",
            "paired_bootstrap": f"percentile bootstrap, {BOOTSTRAP_RESAMPLES} resamples, seed {RNG_SEED}",
            "paired_test": "two-sided one-sample paired t-test on seed differences",
            "sensitivity_test": "two-sided Wilcoxon signed-rank",
            "multiplicity": "Holm FWER correction within environment and comparison family",
            "equivalence": f"TOST with absolute margin {SESOI}",
            "correlations": "Pearson and Spearman; exploratory unadjusted p-values; overall variables standardized within environment",
            "condition_confounding": "compare raw, within-environment-condition residual, and condition-mean correlations",
        },
        "audit": audit,
        "source_files": {
            p.name: {"path": str(p), "bytes": p.stat().st_size, "sha256": sha256(p)}
            for p in [INPUT / "manifest.json", INPUT / "config.json", INPUT / "aggregate_summary.csv",
                      INPUT / "condition_summary.csv", INPUT / "aggregate_representation.csv",
                      INPUT / "aggregate_task_information.csv", INPUT / "remote_launcher.log"]
        },
        "output_files": [
            {"path": str(p), "bytes": p.stat().st_size, "sha256": sha256(p)}
            for p in sorted(artifact_paths)
        ],
    }
    (OUTPUT / "analysis_manifest.json").write_text(
        json.dumps(analysis_manifest, indent=2, ensure_ascii=False), encoding="utf-8"
    )

    print(json.dumps(audit, indent=2))


if __name__ == "__main__":
    main()
