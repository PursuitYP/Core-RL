# Cross-Environment Remote Full 科研结果分析

## 结论先行

20-seed remote full 结果不支持“某一种通用几何约束在所有部分可观测任务中都改善严格 streaming 控制”的规律。最稳健的正面结果是：**second-order whitening 在 T-maze、Ringworld 和 Two-loop 中都显著优于 raw，并在 Ringworld 几乎达到 oracle；但在 Hidden velocity 中出现少数灾难性 seed，因此不具备跨环境可靠性。**

任务匹配先验同样高度异质：`matched - raw` 在 Ringworld 为明确正向，在 T-maze 和 Two-loop 证据不足，在 Hidden velocity 为明确负向。`gaussian_moment` 也不是通用改进：它在 Ringworld 和 Hidden velocity 的最终性能上优于 raw，但在前三个离散环境中暴露出极端有限值更新，不能仅凭最终分数视为稳定方法。

表示性质与控制收益确实相关，但不是充分条件。总体 `task_decodability` 与控制的 Spearman 相关为 0.524；按 environment×condition 去均值后仍为 0.321，高于 isotropy error 的 -0.107。但环境内反例很多，相关也受到 condition 分组影响，不能解释为因果。

## 研究问题与设计边界

研究问题是：在保持 GVF questions 和线性 streaming controller 固定时，预测特征的统计/几何性质是否改善部分可观测控制。所有 transition 只处理一次；online transform 只使用当前之前的统计；held-out probes 和 latent labels 仅用于离线分析，不反馈给 agent。

四个任务为：

- **T-maze**：cue 后经过无辨识走廊，在别名 junction 选择与延迟 cue 一致的动作。最终性能是最后 2,000 交互窗口内 junction accuracy。
- **Ringworld**：确定性 12-state 环，两处 decision observation 相同但正确动作相反；历史 landmark 提供相位信息。最终性能是最后窗口 decision accuracy。
- **Two-loop**：长度 8/10 的两个循环，短暂 identity cue、phase landmark 和别名 decision 共同要求 identity 与 phase 记忆。最终性能是最后窗口 decision accuracy。
- **Hidden velocity**：只观测 position 相关量，不直接观测 velocity 的一维连续控制；奖励是位置、速度和动作成本的负值。最终性能是最后窗口 reward，越接近 0 越好。

条件含义：

- `observation_only`：控制器只接收 observation，不接预测状态。
- `oracle`：控制器接收真正 latent state 的隔离上界；oracle 信息不进入 predictive 方法。
- `raw`：未变换的在线 GVF prediction vector。
- `rms_raw`：仅用历史全局 RMS 做尺度归一，不中心化。
- `standardized`：用历史均值/方差逐维标准化。
- `whitened`：用历史 full covariance 做 second-order whitening；不是 Gaussian transform。
- `gaussian_moment`：whitening 后的探索性 online skew/tail moment shaping，不提供分布保证。
- `unit_sphere`：逐样本单位范数。
- `sparse`：保留绝对值最大的 top-k 分量。
- `matched`：T-maze simplex、Ringworld circle、Two-loop simplex+circle block、Hidden velocity anisotropic scaling；输入仍只来自 predictive features。

`decorrelated`、`bounded`、`trace_only` 未在实际 full config 执行，所以没有结果行。

## 指标与统计方法

- `predictive_td_mse`：预测 bank 的 streaming TD error 平方均值。
- `control_td_variance`：控制 TD error 的方差。
- update/parameter norms：在线更新和最终线性参数规模。
- representation 指标在 10,000-sample reservoir 上离线计算，包括 effective rank、isotropy error、condition number、correlation、moment 和 norm 指标。
- task information 使用确定性的 grouped held-out ridge probe：T-maze cue decoding；Ringworld circular phase；Two-loop identity/joint state；Hidden velocity velocity decoding R²/MSE。

每个 condition 的 mean、SD、SEM、t-based 95% CI 和 median 基于 20 seeds。配对统计使用相同 seed 的 `condition - raw`；报告 50,000 次 percentile bootstrap CI、paired Cohen's dz、wins/ties/losses、双侧 paired t-test、Wilcoxon sensitivity，并在每个环境的七项 preregistered-vs-raw family 内做 Holm FWER 校正。`p > 0.05` 不被解释为相等；只有 TOST 在 ±0.02 界内通过时才标记“接近零”，本批次这些比较均未达到该等价证据门槛。

## Final performance 全表

表中为 mean [95% CI]；E1–E3 是 accuracy，E4 是 reward，不能跨列比较绝对值。

| Condition | T-maze | Ringworld | Two-loop | Hidden velocity |
|---|---:|---:|---:|---:|
| observation_only | 0.4987 [0.4928, 0.5046] | 0.4994 [0.4981, 0.5007] | 0.4958 [0.4902, 0.5014] | -0.1002 [-0.1139, -0.0865] |
| oracle | 0.9761 [0.9747, 0.9774] | 0.9746 [0.9732, 0.9760] | 0.9712 [0.9697, 0.9727] | -0.1043 [-0.1209, -0.0876] |
| raw | 0.6806 [0.6204, 0.7408] | 0.7093 [0.5944, 0.8242] | 0.5283 [0.5080, 0.5487] | -0.2231 [-0.2740, -0.1722] |
| rms_raw | 0.6697 [0.6123, 0.7272] | 0.6840 [0.5706, 0.7974] | 0.5685 [0.5318, 0.6052] | -0.1000 [-0.1074, -0.0926] |
| standardized | 0.7562 [0.7031, 0.8093] | 0.9744 [0.9729, 0.9759] | 0.6615 [0.6124, 0.7106] | -1.7724 [-2.6447, -0.9000] |
| whitened | 0.7673 [0.7141, 0.8205] | 0.9745 [0.9730, 0.9759] | 0.7543 [0.6743, 0.8344] | -0.3480 [-0.7090, 0.0129] |
| gaussian_moment | 0.6290 [0.5565, 0.7014] | 0.9000 [0.8150, 0.9850] | 0.5257 [0.4858, 0.5656] | -0.1226 [-0.1594, -0.0858] |
| unit_sphere | 0.6550 [0.5987, 0.7114] | 0.8992 [0.8175, 0.9810] | 0.5289 [0.4892, 0.5686] | -0.1009 [-0.1146, -0.0873] |
| sparse | 0.6680 [0.6263, 0.7096] | 0.7323 [0.6525, 0.8121] | 0.5245 [0.4816, 0.5674] | -0.0997 [-0.1107, -0.0888] |
| matched | 0.6939 [0.6413, 0.7466] | 0.9266 [0.8572, 0.9959] | 0.5345 [0.5192, 0.5497] | -1.0817 [-1.8342, -0.3293] |

完整的 cumulative reward、predictive/control diagnostics、time-to-threshold 和环境特有指标见 `condition_statistics.csv`。

## 分环境结果

### E1 T-maze

Oracle 为 0.9761；最佳非 oracle 是 whitened 0.7673，其次 standardized 0.7562。Raw 0.6806 已明显优于 observation-only 0.4987：配对差 +0.1819 [0.1316, 0.2370]，Holm p=2.77e-6；但 raw 并不“足够”，因为 whitening 和 standardization 进一步分别提高 +0.0867 和 +0.0756。

Whitened 20/20 seeds 胜过 raw，unit-sphere 则 18/20 更差。Matched 的平均增益只有 +0.0133，证据不足。Gaussian moment 平均低于 raw -0.0516；bootstrap CI 为负，但 paired t 在 Holm 校正后不显著，因此保守归类为证据不足，同时其 7/20 seeds 出现 update norm >1，不能视为稳定候选。

Threshold 0.8：oracle 20/20 在平均 382 步达到；whitened 13/20、standardized 11/20；raw 仅 5/20；observation-only 为 0/20。到达时间只对达到阈值的 seeds 取平均。

### E2 Ringworld

Oracle 0.9746、whitened 0.97445、standardized 0.97443 在最终均值上几乎持平。Raw 的均值 0.7093，但 median 仅 0.4955，说明明显 seed 双峰/异质性；whitening 与 standardization 都把 median 提高到约 0.9745。

相对 raw，whitened +0.2652、standardized +0.2651、matched +0.2173、gaussian_moment +0.1907、unit-sphere +0.1900，均为 Holm 校正后的明确正向证据。RMS-only scaling 与 sparse 证据不足。Matched 的平均值低于 whitened，且仍有少数失败 seed，因而“任务匹配”不是本环境最佳解释。

Threshold：oracle、whitened、standardized 和 gaussian_moment 为 20/20；matched 19/20；raw 9/20。Gaussian moment 的最终性能信号为正，但 seeds 9、10、15 产生极端更新，最大 control TD variance 达 5.33e186，因此不能只按 bar height 推荐。

### E3 Two-loop

Oracle 0.9712；最佳非 oracle 是 whitened 0.7543，standardized 0.6615 次之。两者相对 raw 的增益分别为 +0.2260 和 +0.1332，均为明确正向。Raw 0.5283 仅小幅优于 observation-only 0.4958，但配对差 +0.0325 [0.0164, 0.0547] 仍是明确正向。

Pilot 中 matched 和 gaussian_moment 的正面迹象没有扩展：matched-raw +0.0062、gaussian_moment-raw -0.0026，均证据不足。尤其 gaussian_moment 有 15/20 seeds 的平均 update norm >1、12/20 的 control TD variance >1e6，是最系统的稳定性失败。

Gaussian moment 有 16/20 seeds 曾越过 0.8 threshold，且 cumulative reward 均值 5,409.6，高于 raw 1,321.9，但最终 accuracy 仅 0.5257。这暗示可能存在短暂学习后退化；由于轻量包缺失 `aggregate_steps.csv`，当前不能重建其时间进程。

### E4 Hidden velocity

按最终均值看，sparse -0.0997、rms_raw -0.1000、observation-only -0.1002、unit-sphere -0.1009 和 oracle -0.1043 基本成一组。Raw -0.2231 明显更差；raw-observation 的配对差为 -0.1229 [-0.1740, -0.0773]。因此本环境不是“predictive features 必然有利”，而是 raw prediction magnitude/conditioning 明显有害，简单缩放或稀疏化将性能恢复到 observation baseline 附近。

Gaussian moment 相对 raw +0.1005，为明确正向，但其最终均值仍略低于 observation-only。Matched - raw 为 -0.8586，standardized - raw 为 -1.5493，均明确负向。Whitened 的均值差 -0.1249，证据不足；值得注意的是它有 17 wins / 3 losses、median paired difference +0.0778，但三个失败 seed 把 mean 拉成负值。这是典型的高尾部风险，不能用“多数 seed 胜出”掩盖。

E4 的 `whitened` 最大 parameter norm 1.19e23；`matched` 与 `standardized` 也出现大规模有限值爆发。所有条件大多很早越过 -0.3 threshold，说明这个 threshold 不足以预测终局稳定性。

## 全部 vs-raw 配对结果

差值为 condition - raw；W/T/L 为 wins/ties/losses；p 为环境内七项 family 的 Holm p。

| Environment | Condition | Mean difference [bootstrap 95% CI] | W/T/L | dz | Holm p | Evidence |
|---|---|---:|---:|---:|---:|---|
| tmaze | matched | +0.0133 [-0.0108, +0.0338] | 14/0/6 | +0.25 | 0.545 | insufficient |
| tmaze | whitened | +0.0867 [+0.0640, +0.1103] | 20/0/0 | +1.60 | 6.07e-06 | positive |
| tmaze | gaussian_moment | -0.0516 [-0.0998, -0.0045] | 8/0/12 | -0.46 | 0.207 | insufficient |
| tmaze | standardized | +0.0756 [+0.0488, +0.1038] | 18/0/2 | +1.17 | 0.000279 | positive |
| tmaze | rms_raw | -0.0109 [-0.0224, -0.0003] | 8/0/12 | -0.42 | 0.221 | insufficient |
| tmaze | unit_sphere | -0.0256 [-0.0387, -0.0140] | 2/0/18 | -0.88 | 0.00439 | negative |
| tmaze | sparse | -0.0126 [-0.0394, +0.0096] | 10/0/10 | -0.22 | 0.545 | insufficient |
| ringworld | matched | +0.2173 [+0.0970, +0.3374] | 15/4/1 | +0.75 | 0.0109 | positive |
| ringworld | whitened | +0.2652 [+0.1686, +0.3616] | 16/4/0 | +1.08 | 0.000798 | positive |
| ringworld | gaussian_moment | +0.1907 [+0.0921, +0.2902] | 14/4/2 | +0.78 | 0.0109 | positive |
| ringworld | standardized | +0.2651 [+0.1686, +0.3616] | 15/4/1 | +1.08 | 0.000798 | positive |
| ringworld | rms_raw | -0.0253 [-0.1224, +0.0716] | 5/2/13 | -0.10 | 1.000 | insufficient |
| ringworld | unit_sphere | +0.1900 [+0.0939, +0.2868] | 13/3/4 | +0.79 | 0.0109 | positive |
| ringworld | sparse | +0.0230 [-0.1126, +0.1532] | 11/0/9 | +0.07 | 1.000 | insufficient |
| two_loop | matched | +0.0062 [-0.0211, +0.0274] | 11/0/9 | +0.11 | 1.000 | insufficient |
| two_loop | whitened | +0.2260 [+0.1497, +0.3023] | 18/1/1 | +1.27 | 0.000128 | positive |
| two_loop | gaussian_moment | -0.0026 [-0.0382, +0.0400] | 5/0/15 | -0.03 | 1.000 | insufficient |
| two_loop | standardized | +0.1332 [+0.0836, +0.1852] | 19/0/1 | +1.12 | 0.000486 | positive |
| two_loop | rms_raw | +0.0402 [+0.0051, +0.0769] | 11/0/9 | +0.47 | 0.241 | insufficient |
| two_loop | unit_sphere | +0.0006 [-0.0338, +0.0478] | 6/0/14 | +0.01 | 1.000 | insufficient |
| two_loop | sparse | -0.0038 [-0.0423, +0.0470] | 5/0/15 | -0.04 | 1.000 | insufficient |
| hidden_velocity | matched | -0.8586 [-1.5976, -0.2564] | 8/0/12 | -0.54 | 0.0499 | negative |
| hidden_velocity | whitened | -0.1249 [-0.4943, +0.1383] | 17/0/3 | -0.16 | 0.470 | insufficient |
| hidden_velocity | gaussian_moment | +0.1005 [+0.0444, +0.1583] | 17/0/3 | +0.75 | 0.00959 | positive |
| hidden_velocity | standardized | -1.5493 [-2.3774, -0.7732] | 7/0/13 | -0.82 | 0.00624 | negative |
| hidden_velocity | rms_raw | +0.1231 [+0.0779, +0.1749] | 19/0/1 | +1.07 | 0.000737 | positive |
| hidden_velocity | unit_sphere | +0.1222 [+0.0743, +0.1742] | 19/0/1 | +1.04 | 0.000878 | positive |
| hidden_velocity | sparse | +0.1234 [+0.0777, +0.1739] | 18/0/2 | +1.10 | 0.000651 | positive |

## 表示性质与控制性能

### Whitening 改善二阶几何，但收益不是必然

平均 isotropy error 从 raw 到 whitened 分别为：T-maze 5.44→2.99，Ringworld 4.75→3.25，Two-loop 5.89→2.23，Hidden velocity 6.18→1.93。即 whitening 在四环境都按预期改善了 second-order geometry；前三环境同时改善控制，而 E4 的 mean effect 受灾难 seed 拉低且证据不足。这直接表明“性质达成”和“下游可靠收益”可以分离。

### Task information 通常比 generic isotropy 更有解释力，但不普适

核心 Spearman 结果：

| Metric | Overall | Within env×condition residual | Condition means | Interpretation |
|---|---:|---:|---:|---|
| task_decodability | +0.524 | +0.321 | +0.509 | 总体最强核心关系，但部分来自 condition 差异 |
| isotropy_error | -0.286 | -0.107 | -0.391 | 低误差通常较好；seed 内关系很弱 |
| effective_rank | -0.010 | +0.172 | -0.113 | rank 本身几乎无总体解释力 |
| condition_number | -0.119 | +0.159 | -0.117 | 弱且方向不稳定 |
| mean_abs_corr | -0.275 | -0.397 | -0.304 | 去相关与性能有一定关系，但仍非因果 |
| skewness_error | -0.255 | +0.232 | -0.405 | 去组后反号，典型 confounding |
| kurtosis_error | +0.060 | +0.250 | -0.176 | 方向不稳定 |

分环境看，T-maze task decodability 的 rho=0.802、residual rho=0.727，关系最可靠。Two-loop raw rho=0.558、condition-mean rho=0.721，但 residual 仅 0.170，主要是条件间结构。Ringworld 为 0.258/0.058，Hidden velocity 为 0.152/0.189，都很弱。因此不能说 task decodability 在每个任务都充分解释控制。

还有直接反例：Ringworld、T-maze 和 Two-loop 的 raw task-decoding 均值分别约 0.813、0.793、0.739，均高于对应 whitened 的 0.757、0.771、0.711，但 whitening 控制表现更好。Task information、conditioning 与控制更新规模共同决定结果。

### Matched prior 达成结构不等于产生效用

源码和诊断显示 matched 输出满足命名结构：simplex 和 circle 约束误差接近 0，Hidden velocity 的目标 anisotropic ratio 为 9。原图也显示 E1 simplex、E2 circle、E3 block structure。可是控制结果只有 Ringworld 明确受益，T-maze/Two-loop 证据不足，Hidden velocity 明确受害。因此结构实现与下游效用必须分开报告。

### Gaussian moment 的结论

`gaussian_moment` 只能称为在线 moment-shaping extension。它在 Ringworld 和 E4 相对 raw 的最终分数为正，但没有跨环境一致性，也没有分布保证。E1/E2/E3 的极端 update/TD/parameter values 是决定性稳定性反证；最终窗口看似正常并不抵消这些失败。

完整 Pearson/Spearman、p 值、environment-specific、within-condition residual 和 condition-mean 分解见 `geometry_control_relationships.csv`。所有相关分析为探索性，p 值未作多重校正，且不作因果解释。

## Pilot 与 Remote Full 对照

| Pilot observation | Classification | Remote full evidence |
|---|---|---|
| E1 approximately null | Not supported | whitened-raw +0.0867、standardized-raw +0.0756，均明确正向 |
| E2 uncertain | Partially supported | 正向方向保留，但 full 已将 whitening/standardization/moment 的不确定性明显收窄 |
| E3 positive signals for several conditioning methods | Partially supported | whitening/standardization 保留；gaussian_moment 和 matched 不再有明确增益 |
| E4 often favors raw | Partially supported | raw 胜 matched/standardized，whitened 有尾部风险；但 rms_raw/unit_sphere/sparse/gaussian_moment 均明显胜 raw |
| task-matched priors do not help universally | Supported | 四环境 matched-raw 依次 +0.0133、+0.2173、+0.0062、-0.8586 |

该对照没有为了维护 pilot 叙述而忽略 full 结果。逐行版本见 `pilot_full_reconciliation.csv`。

## 15 张原始图逐图审计

| Figure | 数据与主要现象 | CSV 一致性/问题 | 能支持与不能支持的结论 |
|---|---|---|---|
| `control_learning_curves_by_environment.png` | `aggregate_steps.csv` 的 moving performance mean±SEM | 终点大致符合 summary，但存在大量从终点折返起点的直线/三角连线，显示 `t` 未显式排序或时间序列拼接顺序问题；轻量包无 steps，无法复算 | 只能粗看趋势/灾难退化；不能用于精确学习速度、转折或面积比较 |
| `final_performance_by_environment.png` | 800-row summary 的 final mean±SEM | 与本分析均值一致；condition 顺序是数据顺序而非配置顺序；E4 单独 reward 轴正确 | 支持终局均值与异质性；不能替代 paired inference，也不能比较跨环境绝对高度 |
| `task_matched_vs_generic.png` | raw/whitened/gaussian/matched 四条件终局 bars | 与 summary 一致 | 支持 matched 非普适；不能说明差异是否由同 seed 配对显著 |
| `effective_rank_vs_control.png` | representation + summary 的 800 个 seed 点 | 与 CSV 范围一致；不同环境 feature dimension 不同 | 支持 rank 不充分；不能作因果解释或跨环境 pooled slope |
| `isotropy_vs_control.png` | isotropy error 对 final performance | 与 CSV 一致；E4 尾部明显 | 支持低 isotropy error 不保证收益；不能证明 whitening 因 isotropy 而改善 |
| `decodability_vs_control.png` | 环境特定 task_decodability 对控制 | 与 CSV 一致；x 指标定义随环境变化 | 支持 T-maze 较强关系和其他环境反例；不能把四环境 x 值当同一测量尺度 |
| `covariance_eigenvalue_spectra.png` | 各环境/条件的平均 covariance eigenvalues | 与 representation CSV 一致；log y 将零/近零显示在 floor，feature dimension 不同 | 支持谱形/秩差异；不能说明单 seed 稳定性或控制因果 |
| `moment_error_vs_control_performance.png` | skewness/kurtosis error 与 final performance 的 pooled scatter | **关键问题：把 E1–E3 accuracy 与 E4 reward 混在同一 y 轴；kurtosis outliers 也压缩尺度** | 只展示有极端 moment error；不能支持 pooled moment-performance 结论 |
| `property_fulfillment_summary.png` | 4×10 的 mean isotropy error heatmap | 数值与 CSV 一致；标题“property fulfillment”实际只覆盖 isotropy | 支持 second-order 几何比较；不能证明 simplex/circle/sparsity/moment 等全部命名性质达成 |
| `update_norm_stability.png` | `aggregate_updates.csv` 的 update norm mean±SEM | 极端 gaussian/E4-whitened 与 summary 同阶；线性 y 轴让其余条件不可见；轻量包无 updates | 支持存在极端有限值爆发；不能定位爆发时间或验证每条曲线 |
| `environment_specific_latent_geometry.png` | 每环境第一个 matched seed 的 diagnostic samples；E4 用 PCA | 结构与源码一致，但不是 20-seed 汇总；颜色是 diagnostic-only latent | 支持单 seed 的结构实现；不能推广到 seed population 或说明控制收益 |
| `e1_cue_clusters.png` | 第一个 matched seed 的 simplex coordinates 与 cue | p1+p2≈1；两 cue 在部分区间重叠 | 支持 simplex constraint；不能证明完美 cue separation 或 matched 优于 raw |
| `e2_circular_phase.png` | 第一个 matched seed 的 circle block 与 true phase | 半径约 1，但有断裂弧和离群点；与 pilot real-stream phase-order 失败相容 | 支持 unit-circle 约束；不能证明全局相位顺序或 20-seed 稳健性 |
| `e3_block_representation.png` | identity simplex 与 phase circle blocks | 两个几何块可见，但 identity 颜色重叠、circle 有断裂 | 支持 block implementation；不能解释为什么 full matched 未改善控制 |
| `e4_hidden_velocity_prediction.png` | 第一个 matched seed 的 held-out true/predicted velocity | 明显回归收缩和离群点，远离 ideal line；matched task R² 汇总均值约 0.335 | 支持只能部分解码速度；不能代表 20 seeds 或证明预测改善控制 |

## 是否需要补充下载

不建议立即下载 18 GB 全包。按未回答问题精准补充：

| 文件 | 尚未回答的问题 | 下载范围 | 会否改变核心结论 | 优先级 |
|---|---|---|---|---|
| `aggregate_steps.csv` | 学习曲线为何折返；E3 gaussian 是否先学会后退化；time-to-threshold 与最终性能的时间关系 | 建议完整 aggregate 文件，便于统一排序和 20-seed 重绘 | 不太会改变终局配对结论，但会改变学习动力学结论 | 高 |
| `aggregate_updates.csv` | 数值爆发在何时开始、持续多久、是否与控制退化同步 | 建议完整 aggregate；若必须裁剪，优先异常 env/condition/seeds | 不会消除已观察到的极端终局量，但会决定稳定性机制解释 | 高 |
| `aggregate_decisions.csv` | Ringworld raw/matched 的双峰来自何种 decision trajectory；E1/E3 决策级恢复 | 可先下载 Ringworld 全 conditions×20 seeds，再按需扩展 | 可能细化异质性，不太会推翻 final mean/paired result | 中 |
| run-level `prediction_metrics.csv` | Gaussian moment 的 predictive TD/transform drift 是否先于 control 爆发 | 优先 E1 gaussian seeds 1,3,4,8,9,13,14；E2 seeds 9,10,15；E3 gaussian 全 seeds；E4 whitened 1,10、standardized 5,7,15,18,19、matched 2,7,11,13,14,15,17 | 可能改变机制归因，不改变“存在稳定性失败” | 中高 |
| run-level `diagnostic_samples.npz` | matched/whitened/raw 的几何结构是否跨 20 seeds 稳健 | 先取每环境 matched 全 20 seeds，再取 raw/whitened/gaussian 对照 | 可能改变结构稳健性结论，不改变已测终局性能 | 中 |
| 18 GB 完整包 | 只有在上述 aggregates/run-level 定向文件仍不足时做完整 forensic reproduction | 暂不下载 | 当前无证据表明需要用它才能回答核心科研问题 | 低 |

## 最可靠的三条科研结论

1. **Second-order conditioning 在三个离散部分可观测任务中有可重复收益，但不是跨环境安全默认。** Whitened 对 E1/E2/E3 的 paired effect 全部明确正向，E4 则有灾难 seed。
2. **性质达成与下游效用相互分离。** Whitening 在四环境都降低 isotropy error；matched 结构也按设计出现，但控制收益仍异质甚至为负。
3. **任务信息比单一 generic rank/isotropy 更接近控制需求，但仍不充分。** Overall task decodability 关系更强；Ringworld/Two-loop 的 condition confounding 和 raw-vs-whitened 反例阻止普适因果解释。

## 最重要的三条限制

1. 轻量包缺失 steps/updates/decisions，原始学习曲线存在明显连线伪影，时间动力学尚未独立复算。
2. 多个方法有重尾/灾难 seed；20-seed mean、SEM 和普通 divergence flag 不能完整表达尾部风险，尤其 gaussian_moment 与 E4 conditioned methods。
3. 相关和 probe 指标是观察性、环境特定且受 condition 分组影响；图中的 latent geometry 仅来自第一个 matched seed，不能作群体或因果结论。

## 结论边界

本分析支持继续研究“何时以及为什么 conditioning 有效”，不支持将 whitening、moment shaping 或 task-matched prior 作为普适最佳方法。下一步应先取得 aggregate steps/updates 并解释数值尾部，而不是根据 full 结果调参追求正面结果。
