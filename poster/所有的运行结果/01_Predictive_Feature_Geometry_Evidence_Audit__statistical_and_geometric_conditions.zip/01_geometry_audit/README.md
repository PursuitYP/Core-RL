# Predictive Feature Geometry Evidence Audit

**Core topic:** whether prescribed statistical and geometric properties of online predictive features improve strictly streaming linear control under partial observability.

This package is the English LaTeX edition of the latest formatting-optimized evidence-audit PDF returned earlier in the conversation. It covers the four-environment pilot, property diagnostics, task decodability, control performance, bank/horizon ablations, null results, and failure boundaries.

## Build

```bash
./build.sh
```

The build requires a standard TeX Live/MiKTeX installation with `latexmk` and `pdflatex`.
