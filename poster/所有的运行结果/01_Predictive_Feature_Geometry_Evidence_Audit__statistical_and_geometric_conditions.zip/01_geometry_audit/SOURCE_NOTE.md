## Source and version selection

This package translates the latest formatting-optimized version of the standalone predictive-feature-geometry evidence audit (`排版优化后的报告.pdf`). It is treated as a distinct article rather than as a revision of the later integrated paper.
